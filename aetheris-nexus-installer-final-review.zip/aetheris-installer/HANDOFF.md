# AETHERIS NEXUS INSTALLER — HANDOFF

## Estado recibido
- Aplicación Electron + React + Vite + TypeScript.
- Motor `.mrpack`, seguridad transaccional y copias: 39 pruebas declaradas en el informe original.
- UI: 8 pruebas Playwright declaradas; antes dependían de rutas absolutas locales y el workflow no las ejecutaba.
- No hay `.mrpack` de perfiles incluidos.
- No hay `package-lock.json` ni `.exe` en el ZIP recibido.
- La generación de un ejecutable y las pruebas NSIS/Windows no se habían ejecutado.

## Cambios en esta revisión
- Workflow Windows actualizado para generar lockfile cuando falte y luego usar `npm ci`.
- Workflow ejecuta las 39 pruebas del motor/servicio y las 8 pruebas de UI en Chromium.
- El test UI ahora resuelve Playwright desde las dependencias del proyecto y abre la compilación real de Vite (`dist/renderer/index.html`).
- Playwright 1.65.0 agregado como dependencia de desarrollo para que la prueba UI sea reproducible.
- Añadido `packs/.gitkeep` para que el directorio `extraResources` exista en un checkout limpio de GitHub.
- Añadido `dist-tests/` a `.gitignore`.
- El workflow sube también `package-lock.json` como artefacto para que se descargue y se incorpore al repositorio después del primer build.

## Validación realizada aquí
- ZIP recibido: extraído con comprobación de rutas seguras.
- Revisión estática del manifiesto, configuración Electron Builder, workflow, rutas de recursos y pruebas.
- `npm install` **no pudo ejecutarse** en este entorno: fallo DNS `EAI_AGAIN` al resolver `registry.npmjs.org`.
- No se generó lockfile, no se instalaron Electron/Vite/Playwright y no se compiló `.exe` aquí.

## Siguiente paso obligatorio
1. Subir el contenido de esta carpeta a un repositorio GitHub en la rama `main`.
2. Ejecutar Actions → `Build Windows installer`.
3. Si falla, descargar el log de Actions y corregir el error exacto.
4. En el primer build exitoso, descargar el artefacto `AETHERIS-NEXUS-INSTALLER-package-lock` y añadir `package-lock.json` al repositorio; los siguientes builds usarán `npm ci` sin volver a resolver versiones.
5. El `.exe` aún debe probarse en una computadora Windows real junto con los tres paquetes `.mrpack` reales.

## Pendientes conocidos
- Los tres `.mrpack` siguen ausentes.
- Electron real, instalador NSIS, instalación/desinstalación, launchers y Minecraft aún no se han validado en Windows real.
- No hay firma digital configurada.

## Revisión adicional de CI (2026-11-09)
- Confirmado en metadatos públicos que las versiones declaradas de Electron 45.2.3, electron-builder 26.18.1, Playwright 1.65.0, tsx 4.23.12, TypeScript 6.0.3 y React 19.2.8 existen/publicadas. Esto **no sustituye** la resolución de todo el árbol de dependencias ni un `npm ci` real.
- El workflow fija Node 22.16.0 (compatible con el mínimo `>=22.12` declarado por el proyecto y las herramientas de Vite/Playwright).
- La prueba smoke ahora busca el ejecutable por su nombre exacto y tiene límite de 55 segundos para no dejar CI bloqueada si la app no cierra.
- Sigue pendiente ejecutar GitHub Actions en Windows: este entorno no pudo resolver el registro npm, por lo que no hay `package-lock.json`, `node_modules` ni `.exe` verificables.
