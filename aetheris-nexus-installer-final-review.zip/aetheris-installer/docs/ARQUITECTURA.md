# Arquitectura

```
src/
  core/        Motor (TypeScript puro, solo APIs de Node; NO importa Electron)
    zip.ts        Lector ZIP para entradas no confiables (zip-slip, bombas, CRC, enlaces)
    mrpack.ts     Validación de modrinth.index.json y overrides/client-overrides
    download.ts   Descarga en streaming, hash SHA-1/SHA-512 mientras llega, reintentos, cancelación
    engine.ts     Instalar/actualizar/cambiar, reparar, verificar, desinstalar, reversión (diario txn.json)
    backup.ts     Copias automáticas y manuales, restauración verificada
    registry.ts   Registro de archivos instalados (.aetheris/install.json), escritura atómica
    paths.ts      Rutas seguras, carpetas protegidas, destinos aceptables
    detect.ts     Windows, RAM, Java, launchers (acceso al sistema inyectable para pruebas)
    launcher.ts   Perfil de Fabric y entrada en launcher_profiles.json (launcher oficial)
    profiles.ts   Perfiles, estado de cada paquete, reglas (sin shaders en FPS/PvP), avisos
  electron/
    service.ts    Une el núcleo con la API de la interfaz (sin Electron; probado)
    main.ts       Ventana, IPC con validación de argumentos, diálogos, smoke test
    preload.ts    Puente seguro (contextBridge): solo funciones concretas
  shared/       Tipos y contrato de la API (api.ts, types.ts)
  renderer/     Interfaz React (Vite): vistas, panel de operación, tema oscuro
profiles/profiles.json   Definición de los tres perfiles (objetivos) y nombre del .mrpack esperado
packs/                   Aquí van los .mrpack reales
tests/                   Pruebas del núcleo/servicio (node:test) y de interfaz (Playwright)
```

## Flujo de una instalación (transaccional)
1. **Validar** el `.mrpack` (estructura, loader Fabric, rutas, dominios, hashes presentes).
2. **Preparar** en `.aetheris/staging/…` dentro de la instancia: descargar con verificación de hash y extraer overrides. Si algo falla aquí, **la instancia no cambia**; al reintentar se reutiliza lo ya verificado.
3. **Planificar**: qué se crea, qué se reemplaza, qué se retira (archivos antiguos del perfil anterior que no hayas tocado), qué configuración tuya se respeta.
4. **Respaldar** originales a `.aetheris/backups/<id>/` y escribir el diario `txn.json` **antes** de cambiar nada.
5. **Aplicar** (renombrados en el mismo volumen), registrar `install.json` de forma atómica y borrar el diario.
6. Si falla a mitad: reversión automática desde el diario. Si el proceso muere: la siguiente operación detecta el diario, se niega a continuar y ofrece «Revertir cambios».

## Seguridad de la interfaz
`contextIsolation`, `sandbox`, sin `nodeIntegration`, CSP estricta, navegación y ventanas nuevas bloqueadas, permisos denegados, IPC solo desde nuestra ventana y con argumentos validados, una única operación a la vez.
