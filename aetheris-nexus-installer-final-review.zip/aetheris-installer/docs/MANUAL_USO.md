# Manual de uso

## Primer arranque
Abre **Perfiles**. Cada tarjeta indica si su paquete está **Configurado**, **Falta el paquete** o **No es válido**. Si falta, usa **Incorporar .mrpack**. En **Sistema** ves Windows, RAM, Java y los launchers detectados.

## Instalar un perfil
1. **Instalar** en la tarjeta del perfil.
2. Elige destino: *Launcher oficial* (carpeta propia en `.minecraft\aetheris-instances\<perfil>`, sin mezclar con tu .minecraft) o *Carpeta de instancia* (Prism, Modrinth App, CurseForge…: se copian archivos; el cargador Fabric debe estar ya configurado en esa instancia).
3. Elige qué hacer con tu configuración existente (`options.txt`, `config/`, `shaderpacks/`): **respetarla** (por defecto) o reemplazarla (con copia previa).
4. En el launcher oficial puedes crear el perfil automáticamente (cierra el launcher antes; se hace copia de `launcher_profiles.json`).
5. Sigue el progreso por fases. **Cancelar** no deja nada a medias. Si falla una descarga: **Reintentar**.

## Mantenimiento
- **Comprobar integridad**: compara cada archivo instalado con su huella.
- **Reparar**: restaura archivos que faltan o están dañados; tus configuraciones editadas se respetan.
- **Actualizar al paquete actual** y **Cambiar de perfil**: reaplican el paquete; se retiran solo los archivos antiguos que no modificaste.
- **Copias de seguridad**: crear y restaurar (archivos instalados + tu configuración; nunca mundos ni capturas).
- **Revertir cambios**: aparece si una operación se interrumpió.
- **Desinstalar**: retira solo lo registrado por AETHERIS y su perfil del launcher; tus mundos, capturas, partidas y archivos propios no se tocan.

## Dónde se guarda todo
`<instancia>\.aetheris\` (registro, copias, diario) · `%APPDATA%\AETHERIS NEXUS INSTALLER\` (registros del instalador, paquetes incorporados, lista de instalaciones).
