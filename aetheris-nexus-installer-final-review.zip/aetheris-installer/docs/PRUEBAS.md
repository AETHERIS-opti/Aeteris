# Pruebas

Ejecutar: `npm test` (núcleo y servicio, 39 pruebas) y `npm run build:renderer && npx playwright install chromium && npm run test:ui` (8 pruebas de interfaz sobre la compilación real de Vite). El workflow Windows ejecuta ambos grupos.

## Qué es REAL y qué es SIMULADO
| Prueba | Real | Simulado |
|---|---|---|
| Lectura/validación ZIP y mrpack | Código real sobre archivos ZIP reales | Los ZIP los fabrica el test (sintéticos) |
| Descargas, hashes, reintentos, cancelación, URL inaccesible | Código real con `fetch` real | Servidor HTTP local en 127.0.0.1 con contenido de prueba |
| Instalar/actualizar/reparar/desinstalar/copias/reversión/corte | Código real sobre el sistema de archivos real (carpetas temporales) | El «corte» se simula con un gancho de prueba |
| Mundos y archivos personales intactos | Se comparan bytes antes/después | Mundos de juguete (no son partidas reales) |
| Detección de sistema y Java | Lógica real | Contextos falsos (no se ejecutó en Windows) |
| Launcher oficial | Lógica real sobre archivos temporales | `launcher_profiles.json` y servidor de Fabric simulados; **no el launcher real** |
| Errores de permisos | Enlace simbólico hacia fuera, destinos prohibidos | **No** se probaron permisos de Windows (ACL) |
| Interfaz | Chromium real, React real, compilación real de Vite | API de Electron simulada |
| Verificación de `.exe` | Lógica de cabecera PE | Cabeceras sintéticas |

## NO probado
Electron en ejecución, IPC real, diálogos nativos, NSIS, instalación/desinstalación del `.exe`, launchers reales, Windows real, rutas con espacios/acentos largas de Windows, ACL/permisos, antivirus, ni Minecraft. Los pasos de Windows están en el workflow pero no se han ejecutado.

## Medición de rendimiento del motor (este sandbox, Linux, Node 22.23, Xeon 2,1 GHz)
`tsx scripts/perf-check.ts`: 300 MB descargados y verificados + 400 archivos pequeños extraídos en **≈3,4 s** (dos mediciones: 3,41 s y 3,44 s; antes de evitar la segunda lectura de cada descarga, una medición dio 4,33 s); memoria residente pico **≈ +38 MB** sobre el inicio (el contenido se procesa en streaming). No es un benchmark de Minecraft ni de un Windows real.
