# Informe de auditoría del proyecto

Fecha: 2026-11-09. Alcance: todo el contenido de esta carpeta. Entorno de revisión: Linux, Node 22.23, TypeScript 6.0.3, Chromium headless (Playwright). **Sin acceso a npm, sin Electron, sin Windows.**

## Estado inicial
El proyecto instalador se creó en esta sesión (no existía código previo del instalador). Lo anterior de AETHERIS NEXUS (paquetes `.mrpack`, resource packs, catálogo de mods) vive en otra carpeta y no se ha modificado.

## Qué está terminado y comprobado
| Área | Resultado |
|---|---|
| Lectura ZIP segura | ✔ 6 pruebas (rutas, enlaces, duplicados, CRC/tamaño, bombas, no-ZIP) |
| Validación `.mrpack` | ✔ 3 pruebas (índice, loader, hashes, URLs/dominios, rutas protegidas, extensiones, client-overrides) |
| Descargas | ✔ 6 pruebas (hash, reintentos, 404, espejo, conexión rechazada, cancelación) |
| Motor transaccional | ✔ 12 pruebas (instalar, fallo previo sin cambios, hash manipulado, config personal, reversión a mitad, corte de proceso, actualizar/cambiar, reparar, desinstalar, copias, enlaces simbólicos, cancelar/concurrencia, loader y rutas protegidas) |
| Sistema/launcher/perfiles | ✔ 5 pruebas con contextos simulados |
| Servicio (lo que llama la UI) | ✔ 4 pruebas de extremo a extremo en carpetas temporales |
| Scripts | ✔ verificación de arquitectura del `.exe` (cabeceras sintéticas) |
| Interfaz | ✔ 8 pruebas en Chromium con API simulada + 8 capturas en `docs/screenshots/` |
| Tipos del núcleo/servicio/Electron | ✔ `tsc --strict` limpio (Electron contra un shim mínimo propio, no los tipos reales) |
| Tipos de la interfaz | ◐ comprobados con un shim de React; los únicos avisos fueron parámetros de eventos sin tipo por el shim. Los tipos reales los comprueba la CI |

## Hallazgos corregidos durante el desarrollo
1. Una descarga con contenido manipulado devolvía un error de tamaño en vez de `E_HASH`: la comprobación de hash ahora va primero.
2. Rutas de Windows (`C:\…`) no se reconocían como absolutas al probar en Linux: la validación de destino ahora entiende ambos formatos.
3. Cada archivo descargado se leía dos veces (verificación en streaming + hash de registro): ahora solo se calcula el SHA-256. Mejora medida de ≈4,3 s a ≈3,4 s en la prueba de 300 MB.
4. Etiquetas en mayúsculas por CSS hacían fallar una prueba de interfaz (error del test, no de la UI).
5. El chip «Sin shaders» aparecía duplicado.

## Revisión de rendimiento del instalador
- Descarga y extracción en **streaming**; nunca se carga un archivo completo en memoria (índice y archivos pequeños con tope de 8 MiB). Medido: +≈38 MB de pico con 300 MB.
- Descargas en paralelo (4 por defecto), con espera exponencial; sin bucles de sondeo salvo la pantalla de registros (cada 1,5 s solo mientras está abierta).
- Dependencias de ejecución: solo `react` y `react-dom`. El motor no usa paquetes de terceros (ZIP propio).
- Concurrencia: bloqueo por carpeta (una operación por instancia) y una sola operación a la vez en la app.

## Riesgos abiertos
- **Electron/NSIS sin ejecutar** (ver `LIMITACIONES_Y_PENDIENTES.md`).
- Versiones de dependencias: `electron 45.2.3`, `electron-builder 26.18.1` y `vite 8.2` constan en fuentes consultadas; `@vitejs/plugin-react ^6.0.2` aparece en una fuente; `typescript 6.0.3`, `react 19.2.8` y `tsx 4.23.12` son las del entorno de desarrollo. **No se pudo ejecutar `npm install`**, así que ninguna combinación se ha resuelto realmente.
- El modo de lectura de ZIP rechaza ZIP64 (los `.mrpack` normales no lo necesitan).
- Un `.mrpack` con `fabric-loader` inexistente en el servicio de Fabric hace fallar solo la creación del perfil del launcher (los archivos quedan instalados y se informa).


## Ajustes de empaquetado (2026-11-09)
- Revisión estática de `electron-builder.yml`, rutas de renderer/recursos y workflow Windows.
- `tests/ui/ui.test.cjs` ahora usa la dependencia local `playwright`, abre `dist/renderer/index.html` producido por Vite y convierte la ruta local con `pathToFileURL` para Windows.
- CI ejecuta los grupos de 39 pruebas de motor/servicio y 8 pruebas UI.
- La compilación y las pruebas Windows siguen sin ejecutarse en esta revisión: la instalación npm local quedó bloqueada por DNS `EAI_AGAIN` a `registry.npmjs.org`.
