# Seguridad

| Medida | Dónde | Probado |
|---|---|---|
| Rutas del ZIP/mrpack: sin `..`, absolutas, unidades, UNC, `:`, nombres reservados, barras invertidas | `paths.ts`, `zip.ts` | Sí (zip.test) |
| Enlaces simbólicos en ZIP rechazados; ancestros simbólicos hacia fuera del destino rechazados | `zip.ts`, `paths.ts` | Sí |
| Zip bombs: máx. entradas, tamaño por entrada y total, ratio | `zip.ts` | Sí |
| CRC y tamaño verificados al extraer; sin archivos parciales | `zip.ts` | Sí |
| Solo dominios permitidos por la especificación de Modrinth y solo https | `mrpack.ts` | Sí |
| Sin hash = sin descarga; hash SHA-1/SHA-512 verificado en streaming | `mrpack.ts`, `download.ts` | Sí |
| Extensiones ejecutables bloqueadas (`.exe .bat .dll .ps1 …`); mods solo `.jar` | `paths.ts`, `mrpack.ts` | Sí |
| Carpetas protegidas (`saves`, `screenshots`, `logs`, `crash-reports`, `servers.dat`…): un paquete que las toque se rechaza | `paths.ts` | Sí (y por mutación) |
| Configuración personal no se sobrescribe sin autorización | `engine.ts` | Sí |
| Copia antes de reemplazar/retirar; reversión desde diario; recuperación tras corte | `engine.ts` | Sí (corte simulado) |
| Desinstalación solo de lo registrado y sin modificar | `engine.ts` | Sí |
| Destinos no aceptables (raíz de unidad, Windows, Program Files, home) | `paths.ts` | Sí |
| Sin permisos de administrador (`asInvoker`, NSIS por usuario) | `electron-builder.yml` | **No** (requiere CI Windows) |
| Electron endurecido (aislamiento, sandbox, CSP, IPC validado) | `main.ts`, `preload.ts`, `index.html` | Parcial: la CI hace un smoke test; nunca ejecutado aquí |

**Pruebas de mutación** (hechas a mano en el entorno de desarrollo): romper a propósito `isProtected`, la comprobación de hash, el filtro `..`, la reversión, el borrado de archivos modificados y la protección de configuración hace fallar pruebas en los seis casos.

**No firmado**: el `.exe` no tiene firma digital. SmartScreen puede avisar. Comprueba el SHA-256 que muestra el resumen de GitHub Actions.
