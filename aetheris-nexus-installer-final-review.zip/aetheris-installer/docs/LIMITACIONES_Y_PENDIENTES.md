# Limitaciones y tareas pendientes

## Limitaciones
1. **No hay ejecutable.** Hay que compilarlo con GitHub Actions. Hasta que el workflow se ejecute en Windows, no se sabe si compila `electron-builder`, si el NSIS se genera ni si la app arranca.
2. **Sin firma digital.** SmartScreen puede avisar.
3. **Launchers**: solo el oficial tiene integración (perfil + versión de Fabric), y **nunca se probó contra el launcher real**. Para Prism, Modrinth App, CurseForge, GDLauncher solo se copian archivos; las rutas de instancias son suposiciones basadas en ubicaciones habituales. Marcados «No verificado» en la UI.
4. El launcher oficial puede sobrescribir `launcher_profiles.json` si está abierto: se avisa de cerrarlo.
5. Solo Fabric. Solo `.mrpack` (no CurseForge `.zip`).
6. Java: 26.3 → Java 25 consta en las fuentes consultadas; el resto de versiones sigue la tabla conocida de Mojang. El launcher oficial lleva su propio Java; la detección es informativa y no bloquea.
7. Los perfiles dependen de sus `.mrpack`: el instalador **no incluye** ninguno y no inventa diferencias entre perfiles.
8. No se verificó ningún permiso de Windows (ACL), rutas largas (>260), antivirus ni instalación en unidades de red.

## Pendiente (orden)
1. Subir a GitHub, ejecutar el workflow y corregir lo que falle (primer run: genera `package-lock.json`; súbelo).
2. Añadir los tres `.mrpack` reales en `packs/` (o con «Incorporar .mrpack») y probar una instalación completa con Minecraft real.
3. Probar el perfil del launcher oficial en un Windows real; probar Prism/Modrinth App y ajustar rutas.
4. Certificado de firma de código (si se quiere eliminar el aviso de SmartScreen).
5. Pruebas de interfaz en CI (requiere Playwright y navegadores).
6. Auto-actualización del instalador (no implementada).


## Revisión del empaquetado (2026-11-09)
- El workflow ahora resuelve un lockfile si falta y después ejecuta `npm ci`. El primer lockfile se publica como artefacto para incorporarlo al repositorio.
- Las 8 pruebas de interfaz se integraron en CI con Playwright/Chromium y cargan la compilación real de Vite; antes dependían de rutas absolutas del entorno de desarrollo y no se ejecutaban en Actions.
- Añadido `packs/.gitkeep` para que el directorio de recursos exista al clonar el repositorio.
- Estas modificaciones aún no están verificadas en GitHub Actions. Este entorno no pudo resolver `registry.npmjs.org` (DNS `EAI_AGAIN`), por lo que no se pudo generar aquí `package-lock.json`, instalar dependencias ni crear el `.exe`.
