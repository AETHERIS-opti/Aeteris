/**
 * Capa de servicio del proceso principal: une el núcleo (src/core) con la API de la interfaz.
 * NO importa 'electron': recibe las rutas y utilidades por parámetro, así se puede probar con Node puro.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { AetherisError, isAetherisError, userMessage } from '../core/errors';
import { Logger } from '../core/logger';
import { detectSystem, checkJava, realContext, type DetectContext } from '../core/detect';
import { installOrUpdate, repair, uninstall, verifyIntegrity, rollbackPending, getInstallInfo, setLauncherInfo, type EngineOptions } from '../core/engine';
import { createManualBackup, listBackups, restoreBackup } from '../core/backup';
import { installOfficialLauncherProfile, removeOfficialLauncherProfile, type LauncherOptions } from '../core/launcher';
import { listProfiles, importPack, loadConfig, resolvePackFile, type ProfilesPaths } from '../core/profiles';
import { assertAcceptableInstanceDir } from '../core/paths';
import { readRecord } from '../core/registry';
import type { AetherisApi, InstallArgs, InstallInfoDto, KnownInstall, OpSummary, ProgressMsg, Result } from '../shared/api';

export interface ServiceDeps {
  paths: ProfilesPaths; userData: string; log: Logger; emit: (m: ProgressMsg) => void;
  detectCtx?: DetectContext; engine?: Partial<EngineOptions>; launcher?: LauncherOptions; home: string;
  pickFile?: () => Promise<string | null>;
}

const ok = <T>(value: T): Result<T> => ({ ok: true, value });
const fail = (e: unknown, log: Logger): Result<never> => {
  const code = isAetherisError(e) ? e.code : 'E_UNEXPECTED';
  log.error(`${code}: ${(e as Error)?.message ?? String(e)}`);
  return { ok: false, error: { code, message: userMessage(e), ...(isAetherisError(e) && e.details ? { details: e.details } : {}) } };
};

const knownFile = (userData: string) => path.join(userData, 'installs.json');
async function readKnown(userData: string): Promise<string[]> { try { const j = JSON.parse(await fs.readFile(knownFile(userData), 'utf8')) as unknown; return Array.isArray(j) ? j.filter((x): x is string => typeof x === 'string') : []; } catch { return []; } }
async function addKnown(userData: string, folder: string) { const l = await readKnown(userData); if (!l.includes(folder)) { l.push(folder); await fs.mkdir(userData, { recursive: true }); await fs.writeFile(knownFile(userData), JSON.stringify(l, null, 2)); } }
async function dropKnown(userData: string, folder: string) { const l = (await readKnown(userData)).filter((f) => f !== folder); await fs.writeFile(knownFile(userData), JSON.stringify(l, null, 2)).catch(() => undefined); }

function dto(folder: string, r: NonNullable<Awaited<ReturnType<typeof getInstallInfo>>>): InstallInfoDto {
  return { folder, profileId: r.profileId, packName: r.packName, packVersionId: r.packVersionId, minecraft: r.minecraft, loaderVersion: r.loaderVersion, installedAt: r.installedAt, updatedAt: r.updatedAt, fileCount: r.fileCount, pendingTransaction: r.pendingTransaction, launcherProfile: !!r.launcher };
}

export function createService(d: ServiceDeps): Omit<AetherisApi, 'appInfo' | 'chooseFolder' | 'onProgress' | 'openFolder' | 'importPack'> & {
  importPackFrom(profileId: string, file: string): Promise<Result<{ imported: boolean }>>;
} {
  let current: AbortController | null = null;
  const eng = (op: string): EngineOptions => ({
    ...d.engine, home: d.home, log: d.log, ...(current ? { signal: current.signal } : {}),
    onProgress: (e) => d.emit({ ...e, op: e.op || op }),
  });
  const guard = async <T>(fn: () => Promise<T>): Promise<Result<T>> => {
    if (current) return fail(new AetherisError('E_BUSY', 'Ya hay otra operación en curso. Espera a que termine o cancélala.'), d.log);
    current = new AbortController();
    try { return ok(await fn()); } catch (e) { return fail(e, d.log); } finally { current = null; }
  };
  const safe = async <T>(fn: () => Promise<T>): Promise<Result<T>> => { try { return ok(await fn()); } catch (e) { return fail(e, d.log); } };
  const ctx = () => d.detectCtx ?? realContext();

  return {
    getSystem: () => safe(() => detectSystem(ctx())),
    javaCheck: (mc) => safe(async () => checkJava((await detectSystem(ctx())).java, mc)),
    listProfiles: () => safe(() => listProfiles(d.paths, d.engine?.policy)),
    defaultOfficialFolder: (profileId) => safe(async () => {
      if (!/^[a-z0-9-]{2,30}$/.test(profileId)) throw new AetherisError('E_PROFILE', 'Perfil inválido');
      const sys = await detectSystem(ctx());
      if (!sys.minecraftDir) throw new AetherisError('E_LAUNCHER', 'No se encontró la carpeta .minecraft');
      return path.join(sys.minecraftDir.path, 'aetheris-instances', profileId);
    }),
    importPackFrom: (profileId, file) => safe(async () => { await importPack(d.paths, profileId, file, d.engine?.policy); d.log.info(`Paquete incorporado para ${profileId}`); return { imported: true }; }),
    cancel: async () => { current?.abort(); },
    install: (a: InstallArgs) => guard(async (): Promise<OpSummary> => {
      const cfg = await loadConfig(d.paths.profilesJson);
      const def = cfg.profiles.find((p) => p.id === a.profileId);
      if (!def) throw new AetherisError('E_PROFILE', 'Perfil desconocido');
      const found = await resolvePackFile(d.paths, def);
      if (!found) throw new AetherisError('E_PROFILE', `El perfil ${def.name} todavía no tiene su archivo ${def.expectedFile}. Incorpóralo primero.`);
      const report = await listProfiles(d.paths, d.engine?.policy);
      const st = report.profiles.find((p) => p.id === a.profileId)!;
      if (st.status !== 'ready') throw new AetherisError('E_PROFILE', st.statusMessage);
      let folder: string; let mcDir: string | undefined;
      if (a.target.kind === 'official') {
        const sys = await detectSystem(ctx());
        if (!sys.minecraftDir?.exists) throw new AetherisError('E_LAUNCHER', 'No se encontró el launcher oficial de Minecraft. Ábrelo una vez o elige "Carpeta de instancia".');
        mcDir = sys.minecraftDir.path; folder = path.join(mcDir, 'aetheris-instances', a.profileId);
      } else {
        if (!a.target.folder) throw new AetherisError('E_TARGET', 'Elige una carpeta de destino');
        folder = a.target.folder;
      }
      folder = assertAcceptableInstanceDir(folder, d.home);
      d.log.info(`Instalando ${a.profileId} en ${folder}`);
      const res = await installOrUpdate({ ...eng('install'), instanceDir: folder, mrpackPath: found.file, profileId: a.profileId, userConfigPolicy: a.userConfigPolicy });
      await addKnown(d.userData, folder);
      const out: OpSummary = { op: res.op, installed: res.installed, unchanged: res.unchanged, removed: res.removed, skippedUserConfigs: res.skippedUserConfigs, keptModified: res.keptModified, duplicates: res.duplicates, ...(res.backupId ? { backupId: res.backupId } : {}), folder };
      if (a.target.kind === 'official' && a.createLauncherProfile && mcDir) {
        try {
          const rec = (await readRecord(folder))!;
          const info = await installOfficialLauncherProfile({ minecraftDir: mcDir, gameDir: folder, profileId: a.profileId, profileName: def.name, minecraft: rec.minecraft, loaderVersion: rec.loaderVersion }, d.launcher);
          await setLauncherInfo(folder, info); out.launcherProfile = 'created';
        } catch (e) { out.launcherProfile = 'failed'; out.launcherError = userMessage(e); d.log.warn(`Perfil de launcher no creado: ${userMessage(e)}`); }
      } else out.launcherProfile = 'skipped';
      return out;
    }),
    listKnownInstalls: () => safe(async (): Promise<KnownInstall[]> => {
      const out: KnownInstall[] = [];
      for (const folder of await readKnown(d.userData)) {
        const exists = await fs.stat(folder).then((s) => s.isDirectory(), () => false);
        let info: InstallInfoDto | null = null;
        if (exists) { try { const r = await getInstallInfo(folder); info = r ? dto(folder, r) : null; } catch { info = null; } }
        out.push({ folder, exists, info });
      }
      return out;
    }),
    inspect: (folder) => safe(async () => { const f = assertAcceptableInstanceDir(folder, d.home); const r = await getInstallInfo(f); if (r) await addKnown(d.userData, f); return r ? dto(f, r) : null; }),
    verify: (folder) => guard(async () => verifyIntegrity(assertAcceptableInstanceDir(folder, d.home), eng('verify'))),
    repair: (folder, policy) => guard(async () => {
      const r = await repair({ ...eng('repair'), instanceDir: assertAcceptableInstanceDir(folder, d.home), userConfigPolicy: policy });
      return { op: r.op, installed: r.installed, unchanged: r.unchanged, removed: r.removed, skippedUserConfigs: r.skippedUserConfigs, keptModified: r.keptModified, duplicates: r.duplicates, ...(r.backupId ? { backupId: r.backupId } : {}), folder, repaired: r.repaired };
    }),
    uninstall: (folder, removeBackups) => guard(async () => {
      const f = assertAcceptableInstanceDir(folder, d.home);
      const r = await uninstall({ ...eng('uninstall'), instanceDir: f, removeBackups });
      if (r.launcher) { try { await removeOfficialLauncherProfile(r.launcher, f, d.launcher); } catch (e) { d.log.warn(`No se pudo quitar el perfil del launcher: ${userMessage(e)}`); } }
      await dropKnown(d.userData, folder);
      return { removed: r.removed.length, keptModified: r.keptModified, ...(r.backupId ? { backupId: r.backupId } : {}) };
    }),
    rollbackPending: (folder) => guard(() => rollbackPending(assertAcceptableInstanceDir(folder, d.home), eng('rollback'))),
    createBackup: (folder) => guard(async () => { const b = await createManualBackup(assertAcceptableInstanceDir(folder, d.home), 'Copia manual desde el instalador'); return { id: b.id, createdAt: b.createdAt, reason: b.reason, kind: b.kind, fileCount: b.files.length }; }),
    listBackups: (folder) => safe(async () => (await listBackups(assertAcceptableInstanceDir(folder, d.home))).map((b) => ({ id: b.id, createdAt: b.createdAt, reason: b.reason, kind: b.kind, fileCount: b.files.length }))),
    restoreBackup: (folder, id) => guard(async () => { const r = await restoreBackup(assertAcceptableInstanceDir(folder, d.home), id); return { restored: r.restored, removed: r.removed }; }),
    readLogs: async () => d.log.tail(300).map((l) => ({ t: l.t, level: l.level, msg: l.msg })),
  };
}
