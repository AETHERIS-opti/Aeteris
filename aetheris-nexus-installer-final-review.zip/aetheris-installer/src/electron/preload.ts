/** Puente seguro: solo se exponen funciones concretas, nunca ipcRenderer ni Node. */
import { contextBridge, ipcRenderer } from 'electron';
import { CHANNELS, PROGRESS_CHANNEL, type AetherisApi, type ProgressMsg } from '../shared/api';

const invoke = (ch: string) => (...a: unknown[]) => ipcRenderer.invoke(`aetheris:${ch}`, ...a);
const api = Object.fromEntries(CHANNELS.map((c) => [c, invoke(c)])) as unknown as Omit<AetherisApi, 'onProgress'>;
const full: AetherisApi = {
  ...api,
  onProgress(cb) {
    const h = (_e: unknown, m: ProgressMsg) => cb(m);
    ipcRenderer.on(PROGRESS_CHANNEL, h);
    return () => { ipcRenderer.removeListener(PROGRESS_CHANNEL, h); };
  },
};
contextBridge.exposeInMainWorld('aetheris', full);
