/** Proceso principal de Electron. Toda la lógica vive en service.ts / src/core; aquí solo ventana, IPC y diálogos. */
import { app, BrowserWindow, dialog, ipcMain, session, shell } from 'electron';
import path from 'node:path';
import fs from 'node:fs/promises';
import { Logger } from '../core/logger';
import { assertAcceptableInstanceDir } from '../core/paths';
import { userMessage, isAetherisError } from '../core/errors';
import { createService } from './service';
import { CHANNELS, PROGRESS_CHANNEL, type AppInfo, type ProgressMsg, type Result } from '../shared/api';

let win: BrowserWindow | null = null;
const devUrl = process.env.VITE_DEV_SERVER_URL;

// Los recursos (perfiles y paquetes) viajan como extraResources en la app empaquetada.
const resourcesBase = () => (app.isPackaged ? process.resourcesPath : app.getAppPath());
const rendererIndex = () => path.join(app.getAppPath(), 'dist', 'renderer', 'index.html');

/** Prueba de arranque para la CI: la ventana carga, el puente seguro existe y se pintan las tres tarjetas de perfil. Sale con 0 o 1. */
function runSmokeTest(w: BrowserWindow) {
  const started = Date.now();
  const tick = async () => {
    try {
      const r = await w.webContents.executeJavaScript(`({ bridge: typeof window.aetheris?.listProfiles === 'function', node: typeof require !== 'undefined', cards: document.querySelectorAll('.card').length })`) as { bridge: boolean; node: boolean; cards: number };
      if (r.bridge && !r.node && r.cards === 3) { process.stdout.write('SMOKE-TEST OK: ventana cargada, puente seguro presente, Node no expuesto, 3 perfiles pintados\n'); app.exit(0); return; }
    } catch { /* la página aún no está lista */ }
    if (Date.now() - started > 40_000) { process.stderr.write('SMOKE-TEST FALLÓ: la interfaz no se pintó a tiempo\n'); app.exit(1); return; }
    setTimeout(() => void tick(), 500);
  };
  void tick();
}

function main() {
  if (!app.requestSingleInstanceLock()) { app.quit(); return; }
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.setAppUserModelId('com.aetheris.nexus.installer');

  const userData = app.getPath('userData');
  const logFile = path.join(userData, 'logs', 'installer.log');
  const log = new Logger(logFile);
  const send = (m: ProgressMsg) => { if (win && !win.isDestroyed()) win.webContents.send(PROGRESS_CHANNEL, m); };
  const svc = createService({
    paths: { profilesJson: path.join(resourcesBase(), 'profiles', 'profiles.json'), packsDir: path.join(resourcesBase(), 'packs'), userPacksDir: path.join(userData, 'packs') },
    userData, log, emit: send, home: app.getPath('home'),
  });

  const str = (v: unknown, max = 600): string => { if (typeof v !== 'string' || v.length === 0 || v.length > max) throw new Error('Argumento inválido'); return v; };
  const bad = (e: unknown): Result<never> => ({ ok: false, error: { code: isAetherisError(e) ? e.code : 'E_ARG', message: userMessage(e) } });
  const policy = (v: unknown): 'keep' | 'replace' => (v === 'replace' ? 'replace' : 'keep');

  const handlers: Record<(typeof CHANNELS)[number], (...a: unknown[]) => Promise<unknown>> = {
    appInfo: async (): Promise<AppInfo> => ({ version: app.getVersion(), packaged: app.isPackaged, platform: process.platform, arch: process.arch, electron: process.versions.electron ?? '?', signed: false, userData, logFile }),
    getSystem: () => svc.getSystem(),
    javaCheck: (mc) => svc.javaCheck(str(mc, 30)),
    listProfiles: () => svc.listProfiles(),
    importPack: async (id) => {
      const r = await dialog.showOpenDialog(win!, { title: 'Elegir archivo .mrpack', properties: ['openFile'], filters: [{ name: 'Paquete Modrinth', extensions: ['mrpack'] }] });
      if (r.canceled || !r.filePaths[0]) return { ok: true, value: { imported: false } };
      return svc.importPackFrom(str(id, 40), r.filePaths[0]);
    },
    chooseFolder: async (title) => { const r = await dialog.showOpenDialog(win!, { title: str(title, 120), properties: ['openDirectory', 'createDirectory'] }); return r.canceled ? null : r.filePaths[0] ?? null; },
    defaultOfficialFolder: (id) => svc.defaultOfficialFolder(str(id, 40)),
    install: (a) => {
      const o = a as { profileId?: unknown; target?: { kind?: unknown; folder?: unknown }; userConfigPolicy?: unknown; createLauncherProfile?: unknown };
      const kind = o.target?.kind === 'folder' ? 'folder' : 'official';
      return svc.install({ profileId: str(o.profileId, 40), target: kind === 'folder' ? { kind, folder: str(o.target?.folder) } : { kind }, userConfigPolicy: policy(o.userConfigPolicy), createLauncherProfile: o.createLauncherProfile === true });
    },
    cancel: () => svc.cancel(),
    listKnownInstalls: () => svc.listKnownInstalls(),
    inspect: (f) => svc.inspect(str(f)),
    verify: (f) => svc.verify(str(f)),
    repair: (f, p) => svc.repair(str(f), policy(p)),
    uninstall: (f, rb) => svc.uninstall(str(f), rb === true),
    rollbackPending: (f) => svc.rollbackPending(str(f)),
    createBackup: (f) => svc.createBackup(str(f)),
    listBackups: (f) => svc.listBackups(str(f)),
    restoreBackup: (f, id) => svc.restoreBackup(str(f), str(id, 60)),
    readLogs: () => svc.readLogs(),
    openFolder: async (f) => {
      try { const abs = assertAcceptableInstanceDir(str(f)); await fs.access(abs); const err = await shell.openPath(abs); return err ? bad(new Error(err)) : { ok: true, value: true }; }
      catch (e) { return bad(e); }
    },
  };
  for (const ch of CHANNELS) ipcMain.handle(`aetheris:${ch}`, async (ev, ...args) => {
    // solo se atienden mensajes de nuestra propia ventana
    if (!win || ev.sender !== win.webContents) return bad(new Error('Origen no permitido'));
    try { return await handlers[ch](...args); } catch (e) { return bad(e); }
  });

  app.whenReady().then(() => {
    session.defaultSession.setPermissionRequestHandler((_wc, _perm, cb) => cb(false));
    win = new BrowserWindow({
      width: 1180, height: 780, minWidth: 920, minHeight: 640, backgroundColor: '#07090f', title: 'AETHERIS NEXUS INSTALLER', show: false, autoHideMenuBar: true,
      webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true, spellcheck: false },
    });
    win.once('ready-to-show', () => win?.show());
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    win.webContents.on('will-navigate', (e) => e.preventDefault());
    if (devUrl) void win.loadURL(devUrl); else void win.loadFile(rendererIndex());
    if (process.argv.includes('--smoke-test')) runSmokeTest(win);
    win.on('closed', () => { win = null; });
    log.info(`Instalador ${app.getVersion()} iniciado (${process.platform}/${process.arch}, empaquetado: ${app.isPackaged})`);
  });
  app.on('window-all-closed', () => app.quit());
}
main();
