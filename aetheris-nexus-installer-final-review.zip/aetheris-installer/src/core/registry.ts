import fs from 'node:fs/promises';
import path from 'node:path';
import { AetherisError } from './errors';
import { assertSafeRelative, resolveInside } from './paths';

export const AETH = '.aetheris';

export interface TrackedFile {
  sha256: string; size: number; source: 'download' | 'override';
  sha1?: string; sha512?: string; urls?: string[];
}
export interface LauncherInfo { kind: 'official'; minecraftDir: string; versionId: string; profileKey: string; createdVersionFile: boolean }
export interface InstallRecord {
  schema: 1;
  profileId: string; packName: string; packVersionId: string;
  minecraft: string; loader: 'fabric'; loaderVersion: string;
  installedAt: string; updatedAt: string;
  files: Record<string, TrackedFile>;
  launcher?: LauncherInfo;
}
export interface Txn {
  id: string; op: string; startedAt: string; phase: 'committing' | 'applied';
  entries: Array<{ rel: string; action: 'create' | 'replace' | 'delete'; hadOriginal: boolean }>;
  createdDirs: string[];
}

export const aethDir = (instance: string) => path.join(instance, AETH);
export const recordPath = (instance: string) => path.join(aethDir(instance), 'install.json');
export const txnPath = (instance: string) => path.join(aethDir(instance), 'txn.json');
export const packCopyPath = (instance: string) => path.join(aethDir(instance), 'pack.mrpack');
export const stagingRoot = (instance: string, id: string) => path.join(aethDir(instance), 'staging', id);
export const backupsRoot = (instance: string) => path.join(aethDir(instance), 'backups');

export async function writeJsonAtomic(file: string, data: unknown): Promise<void> {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(data, null, 2));
  await fs.rename(tmp, file);
}

export async function readRecord(instance: string): Promise<InstallRecord | null> {
  let raw: string;
  try { raw = await fs.readFile(recordPath(instance), 'utf8'); } catch (e) { if ((e as NodeJS.ErrnoException).code === 'ENOENT') return null; throw e; }
  let r: InstallRecord;
  try { r = JSON.parse(raw) as InstallRecord; } catch { throw new AetherisError('E_IO', 'El registro de instalación está dañado (JSON inválido). Usa una copia de seguridad o reinstala.'); }
  if (r.schema !== 1 || typeof r.files !== 'object' || r.files === null || typeof r.profileId !== 'string') throw new AetherisError('E_IO', 'El registro de instalación tiene un formato desconocido');
  for (const rel of Object.keys(r.files)) { assertSafeRelative(rel, 'registro'); resolveInside(instance, rel); }
  return r;
}

export async function readTxn(instance: string): Promise<Txn | null> {
  try { return JSON.parse(await fs.readFile(txnPath(instance), 'utf8')) as Txn; }
  catch (e) { if ((e as NodeJS.ErrnoException).code === 'ENOENT') return null; throw new AetherisError('E_TXN_PENDING', 'Hay un diario de operación ilegible; revisa la carpeta .aetheris'); }
}
