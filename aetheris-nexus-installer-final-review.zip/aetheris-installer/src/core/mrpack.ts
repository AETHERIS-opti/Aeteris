/** Lectura y validación estricta de .mrpack según la especificación oficial de Modrinth (formatVersion 1). */
import { AetherisError } from './errors';
import { ZipReader, type ZipEntry } from './zip';
import { assertSafeRelative, hasBlockedExtension, isProtected } from './paths';
import { HEX_LEN, isHex } from './hash';

export interface MrpackFile {
  path: string;
  hashes: { sha1?: string; sha512?: string };
  env: { client: 'required' | 'optional' | 'unsupported'; server: 'required' | 'optional' | 'unsupported' };
  downloads: string[];
  fileSize?: number;
}
export interface MrpackIndex {
  formatVersion: 1; game: 'minecraft'; versionId: string; name: string; summary?: string;
  files: MrpackFile[];
  dependencies: Record<string, string>;
}
export interface NetworkPolicy { allowedHosts: string[]; allowHttp: boolean }
/** Dominios de descarga permitidos por la especificación de Modrinth. */
export const STRICT_POLICY: NetworkPolicy = { allowedHosts: ['cdn.modrinth.com', 'github.com', 'raw.githubusercontent.com', 'gitlab.com'], allowHttp: false };

const DOWNLOAD_DIRS = new Set(['mods', 'resourcepacks', 'shaderpacks', 'config']);
const LOADER_KEYS = ['fabric-loader', 'forge', 'neoforge', 'quilt-loader'];
const ALL_DEP_KEYS = new Set(['minecraft', ...LOADER_KEYS]);

export interface OpenedMrpack {
  zip: ZipReader;
  index: MrpackIndex;
  minecraft: string;
  loaderVersion: string;
  /** rel -> entrada; client-overrides ya tiene precedencia sobre overrides */
  overrides: Map<string, ZipEntry>;
}

export function checkUrl(u: unknown, policy: NetworkPolicy, ctx: string): string {
  if (typeof u !== 'string') throw new AetherisError('E_MRPACK', `${ctx}: URL inválida`);
  let url: URL;
  try { url = new URL(u); } catch { throw new AetherisError('E_MRPACK', `${ctx}: URL mal formada`); }
  if (url.protocol !== 'https:' && !(policy.allowHttp && url.protocol === 'http:')) throw new AetherisError('E_MRPACK', `${ctx}: solo se admiten URLs https (${url.protocol})`);
  if (url.username || url.password) throw new AetherisError('E_MRPACK', `${ctx}: la URL no puede llevar credenciales`);
  if (!policy.allowedHosts.includes(url.hostname)) throw new AetherisError('E_MRPACK', `${ctx}: dominio no permitido por la especificación de Modrinth: ${url.hostname}`);
  return u;
}

export function validateIndex(raw: unknown, policy: NetworkPolicy = STRICT_POLICY): { index: MrpackIndex; minecraft: string; loaderVersion: string } {
  const bad = (m: string): never => { throw new AetherisError('E_MRPACK', `modrinth.index.json inválido: ${m}`); };
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) bad('no es un objeto');
  const o = raw as Record<string, unknown>;
  if (o.formatVersion !== 1) bad(`formatVersion debe ser 1 (es ${String(o.formatVersion)})`);
  if (o.game !== 'minecraft') bad('game debe ser "minecraft"');
  if (typeof o.versionId !== 'string' || !o.versionId) bad('falta versionId');
  if (typeof o.name !== 'string' || !o.name) bad('falta name');
  const deps = o.dependencies;
  if (typeof deps !== 'object' || deps === null || Array.isArray(deps)) bad('faltan dependencies');
  const d = deps as Record<string, unknown>;
  for (const k of Object.keys(d)) if (!ALL_DEP_KEYS.has(k)) bad(`dependencia desconocida: ${k}`);
  for (const [k, v] of Object.entries(d)) if (typeof v !== 'string' || !v) bad(`versión inválida para ${k}`);
  if (typeof d.minecraft !== 'string') bad('falta la dependencia minecraft');
  const loaders = LOADER_KEYS.filter((k) => k in d);
  if (loaders.length !== 1) bad(`debe declarar exactamente un cargador (declara ${loaders.length})`);
  if (loaders[0] !== 'fabric-loader') throw new AetherisError('E_LOADER', `Este instalador solo admite Fabric; el paquete usa ${loaders[0]}`);
  if (!Array.isArray(o.files)) bad('files debe ser una lista');
  const seen = new Set<string>();
  const files: MrpackFile[] = [];
  for (const [i, f] of (o.files as unknown[]).entries()) {
    const ctx = `files[${i}]`;
    if (typeof f !== 'object' || f === null) return bad(`${ctx} no es un objeto`);
    const r = f as Record<string, unknown>;
    const p = assertSafeRelative(String(r.path), `${ctx}.path`);
    const top = p.split('/')[0]!;
    if (p.split('/').length < 2 || !DOWNLOAD_DIRS.has(top)) bad(`${ctx}: solo se descargan archivos dentro de ${[...DOWNLOAD_DIRS].join(', ')} (${p})`);
    if (top === 'mods' && !p.toLowerCase().endsWith('.jar')) bad(`${ctx}: los archivos de mods deben ser .jar (${p})`);
    if (hasBlockedExtension(p)) bad(`${ctx}: extensión no permitida (${p})`);
    if (isProtected(p)) throw new AetherisError('E_PROTECTED', `${ctx}: el paquete intenta escribir en una ruta protegida (${p})`);
    if (seen.has(p.toLowerCase())) bad(`ruta duplicada: ${p}`);
    seen.add(p.toLowerCase());
    const h = (r.hashes ?? {}) as Record<string, unknown>;
    const hashes: MrpackFile['hashes'] = {};
    if (h.sha1 !== undefined) { if (!isHex(h.sha1, HEX_LEN.sha1)) bad(`${ctx}: sha1 inválido`); hashes.sha1 = h.sha1 as string; }
    if (h.sha512 !== undefined) { if (!isHex(h.sha512, HEX_LEN.sha512)) bad(`${ctx}: sha512 inválido`); hashes.sha512 = h.sha512 as string; }
    if (!hashes.sha1 && !hashes.sha512) bad(`${ctx}: sin hash sha1/sha512 (no se descarga nada sin poder verificarlo)`);
    const dl = r.downloads;
    if (!Array.isArray(dl) || dl.length === 0) bad(`${ctx}: sin URLs de descarga`);
    const downloads = (dl as unknown[]).map((u, j) => checkUrl(u, policy, `${ctx}.downloads[${j}]`));
    const e = (r.env ?? {}) as Record<string, unknown>;
    const okEnv = (v: unknown) => v === 'required' || v === 'optional' || v === 'unsupported';
    if ((e.client !== undefined && !okEnv(e.client)) || (e.server !== undefined && !okEnv(e.server))) bad(`${ctx}: env inválido`);
    if (r.fileSize !== undefined && !(Number.isInteger(r.fileSize) && (r.fileSize as number) > 0 && (r.fileSize as number) <= 1024 ** 3)) bad(`${ctx}: fileSize inválido`);
    files.push({
      path: p, hashes, downloads,
      env: { client: (e.client as MrpackFile['env']['client']) ?? 'required', server: (e.server as MrpackFile['env']['server']) ?? 'required' },
      ...(r.fileSize !== undefined ? { fileSize: r.fileSize as number } : {}),
    });
  }
  const index: MrpackIndex = { formatVersion: 1, game: 'minecraft', versionId: o.versionId as string, name: o.name as string,
    ...(typeof o.summary === 'string' ? { summary: o.summary } : {}), files, dependencies: d as Record<string, string> };
  return { index, minecraft: d.minecraft as string, loaderVersion: d['fabric-loader'] as string };
}

/** Abre un .mrpack, valida índice y overrides y devuelve todo lo necesario para instalar. */
export async function openMrpack(file: string, policy: NetworkPolicy = STRICT_POLICY): Promise<OpenedMrpack> {
  const zip = await ZipReader.open(file);
  const idxEntry = zip.find('modrinth.index.json');
  if (!idxEntry) throw new AetherisError('E_MRPACK', 'No es un .mrpack: falta modrinth.index.json en la raíz');
  let json: unknown;
  try { json = JSON.parse((await zip.read(idxEntry)).toString('utf8')); } catch (e) {
    if (e instanceof AetherisError) throw e;
    throw new AetherisError('E_MRPACK', 'modrinth.index.json no es JSON válido');
  }
  const { index, minecraft, loaderVersion } = validateIndex(json, policy);
  const overrides = new Map<string, ZipEntry>();
  for (const prefix of ['overrides/', 'client-overrides/']) {
    for (const e of zip.entries) {
      if (e.isDirectory || !e.name.startsWith(prefix)) continue;
      const rel = assertSafeRelative(e.name.slice(prefix.length), 'ruta de overrides');
      if (isProtected(rel)) throw new AetherisError('E_PROTECTED', `El paquete intenta escribir en una ruta protegida: ${rel}`);
      if (hasBlockedExtension(rel)) throw new AetherisError('E_MRPACK', `El paquete incluye un archivo con extensión no permitida: ${rel}`);
      overrides.set(rel, e); // client-overrides se procesa después y reemplaza a overrides
    }
  }
  const lower = new Map<string, string>();
  for (const rel of overrides.keys()) {
    const k = rel.toLowerCase();
    if (lower.has(k) && lower.get(k) !== rel) throw new AetherisError('E_MRPACK', `Rutas de overrides que solo se distinguen por mayúsculas: ${rel}`);
    lower.set(k, rel);
  }
  return { zip, index, minecraft, loaderVersion, overrides };
}
