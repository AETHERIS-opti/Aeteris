import fs from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { AetherisError } from './errors';
import { sleep } from './paths';
import { hashFile } from './hash';
import type { NetworkPolicy } from './mrpack';
import { STRICT_POLICY, checkUrl } from './mrpack';

export interface Expected { sha1?: string; sha512?: string; size?: number }
export interface DownloadOptions {
  expected: Expected;
  retries?: number;           // reintentos tras el primer intento (por defecto 3)
  backoffMs?: number;         // espera base (por defecto 600 ms, exponencial)
  timeoutMs?: number;         // sin datos durante este tiempo => error (por defecto 30 s)
  signal?: AbortSignal;
  policy?: NetworkPolicy;
  fetchImpl?: typeof fetch;
  onBytes?: (n: number) => void;
  onRetry?: (attempt: number, err: Error) => void;
}

/** ¿El archivo ya existe y coincide con los hashes esperados? */
export async function matchesExpected(file: string, exp: Expected): Promise<boolean> {
  try {
    const st = await fs.stat(file);
    if (exp.size !== undefined && st.size !== exp.size) return false;
    const algos = ([exp.sha1 ? 'sha1' : null, exp.sha512 ? 'sha512' : null].filter(Boolean)) as Array<'sha1' | 'sha512'>;
    if (algos.length === 0) return false;
    const h = await hashFile(file, algos);
    return (!exp.sha1 || h.sha1 === exp.sha1) && (!exp.sha512 || h.sha512 === exp.sha512);
  } catch { return false; }
}

class Retryable extends Error {}

async function once(url: string, dest: string, o: DownloadOptions): Promise<void> {
  const f = o.fetchImpl ?? fetch;
  const ctl = new AbortController();
  const onAbort = () => ctl.abort();
  o.signal?.addEventListener('abort', onAbort, { once: true });
  let timer: NodeJS.Timeout | undefined;
  const arm = () => { clearTimeout(timer); timer = setTimeout(() => ctl.abort(new Error('tiempo de espera agotado')), o.timeoutMs ?? 30_000); };
  const part = dest + '.part';
  try {
    arm();
    let res: Response;
    try { res = await f(url, { signal: ctl.signal, redirect: 'follow', headers: { 'User-Agent': 'AETHERIS-NEXUS-INSTALLER/1.0' } }); }
    catch (e) { if (o.signal?.aborted) throw new AetherisError('E_CANCELLED', 'Descarga cancelada'); throw new Retryable(`conexión fallida: ${(e as Error).message}`); }
    if (!res.ok || !res.body) {
      if (res.status >= 500 || res.status === 429 || res.status === 408) throw new Retryable(`el servidor respondió ${res.status}`);
      throw new AetherisError('E_DOWNLOAD', `El servidor respondió ${res.status} para ${new URL(url).hostname}${new URL(url).pathname}`);
    }
    const sha1 = createHash('sha1'), sha512 = createHash('sha512');
    let size = 0;
    await fs.mkdir(path.dirname(dest), { recursive: true });
    const src = Readable.fromWeb(res.body as never);
    src.on('data', (c: Buffer) => { arm(); size += c.length; sha1.update(c); sha512.update(c); o.onBytes?.(c.length); });
    try { await pipeline(src, createWriteStream(part)); }
    catch (e) { if (o.signal?.aborted) throw new AetherisError('E_CANCELLED', 'Descarga cancelada'); throw new Retryable(`descarga interrumpida: ${(e as Error).message}`); }
    const e = o.expected;
    const d1 = sha1.digest('hex'), d512 = sha512.digest('hex');
    if ((e.sha512 && d512 !== e.sha512) || (e.sha1 && d1 !== e.sha1)) throw new AetherisError('E_HASH', `El archivo descargado no coincide con su hash (${path.basename(dest)}). Puede estar corrupto o manipulado.`);
    if (e.size !== undefined && size !== e.size) throw new AetherisError('E_HASH', `Tamaño inesperado en ${path.basename(dest)} (${size} ≠ ${e.size})`);
    await fs.rename(part, dest);
  } finally {
    clearTimeout(timer);
    o.signal?.removeEventListener('abort', onAbort);
    await fs.rm(part, { force: true });
  }
}

/** Descarga con verificación de hash y reintentos. Nunca deja el destino a medias. */
export async function downloadVerified(urls: string[], dest: string, o: DownloadOptions): Promise<void> {
  const policy = o.policy ?? STRICT_POLICY;
  const retries = o.retries ?? 3;
  let last: Error = new Error('sin URLs');
  for (const raw of urls) {
    const url = checkUrl(raw, policy, 'descarga');
    for (let attempt = 0; attempt <= retries; attempt++) {
      try { await once(url, dest, o); return; }
      catch (e) {
        if (e instanceof AetherisError && e.code === 'E_CANCELLED') throw e;
        last = e as Error;
        const fatal = e instanceof AetherisError && e.code === 'E_DOWNLOAD';
        const hashBad = e instanceof AetherisError && e.code === 'E_HASH';
        if (fatal) break;                         // 4xx: probar la siguiente URL
        if (hashBad && attempt >= 1) break;       // un reintento por si fue corrupción en tránsito
        if (attempt < retries) { o.onRetry?.(attempt + 1, last); await sleep((o.backoffMs ?? 600) * 2 ** attempt, o.signal); }
      }
    }
  }
  if (last instanceof AetherisError) throw last;
  throw new AetherisError('E_DOWNLOAD', `No se pudo descargar ${path.basename(dest)}: ${last.message}`);
}
