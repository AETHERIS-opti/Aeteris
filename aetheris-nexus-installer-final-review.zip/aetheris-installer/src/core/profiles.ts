import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { AetherisError } from './errors';
import { hashFile } from './hash';
import { openMrpack, STRICT_POLICY, type NetworkPolicy, type OpenedMrpack } from './mrpack';
import { assertSafeRelative } from './paths';
import type { ProfileSummary, ProfilesReport } from '../shared/types';

interface ProfileDef { id: string; name: string; tagline: string; description: string; highlights: string[]; shaders: 'optional' | 'none'; expectedFile: string; sha256?: string }
export interface ProfilesConfig { schema: 1; profiles: ProfileDef[] }
export interface ProfilesPaths { profilesJson: string; packsDir: string; userPacksDir: string }

const SHADER_RE = /(^|[/_-])(iris|oculus|optifine|shaders?)([/_.-]|$)/i;

export async function loadConfig(file: string): Promise<ProfilesConfig> {
  let c: ProfilesConfig;
  try { c = JSON.parse(await fs.readFile(file, 'utf8')) as ProfilesConfig; } catch (e) { throw new AetherisError('E_PROFILE', `No se pudo leer la configuración de perfiles: ${(e as Error).message}`); }
  if (c.schema !== 1 || !Array.isArray(c.profiles) || c.profiles.length === 0) throw new AetherisError('E_PROFILE', 'Configuración de perfiles inválida');
  const ids = new Set<string>();
  for (const p of c.profiles) {
    if (!/^[a-z0-9-]{2,30}$/.test(p.id) || ids.has(p.id)) throw new AetherisError('E_PROFILE', `Identificador de perfil inválido o repetido: ${p.id}`);
    ids.add(p.id); assertSafeRelative(p.expectedFile, 'expectedFile');
    if (p.expectedFile.includes('/') || !p.expectedFile.endsWith('.mrpack')) throw new AetherisError('E_PROFILE', `expectedFile inválido en ${p.id}`);
    if (p.shaders !== 'optional' && p.shaders !== 'none') throw new AetherisError('E_PROFILE', `shaders inválido en ${p.id}`);
  }
  return c;
}

/** Reglas del proyecto sobre el CONTENIDO real de un paquete para un perfil. */
export function checkProfileRules(def: ProfileDef, m: OpenedMrpack): string[] {
  const problems: string[] = [];
  if (def.shaders === 'none') {
    const hit = [...m.index.files.map((f) => f.path), ...m.overrides.keys()].filter((p) => SHADER_RE.test(p.toLowerCase()) || p.toLowerCase().startsWith('shaderpacks/'));
    if (hit.length) problems.push(`El perfil ${def.name} debe ir sin shaders, pero el paquete incluye: ${hit.slice(0, 3).join(', ')}${hit.length > 3 ? '…' : ''}`);
  }
  return problems;
}

const modNames = (m: OpenedMrpack) => m.index.files.filter((f) => f.path.startsWith('mods/') && f.env.client !== 'unsupported').map((f) => f.path.slice(5).toLowerCase()).sort();
export const modFingerprint = (m: OpenedMrpack) => createHash('sha256').update(modNames(m).join('\n')).digest('hex').slice(0, 12);

export async function resolvePackFile(paths: ProfilesPaths, def: ProfileDef): Promise<{ file: string; source: 'user' | 'bundled' } | null> {
  for (const [dir, source] of [[paths.userPacksDir, 'user'], [paths.packsDir, 'bundled']] as const) {
    const f = path.join(dir, def.expectedFile);
    if (await fs.stat(f).then((s) => s.isFile(), () => false)) return { file: f, source };
  }
  return null;
}

export async function listProfiles(paths: ProfilesPaths, policy: NetworkPolicy = STRICT_POLICY): Promise<ProfilesReport> {
  const cfg = await loadConfig(paths.profilesJson);
  const out: ProfileSummary[] = []; const fps = new Map<string, string[]>(); const warnings: string[] = [];
  for (const def of cfg.profiles) {
    const base = { id: def.id, name: def.name, tagline: def.tagline, description: def.description, highlights: def.highlights, shaders: def.shaders, expectedFile: def.expectedFile };
    const found = await resolvePackFile(paths, def);
    if (!found) { out.push({ ...base, status: 'missing', statusMessage: `Falta el archivo ${def.expectedFile}. Incorpóralo con "Incorporar .mrpack" o cópialo a la carpeta de paquetes.` }); continue; }
    try {
      if (def.sha256) { const h = (await hashFile(found.file, ['sha256'])).sha256; if (h !== def.sha256) throw new AetherisError('E_PROFILE', 'El archivo no coincide con el SHA-256 fijado para este perfil'); }
      const m = await openMrpack(found.file, policy);
      const problems = checkProfileRules(def, m);
      if (problems.length) throw new AetherisError('E_PROFILE', problems.join(' '));
      const fp = modFingerprint(m); fps.set(fp, [...(fps.get(fp) ?? []), def.name]);
      out.push({ ...base, status: 'ready', statusMessage: `Configurado (${found.source === 'user' ? 'paquete incorporado por ti' : 'paquete incluido'})`,
        pack: { name: m.index.name, versionId: m.index.versionId, minecraft: m.minecraft, loaderVersion: m.loaderVersion, modCount: modNames(m).length, sizeBytes: (await fs.stat(found.file)).size, modListFingerprint: fp, source: found.source } });
    } catch (e) { out.push({ ...base, status: 'invalid', statusMessage: `Paquete no válido: ${(e as Error).message}` }); }
  }
  for (const [, names] of fps) if (names.length > 1) warnings.push(`Estos perfiles tienen exactamente la misma lista de mods: ${names.join(' y ')}. Sus diferencias reales (si las hay) están solo en configuraciones o recursos.`);
  return { profiles: out, warnings, packsDir: paths.packsDir, userPacksDir: paths.userPacksDir };
}

/** Valida un .mrpack elegido por el usuario y lo copia a la carpeta de paquetes del usuario con el nombre esperado del perfil. */
export async function importPack(paths: ProfilesPaths, profileId: string, src: string, policy: NetworkPolicy = STRICT_POLICY): Promise<void> {
  const cfg = await loadConfig(paths.profilesJson);
  const def = cfg.profiles.find((p) => p.id === profileId);
  if (!def) throw new AetherisError('E_PROFILE', 'Perfil desconocido');
  const m = await openMrpack(src, policy);
  const problems = checkProfileRules(def, m);
  if (problems.length) throw new AetherisError('E_PROFILE', problems.join(' '));
  await fs.mkdir(paths.userPacksDir, { recursive: true });
  const dest = path.join(paths.userPacksDir, def.expectedFile); const tmp = `${dest}.${process.pid}.tmp`;
  await fs.copyFile(src, tmp); await fs.rename(tmp, dest);
}
