import path from 'node:path';
import fs from 'node:fs/promises';
import { AetherisError } from './errors';

const WIN_RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
/** Extensiones que nunca se instalan desde un paquete (scripts y ejecutables de Windows). */
export const BLOCKED_EXT = new Set(['.exe', '.bat', '.cmd', '.com', '.scr', '.msi', '.ps1', '.vbs', '.vbe', '.js', '.jse', '.wsf', '.lnk', '.dll', '.sh', '.reg', '.hta', '.cpl', '.jar.exe']);
/** Carpetas del usuario que el instalador no escribe ni borra jamás. */
export const PROTECTED_TOP = new Set(['saves', 'screenshots', 'logs', 'crash-reports', 'backups', '.aetheris']);
export const PROTECTED_FILES = new Set(['servers.dat', 'servers.dat_old', 'usercache.json', 'launcher_profiles.json']);

/** Valida una ruta relativa tipo mrpack/zip ('/' como separador). Devuelve la ruta normalizada. */
export function assertSafeRelative(rel: string, what = 'ruta'): string {
  if (typeof rel !== 'string' || rel.length === 0 || rel.length > 400) throw new AetherisError('E_PATH', `${what} vacía o demasiado larga`);
  if (rel.includes('\0')) throw new AetherisError('E_PATH', `${what} con carácter nulo: ${JSON.stringify(rel)}`);
  if (rel.includes('\\')) throw new AetherisError('E_PATH', `${what} con barra invertida no permitida: ${rel}`);
  if (rel.startsWith('/') || /^[a-zA-Z]:/.test(rel)) throw new AetherisError('E_PATH', `${what} absoluta no permitida: ${rel}`);
  const segs = rel.split('/').filter((s, i, a) => !(s === '' && i === a.length - 1)); // admite una '/' final (directorios)
  if (segs.length === 0) throw new AetherisError('E_PATH', `${what} vacía`);
  for (const s of segs) {
    if (s === '' || s === '.' || s === '..') throw new AetherisError('E_PATH', `${what} con segmento no permitido ("${s}"): ${rel}`);
    if (s.includes(':')) throw new AetherisError('E_PATH', `${what} con ':' no permitido: ${rel}`);
    if (/[<>"|?*\x00-\x1f]/.test(s)) throw new AetherisError('E_PATH', `${what} con caracteres no permitidos: ${rel}`);
    if (/[. ]$/.test(s)) throw new AetherisError('E_PATH', `${what} termina en punto o espacio: ${rel}`);
    if (WIN_RESERVED.test(s)) throw new AetherisError('E_PATH', `${what} usa un nombre reservado de Windows: ${rel}`);
  }
  return segs.join('/');
}

export function isProtected(rel: string): boolean {
  const segs = rel.toLowerCase().split('/');
  if (PROTECTED_TOP.has(segs[0]!)) return true;
  return segs.length === 1 && PROTECTED_FILES.has(segs[0]!);
}

/** Configuración personal: no se sobrescribe sin autorización. */
export function isPersonalConfig(rel: string): boolean {
  const l = rel.toLowerCase();
  return /^options[a-z]*\.txt$/.test(l) || l.startsWith('config/') || l.startsWith('shaderpacks/');
}

export function hasBlockedExtension(rel: string): boolean {
  const ext = path.posix.extname(rel.toLowerCase());
  return BLOCKED_EXT.has(ext);
}

const norm = (p: string) => (process.platform === 'win32' ? p.toLowerCase() : p);

/** Une root+rel garantizando que el resultado queda DENTRO de root (sin comprobar enlaces). */
export function resolveInside(root: string, rel: string): string {
  const safe = assertSafeRelative(rel);
  const base = path.resolve(root);
  const abs = path.resolve(base, ...safe.split('/'));
  if (!(norm(abs).startsWith(norm(base) + path.sep))) throw new AetherisError('E_PATH', `La ruta sale de la carpeta de destino: ${rel}`);
  return abs;
}

/** Comprueba que ningún ancestro existente de `abs` sea un enlace que apunte fuera de root. */
export async function assertNoSymlinkEscape(root: string, abs: string): Promise<void> {
  const realRoot = await fs.realpath(root);
  let cur = abs;
  for (;;) {
    try {
      const real = await fs.realpath(cur);
      if (!(norm(real) === norm(realRoot) || norm(real).startsWith(norm(realRoot) + path.sep))) {
        throw new AetherisError('E_PATH', 'Un enlace simbólico apunta fuera de la carpeta de destino');
      }
      return;
    } catch (e) {
      if (e instanceof AetherisError) throw e;
      const parent = path.dirname(cur);
      if (parent === cur) return;
      cur = parent;
    }
  }
}

/** Destinos que no se aceptan como carpeta de instalación (raíz de unidad, carpetas de sistema, home). */
export function assertAcceptableInstanceDir(dir: string, home?: string): string {
  const P = typeof dir === 'string' && (/^[a-zA-Z]:[\\/]/.test(dir) || dir.startsWith('\\\\')) ? path.win32 : path;
  if (typeof dir !== 'string' || !P.isAbsolute(dir)) throw new AetherisError('E_TARGET', 'La carpeta de destino debe ser una ruta absoluta');
  const abs = P.resolve(dir);
  if (P.parse(abs).root === abs) throw new AetherisError('E_TARGET', 'No se puede instalar en la raíz de una unidad');
  const lower = abs.toLowerCase().replace(/\//g, '\\');
  const forbidden = ['\\windows', '\\program files', '\\program files (x86)', '\\programdata', '\\system32'];
  if (/^[a-z]:\\/.test(lower) && forbidden.some((f) => lower.slice(2).startsWith(f))) throw new AetherisError('E_TARGET', 'No se puede instalar en una carpeta del sistema de Windows');
  if (home && norm(abs) === norm(P.resolve(home))) throw new AetherisError('E_TARGET', 'Elige una subcarpeta, no tu carpeta personal completa');
  return abs;
}

export function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new AetherisError('E_CANCELLED', 'Operación cancelada'));
    const t = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => { clearTimeout(t); reject(new AetherisError('E_CANCELLED', 'Operación cancelada')); }, { once: true });
  });
}
