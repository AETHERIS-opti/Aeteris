/** Detección del sistema. Todo el acceso al sistema pasa por DetectContext para poder probarlo con contextos falsos. */
import os from 'node:os';
import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import type { JavaCheck, JavaInstall, JavaRequirement, LauncherCandidate, LauncherInstance, SystemInfo } from '../shared/types';

export interface DetectContext {
  platform: NodeJS.Platform; arch: string; release: string; totalmem: number; freemem: number; cpus: number;
  env: Record<string, string | undefined>; homedir: string;
  exists(p: string): Promise<boolean>; readdir(p: string): Promise<string[]>; javaVersionOutput(javaPath: string): Promise<string>;
}

export function realContext(): DetectContext {
  return {
    platform: process.platform, arch: process.arch, release: os.release(), totalmem: os.totalmem(), freemem: os.freemem(), cpus: os.cpus().length,
    env: process.env, homedir: os.homedir(),
    exists: (p) => fs.stat(p).then(() => true, () => false),
    readdir: (p) => fs.readdir(p).catch(() => []),
    javaVersionOutput: (j) => new Promise((resolve, reject) => {
      // execFile sin shell: el nombre del ejecutable nunca se interpreta como comando
      execFile(j, ['-version'], { timeout: 6000, windowsHide: true }, (err, stdout, stderr) => (err && !stderr && !stdout ? reject(err) : resolve(`${stderr}\n${stdout}`)));
    }),
  };
}

export function parseJavaVersion(out: string): { version: string; major: number } | null {
  const m = /version "([^"]+)"/.exec(out) ?? /^(?:openjdk|java)\s+([0-9][^\s]*)/m.exec(out);
  if (!m) return null;
  const v = m[1]!;
  const parts = v.split(/[._+-]/);
  const major = parts[0] === '1' ? Number(parts[1]) : Number(parts[0]);
  return Number.isFinite(major) && major > 0 ? { version: v, major } : null;
}

export function windowsName(release: string): { name: string; build: number | null; supported: boolean } {
  const m = /^(\d+)\.(\d+)\.(\d+)/.exec(release);
  if (!m) return { name: 'Windows (versión desconocida)', build: null, supported: true };
  const major = Number(m[1]), build = Number(m[3]);
  if (major >= 10) return { name: build >= 22000 ? 'Windows 11' : 'Windows 10', build, supported: build >= 17763 };
  return { name: `Windows ${m[1]}.${m[2]} (antiguo)`, build, supported: false };
}

/** Versión mínima de Java por versión de Minecraft. 26.3 → 25 consta en las fuentes consultadas; el resto sigue la tabla conocida de Mojang. */
export function requiredJava(mc: string): JavaRequirement {
  const n = mc.split(/[.-]/).map((x) => parseInt(x, 10));
  const a = n[0] ?? 0, b = n[1] ?? 0, c = n[2] ?? 0;
  if (a >= 26) return { major: 25, confirmed: mc.startsWith('26.3'), note: mc.startsWith('26.3') ? 'Minecraft 26.3 requiere Java 25' : 'Extrapolado de 26.3: comprueba el requisito de tu versión' };
  if (a === 1 && (b > 20 || (b === 20 && c >= 5))) return { major: 21, confirmed: true, note: 'Minecraft 1.20.5 o posterior requiere Java 21' };
  if (a === 1 && b >= 18) return { major: 17, confirmed: true, note: 'Minecraft 1.18–1.20.4 requiere Java 17' };
  if (a === 1 && b === 17) return { major: 16, confirmed: true, note: 'Minecraft 1.17 requiere Java 16' };
  return { major: 8, confirmed: true, note: 'Minecraft anterior a 1.17 funciona con Java 8' };
}

export function checkJava(java: JavaInstall[], mc: string): JavaCheck {
  const required = requiredJava(mc);
  const best = [...java].filter((j) => j.major >= required.major).sort((x, y) => x.major - y.major)[0] ?? null;
  if (best) return { ok: true, required, best, message: `Java ${best.version} detectado (se necesita ${required.major} o superior)` };
  const top = [...java].sort((x, y) => y.major - x.major)[0];
  return { ok: false, required, best: null, message: top
    ? `Se necesita Java ${required.major} o superior para Minecraft ${mc}; el más reciente detectado es ${top.version}. El launcher oficial incluye su propio Java y no depende de este.`
    : `No se detectó Java instalado. Minecraft ${mc} necesita Java ${required.major}; el launcher oficial lo descarga por sí mismo.` };
}

async function listJavaCandidates(ctx: DetectContext): Promise<Array<{ path: string; source: string }>> {
  const w = ctx.platform === 'win32'; const exe = w ? 'java.exe' : 'java';
  const out: Array<{ path: string; source: string }> = [];
  if (ctx.env.JAVA_HOME) out.push({ path: path.join(ctx.env.JAVA_HOME, 'bin', exe), source: 'JAVA_HOME' });
  out.push({ path: 'java', source: 'PATH' });
  if (w) {
    const pf = [ctx.env.ProgramFiles, ctx.env['ProgramFiles(x86)']].filter(Boolean) as string[];
    for (const root of pf) for (const vendor of ['Java', 'Eclipse Adoptium', 'Microsoft', 'Zulu', 'Amazon Corretto', 'BellSoft', 'Semeru']) {
      const dir = path.join(root, vendor);
      for (const d of await ctx.readdir(dir)) out.push({ path: path.join(dir, d, 'bin', exe), source: vendor });
    }
    const rts = [path.join(ctx.env.APPDATA ?? '', '.minecraft', 'runtime'), path.join(ctx.env.LOCALAPPDATA ?? '', 'Packages', 'Microsoft.4297127D64EC6_8wekyb3d8bbwe', 'LocalCache', 'Local', 'runtime')];
    for (const rt of rts) for (const comp of await ctx.readdir(rt)) for (const plat of await ctx.readdir(path.join(rt, comp))) for (const inner of await ctx.readdir(path.join(rt, comp, plat)))
      out.push({ path: path.join(rt, comp, plat, inner, 'bin', exe), source: 'Java del launcher oficial' });
  }
  return out;
}

export async function detectJava(ctx: DetectContext): Promise<JavaInstall[]> {
  const found = new Map<string, JavaInstall>();
  for (const c of await listJavaCandidates(ctx)) {
    if (c.path !== 'java' && !(await ctx.exists(c.path))) continue;
    try {
      const p = parseJavaVersion(await ctx.javaVersionOutput(c.path));
      if (p) { const k = `${p.version}|${c.path === 'java' ? 'PATH' : c.path}`; if (!found.has(k)) found.set(k, { path: c.path, version: p.version, major: p.major, source: c.source }); }
    } catch { /* java no ejecutable: se ignora */ }
  }
  return [...found.values()].sort((a, b) => b.major - a.major);
}

async function instancesIn(ctx: DetectContext, dir: string, gameSub: string[]): Promise<LauncherInstance[]> {
  const out: LauncherInstance[] = [];
  for (const name of await ctx.readdir(dir)) {
    const p = path.join(dir, name); let game = p;
    for (const s of gameSub) if (await ctx.exists(path.join(p, s))) { game = path.join(p, s); break; }
    out.push({ name, path: p, gameDir: game });
  }
  return out;
}

export async function detectLaunchers(ctx: DetectContext): Promise<LauncherCandidate[]> {
  const ad = ctx.env.APPDATA ?? path.join(ctx.homedir, 'AppData', 'Roaming');
  const specs: Array<{ kind: LauncherCandidate['kind']; label: string; dir: string; instDir?: string; gameSub: string[]; note: string }> = [
    { kind: 'official', label: 'Launcher oficial de Minecraft (.minecraft)', dir: path.join(ad, '.minecraft'), gameSub: [], note: 'AETHERIS puede crear un perfil propio con su carpeta de juego aislada. No verificado en un Windows real.' },
    { kind: 'prism', label: 'Prism Launcher', dir: path.join(ad, 'PrismLauncher'), instDir: path.join(ad, 'PrismLauncher', 'instances'), gameSub: ['minecraft', '.minecraft'], note: 'Solo se copian archivos a la carpeta de la instancia; el cargador Fabric debe estar ya configurado en la instancia. No verificado.' },
    { kind: 'modrinth', label: 'Modrinth App', dir: path.join(ad, 'ModrinthApp'), instDir: path.join(ad, 'ModrinthApp', 'profiles'), gameSub: [], note: 'Solo se copian archivos a la carpeta del perfil. Estructura no verificada.' },
    { kind: 'curseforge', label: 'CurseForge', dir: path.join(ctx.homedir, 'curseforge', 'minecraft'), instDir: path.join(ctx.homedir, 'curseforge', 'minecraft', 'Instances'), gameSub: [], note: 'Solo se copian archivos a la carpeta de la instancia. No verificado.' },
    { kind: 'gdlauncher', label: 'GDLauncher', dir: path.join(ad, 'gdlauncher_next'), instDir: path.join(ad, 'gdlauncher_next', 'instances'), gameSub: [], note: 'Solo se copian archivos a la carpeta de la instancia. No verificado.' },
  ];
  const out: LauncherCandidate[] = [];
  for (const s of specs) {
    const exists = await ctx.exists(s.dir);
    out.push({ kind: s.kind, label: s.label, path: s.dir, exists, instances: exists && s.instDir ? await instancesIn(ctx, s.instDir, s.gameSub) : [], verified: false, note: s.note });
  }
  return out;
}

export async function detectSystem(ctx: DetectContext = realContext()): Promise<SystemInfo> {
  const warnings: string[] = [];
  const isWin = ctx.platform === 'win32';
  const w = isWin ? windowsName(ctx.release) : { name: ctx.platform, build: null, supported: false };
  if (!isWin) warnings.push('AETHERIS NEXUS INSTALLER está diseñado para Windows x64; en otros sistemas solo es útil para desarrollo.');
  else if (!w.supported) warnings.push(`${w.name} no está soportado; se recomienda Windows 10 (1809 o posterior) o Windows 11.`);
  if (ctx.arch !== 'x64') warnings.push(`Arquitectura ${ctx.arch}: el instalador se compila para x64.`);
  const totalMB = Math.round(ctx.totalmem / 1048576), freeMB = Math.round(ctx.freemem / 1048576);
  if (totalMB < 4096) warnings.push(`Solo hay ${totalMB} MB de RAM: Minecraft puede ir justo. No se fija ninguna cantidad de RAM por ti.`);
  const java = await detectJava(ctx);
  const launchers = await detectLaunchers(ctx);
  const official = launchers.find((l) => l.kind === 'official');
  return {
    os: { platform: ctx.platform, name: w.name, release: ctx.release, build: w.build, arch: ctx.arch, supported: isWin && w.supported && ctx.arch === 'x64' },
    ram: { totalMB, freeMB }, cpuCores: ctx.cpus, java,
    minecraftDir: official ? { path: official.path, exists: official.exists } : null, launchers, warnings,
  };
}
