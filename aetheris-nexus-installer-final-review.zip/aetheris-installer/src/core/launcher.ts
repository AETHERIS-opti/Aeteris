/**
 * Integración con el launcher OFICIAL de Minecraft: instala el perfil de Fabric y crea una entrada propia en launcher_profiles.json
 * cuya carpeta de juego (gameDir) es la instancia de AETHERIS, de modo que NO se mezcla con el .minecraft normal del usuario.
 * Se hace copia de seguridad de launcher_profiles.json antes de tocarlo. NO verificado contra el launcher real de Windows.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { AetherisError } from './errors';
import { writeJsonAtomic } from './registry';
import type { LauncherInfo } from './registry';

export const FABRIC_META = 'https://meta.fabricmc.net';
export interface LauncherOptions { fetchImpl?: typeof fetch; metaBase?: string; now?: () => Date }

const SAFE_ID = /^[A-Za-z0-9._+-]{1,80}$/;
const sanitizeKey = (s: string) => s.replace(/[^A-Za-z0-9_-]/g, '-').slice(0, 40);

export async function fetchFabricProfile(mc: string, loader: string, o: LauncherOptions = {}): Promise<{ id: string; json: Record<string, unknown> }> {
  if (!/^[0-9A-Za-z._-]{1,30}$/.test(mc) || !/^[0-9A-Za-z._+-]{1,30}$/.test(loader)) throw new AetherisError('E_LAUNCHER', 'Versión de Minecraft o de Fabric con caracteres no válidos');
  const url = `${o.metaBase ?? FABRIC_META}/v2/versions/loader/${encodeURIComponent(mc)}/${encodeURIComponent(loader)}/profile/json`;
  let res: Response;
  try { res = await (o.fetchImpl ?? fetch)(url, { headers: { 'User-Agent': 'AETHERIS-NEXUS-INSTALLER/1.0' }, signal: AbortSignal.timeout(20_000) }); }
  catch (e) { throw new AetherisError('E_LAUNCHER', `No se pudo contactar con el servicio oficial de Fabric: ${(e as Error).message}`); }
  if (!res.ok) throw new AetherisError('E_LAUNCHER', `Fabric no ofrece un perfil para Minecraft ${mc} con Fabric Loader ${loader} (respuesta ${res.status}). Comprueba que esas versiones existen.`);
  const json = await res.json() as Record<string, unknown>;
  const id = json.id;
  if (typeof id !== 'string' || !SAFE_ID.test(id)) throw new AetherisError('E_LAUNCHER', 'El perfil de Fabric recibido no tiene un identificador válido');
  if (json.inheritsFrom !== mc) throw new AetherisError('E_LAUNCHER', `El perfil de Fabric no corresponde a Minecraft ${mc}`);
  return { id, json };
}

interface LauncherProfiles { profiles?: Record<string, Record<string, unknown>>; [k: string]: unknown }

export async function installOfficialLauncherProfile(a: {
  minecraftDir: string; gameDir: string; profileId: string; profileName: string; minecraft: string; loaderVersion: string;
}, o: LauncherOptions = {}): Promise<LauncherInfo> {
  const lp = path.join(a.minecraftDir, 'launcher_profiles.json');
  let raw: string;
  try { raw = await fs.readFile(lp, 'utf8'); } catch { throw new AetherisError('E_LAUNCHER', 'No se encontró launcher_profiles.json. Abre el launcher oficial de Minecraft al menos una vez y vuelve a intentarlo.'); }
  let data: LauncherProfiles;
  try { data = JSON.parse(raw) as LauncherProfiles; } catch { throw new AetherisError('E_LAUNCHER', 'launcher_profiles.json está dañado; no se ha modificado'); }
  if (typeof data !== 'object' || data === null || Array.isArray(data)) throw new AetherisError('E_LAUNCHER', 'launcher_profiles.json tiene un formato inesperado; no se ha modificado');
  const { id, json } = await fetchFabricProfile(a.minecraft, a.loaderVersion, o);
  // 1) archivo de versión de Fabric (si no existe ya)
  const vdir = path.join(a.minecraftDir, 'versions', id); const vfile = path.join(vdir, `${id}.json`);
  let created = false;
  try { await fs.stat(vfile); } catch { await fs.mkdir(vdir, { recursive: true }); await writeJsonAtomic(vfile, json); created = true; }
  // 2) copia de seguridad y entrada de perfil
  const bdir = path.join(a.gameDir, '.aetheris', 'launcher-backups'); await fs.mkdir(bdir, { recursive: true });
  const stamp = (o.now?.() ?? new Date()).toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
  await fs.copyFile(lp, path.join(bdir, `launcher_profiles.${stamp}.json`));
  const key = `aetheris-${sanitizeKey(a.profileId)}`;
  const profiles = (data.profiles && typeof data.profiles === 'object' ? data.profiles : {}) as Record<string, Record<string, unknown>>;
  const nowIso = (o.now?.() ?? new Date()).toISOString();
  profiles[key] = { ...(profiles[key] ?? {}), name: a.profileName, type: 'custom', created: (profiles[key]?.created as string | undefined) ?? nowIso, lastUsed: nowIso, icon: 'Grass', lastVersionId: id, gameDir: a.gameDir };
  data.profiles = profiles;
  await writeJsonAtomic(lp, data);
  return { kind: 'official', minecraftDir: a.minecraftDir, versionId: id, profileKey: key, createdVersionFile: created };
}

/** Quita SOLO la entrada creada por AETHERIS (y el archivo de versión si lo creamos nosotros y nadie más lo usa). */
export async function removeOfficialLauncherProfile(info: LauncherInfo, gameDir: string, o: LauncherOptions = {}): Promise<{ removedProfile: boolean; removedVersion: boolean }> {
  const lp = path.join(info.minecraftDir, 'launcher_profiles.json');
  let data: LauncherProfiles;
  try { data = JSON.parse(await fs.readFile(lp, 'utf8')) as LauncherProfiles; } catch { return { removedProfile: false, removedVersion: false }; }
  const profiles = data.profiles ?? {};
  if (!(info.profileKey in profiles)) return { removedProfile: false, removedVersion: false };
  const bdir = path.join(gameDir, '.aetheris', 'launcher-backups'); await fs.mkdir(bdir, { recursive: true });
  const stamp = (o.now?.() ?? new Date()).toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
  await fs.copyFile(lp, path.join(bdir, `launcher_profiles.${stamp}.before-remove.json`));
  delete profiles[info.profileKey]; data.profiles = profiles;
  await writeJsonAtomic(lp, data);
  let removedVersion = false;
  const stillUsed = Object.values(profiles).some((p) => p.lastVersionId === info.versionId);
  if (info.createdVersionFile && !stillUsed && SAFE_ID.test(info.versionId)) { await fs.rm(path.join(info.minecraftDir, 'versions', info.versionId), { recursive: true, force: true }); removedVersion = true; }
  return { removedProfile: true, removedVersion };
}
