/** Errores con código estable: la interfaz los traduce a mensajes comprensibles. */
export type ErrorCode =
  | 'E_ZIP' | 'E_MRPACK' | 'E_LOADER' | 'E_PATH' | 'E_PROTECTED' | 'E_HASH' | 'E_DOWNLOAD' | 'E_CANCELLED'
  | 'E_TXN_PENDING' | 'E_ROLLBACK' | 'E_NOT_INSTALLED' | 'E_ALREADY_INSTALLED' | 'E_BACKUP' | 'E_LAUNCHER'
  | 'E_TARGET' | 'E_BUSY' | 'E_PROFILE' | 'E_IO';

export class AetherisError extends Error {
  readonly code: ErrorCode;
  readonly details?: unknown;
  constructor(code: ErrorCode, message: string, details?: unknown) {
    super(message);
    this.name = 'AetherisError';
    this.code = code;
    this.details = details;
  }
}

export function isAetherisError(e: unknown): e is AetherisError {
  return e instanceof AetherisError;
}

/** Texto amable para el usuario (sin rutas completas ni trazas). */
export function userMessage(e: unknown): string {
  if (isAetherisError(e)) return e.message;
  if (e instanceof Error) return `Error inesperado: ${e.message}`;
  return 'Error desconocido';
}
