import fs from 'node:fs';
import path from 'node:path';

export type Level = 'info' | 'warn' | 'error';
export interface LogEntry { t: string; level: Level; msg: string; data?: unknown }

/** Registro en archivo (JSON por línea, rotación a 1 MB) + búfer en memoria para la pantalla de registros. */
export class Logger {
  private ring: LogEntry[] = [];
  constructor(private file?: string, private maxBytes = 1_000_000) {
    if (file) fs.mkdirSync(path.dirname(file), { recursive: true });
  }
  private write(level: Level, msg: string, data?: unknown) {
    const e: LogEntry = { t: new Date().toISOString(), level, msg, ...(data !== undefined ? { data } : {}) };
    this.ring.push(e);
    if (this.ring.length > 500) this.ring.shift();
    if (!this.file) return;
    try {
      if (fs.existsSync(this.file) && fs.statSync(this.file).size > this.maxBytes) fs.renameSync(this.file, this.file + '.1');
      fs.appendFileSync(this.file, JSON.stringify(e) + '\n');
    } catch { /* el registro nunca debe romper una operación */ }
  }
  info(msg: string, data?: unknown) { this.write('info', msg, data); }
  warn(msg: string, data?: unknown) { this.write('warn', msg, data); }
  error(msg: string, data?: unknown) { this.write('error', msg, data); }
  tail(n = 200): LogEntry[] { return this.ring.slice(-n); }
}
