import fs from 'node:fs/promises';
import path from 'node:path';
import { AetherisError } from './errors';
import { hashFile } from './hash';
import { isProtected, resolveInside, assertNoSymlinkEscape } from './paths';
import { AETH, backupsRoot, readRecord, recordPath, writeJsonAtomic, type InstallRecord } from './registry';

export interface BackupMeta {
  id: string; createdAt: string; reason: string; kind: 'auto' | 'manual';
  files: Array<{ rel: string; sha256: string; size: number }>;
  hasRecord: boolean;
}
const filesDir = (instance: string, id: string) => path.join(backupsRoot(instance), id, 'files');
const metaPath = (instance: string, id: string) => path.join(backupsRoot(instance), id, 'backup.json');

export const newId = (prefix: string, now = new Date()) => `${prefix}-${now.toISOString().replace(/[-:TZ.]/g, '').slice(0, 14)}-${Math.random().toString(36).slice(2, 6)}`;

/** Copia a la carpeta de respaldo el archivo actual `rel` (si existe). Devuelve su ficha o null. */
export async function backupOne(instance: string, id: string, rel: string): Promise<{ rel: string; sha256: string; size: number } | null> {
  const src = resolveInside(instance, rel);
  let st; try { st = await fs.lstat(src); } catch (e) { if ((e as NodeJS.ErrnoException).code === 'ENOENT') return null; throw e; }
  if (!st.isFile()) return null;
  const dst = path.join(filesDir(instance, id), ...rel.split('/'));
  await fs.mkdir(path.dirname(dst), { recursive: true });
  await fs.copyFile(src, dst);
  return { rel, sha256: (await hashFile(src, ['sha256'])).sha256!, size: st.size };
}

export async function writeMeta(instance: string, meta: BackupMeta): Promise<void> { await writeJsonAtomic(metaPath(instance, meta.id), meta); }

export async function restoreOneFromBackup(instance: string, id: string, rel: string): Promise<void> {
  const src = path.join(filesDir(instance, id), ...rel.split('/'));
  const dst = resolveInside(instance, rel);
  await assertNoSymlinkEscape(instance, dst);
  await fs.mkdir(path.dirname(dst), { recursive: true });
  await fs.copyFile(src, dst);
}

async function walk(dir: string, base: string, out: string[]): Promise<void> {
  let items; try { items = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
  for (const it of items) {
    const p = path.join(dir, it.name);
    if (it.isDirectory()) await walk(p, base, out);
    else if (it.isFile()) out.push(path.relative(base, p).split(path.sep).join('/'));
  }
}

/** Copia de seguridad manual: archivos instalados por AETHERIS + configuración personal (options*.txt, config/). Nunca mundos ni capturas. */
export async function createManualBackup(instance: string, reason = 'Copia manual'): Promise<BackupMeta> {
  const rec = await readRecord(instance);
  if (!rec) throw new AetherisError('E_NOT_INSTALLED', 'No hay ninguna instalación de AETHERIS en esta carpeta');
  const rels = new Set<string>(Object.keys(rec.files));
  const cfg: string[] = []; await walk(path.join(instance, 'config'), instance, cfg); cfg.forEach((r) => rels.add(r));
  for (const f of await fs.readdir(instance).catch(() => [] as string[])) if (/^options[a-z]*\.txt$/i.test(f)) rels.add(f);
  const id = newId('manual');
  const files: BackupMeta['files'] = [];
  for (const rel of [...rels].sort()) {
    if (isProtected(rel)) continue;
    const e = await backupOne(instance, id, rel); if (e) files.push(e);
  }
  await fs.mkdir(path.join(backupsRoot(instance), id), { recursive: true });
  await fs.copyFile(recordPath(instance), path.join(backupsRoot(instance), id, 'install.json'));
  const meta: BackupMeta = { id, createdAt: new Date().toISOString(), reason, kind: 'manual', files, hasRecord: true };
  await writeMeta(instance, meta);
  return meta;
}

export async function listBackups(instance: string): Promise<BackupMeta[]> {
  let dirs: string[]; try { dirs = await fs.readdir(backupsRoot(instance)); } catch { return []; }
  const out: BackupMeta[] = [];
  for (const d of dirs) { try { out.push(JSON.parse(await fs.readFile(metaPath(instance, d), 'utf8')) as BackupMeta); } catch { /* sin metadatos: respaldo de transacción */ } }
  return out.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export interface RestoreResult { restored: number; removed: number; preRestoreBackupId: string }
/** Restaura una copia manual. Antes guarda el estado actual de todo lo que va a tocar. No toca mundos ni rutas protegidas. */
export async function restoreBackup(instance: string, id: string): Promise<RestoreResult> {
  if (!/^[a-z]+-\d{14}-[a-z0-9]{4}$/.test(id)) throw new AetherisError('E_BACKUP', 'Identificador de copia inválido');
  let meta: BackupMeta;
  try { meta = JSON.parse(await fs.readFile(metaPath(instance, id), 'utf8')) as BackupMeta; } catch { throw new AetherisError('E_BACKUP', 'La copia de seguridad no existe o está dañada'); }
  if (meta.kind !== 'manual' || !meta.hasRecord) throw new AetherisError('E_BACKUP', 'Solo se pueden restaurar copias manuales completas');
  const snapshot = JSON.parse(await fs.readFile(path.join(backupsRoot(instance), id, 'install.json'), 'utf8')) as InstallRecord;
  // verificar la propia copia antes de tocar nada
  for (const f of meta.files) {
    const p = path.join(filesDir(instance, id), ...f.rel.split('/'));
    const h = await hashFile(p, ['sha256']).catch(() => null);
    if (!h || h.sha256 !== f.sha256) throw new AetherisError('E_BACKUP', `La copia está dañada (${f.rel}); no se ha modificado nada`);
  }
  const current = await readRecord(instance);
  const pre = newId('prerestore');
  const preFiles: BackupMeta['files'] = [];
  const keep = new Set(meta.files.map((f) => f.rel));
  const toRemove = current ? Object.keys(current.files).filter((r) => !keep.has(r) && !(r in snapshot.files)) : [];
  for (const f of meta.files) { if (isProtected(f.rel)) continue; const e = await backupOne(instance, pre, f.rel); if (e) preFiles.push(e); }
  for (const r of toRemove) { const e = await backupOne(instance, pre, r); if (e) preFiles.push(e); }
  await fs.mkdir(path.join(backupsRoot(instance), pre), { recursive: true });
  if (current) await fs.copyFile(recordPath(instance), path.join(backupsRoot(instance), pre, 'install.json'));
  await writeMeta(instance, { id: pre, createdAt: new Date().toISOString(), reason: `Estado previo a restaurar ${id}`, kind: 'auto', files: preFiles, hasRecord: !!current });
  let restored = 0, removed = 0;
  for (const f of meta.files) { if (isProtected(f.rel)) continue; await restoreOneFromBackup(instance, id, f.rel); restored++; }
  for (const r of toRemove) { await fs.rm(resolveInside(instance, r), { force: true }); removed++; }
  await fs.copyFile(path.join(backupsRoot(instance), id, 'install.json'), recordPath(instance));
  return { restored, removed, preRestoreBackupId: pre };
}
void AETH;
