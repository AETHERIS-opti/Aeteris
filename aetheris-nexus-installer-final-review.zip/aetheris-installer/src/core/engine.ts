/**
 * Motor de instalación transaccional de .mrpack.
 *   preparar (descargar/extraer a una carpeta temporal dentro de .aetheris) -> verificar -> respaldar -> aplicar -> registrar.
 * Si algo falla ANTES de aplicar, el destino no cambia. Si falla durante la aplicación, se revierte con el diario (txn.json).
 * Si el proceso muere a mitad, el diario queda en disco y la siguiente operación lo informa y permite revertir.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { AetherisError } from './errors';
import { hashFile } from './hash';
import { downloadVerified, matchesExpected } from './download';
import { openMrpack, STRICT_POLICY, type MrpackFile, type NetworkPolicy, type OpenedMrpack } from './mrpack';
import type { ZipEntry } from './zip';
import { assertAcceptableInstanceDir, assertNoSymlinkEscape, isPersonalConfig, isProtected, resolveInside } from './paths';
import { backupOne, newId, writeMeta, restoreOneFromBackup, type BackupMeta } from './backup';
import {
  AETH, aethDir, backupsRoot, packCopyPath, readRecord, readTxn, recordPath, stagingRoot, txnPath, writeJsonAtomic,
  type InstallRecord, type TrackedFile, type Txn,
} from './registry';
import type { Logger } from './logger';

export type Phase = 'validate' | 'download' | 'extract' | 'commit' | 'verify' | 'cleanup' | 'done';
export interface ProgressEvent { op: string; phase: Phase; message: string; current?: number; total?: number; bytes?: number; totalBytes?: number; file?: string; level?: 'info' | 'warn' | 'error' }
export interface EngineOptions {
  onProgress?: (e: ProgressEvent) => void; signal?: AbortSignal; policy?: NetworkPolicy; fetchImpl?: typeof fetch;
  retries?: number; backoffMs?: number; concurrency?: number; log?: Logger; home?: string;
  /** Solo para pruebas: provoca un fallo o un "corte" tras N cambios aplicados. */
  hooks?: { failAfter?: number; crashAfter?: number };
}
/** Simula que el proceso muere a mitad de la aplicación: NO se revierte (el diario queda en disco). Solo pruebas. */
export class SimulatedCrash extends Error {}
export interface InstallOptions extends EngineOptions {
  instanceDir: string; mrpackPath: string; profileId: string;
  userConfigPolicy?: 'keep' | 'replace'; includeOptional?: boolean;
}
export interface OpResult {
  op: string; installed: number; unchanged: number; removed: string[];
  skippedUserConfigs: string[]; keptModified: string[]; duplicates: string[]; backupId?: string; profileId?: string; packVersionId?: string;
}

const busy = new Set<string>();
const key = (p: string) => (process.platform === 'win32' ? p.toLowerCase() : p);

async function withLock<T>(instance: string, fn: () => Promise<T>): Promise<T> {
  const k = key(path.resolve(instance));
  if (busy.has(k)) throw new AetherisError('E_BUSY', 'Ya hay una operación en curso sobre esta carpeta');
  busy.add(k);
  try { return await fn(); } finally { busy.delete(k); }
}

const emit = (o: EngineOptions, op: string, phase: Phase, message: string, extra: Partial<ProgressEvent> = {}) => {
  o.onProgress?.({ op, phase, message, ...extra });
  const lvl = extra.level ?? 'info';
  o.log?.[lvl](`[${op}] ${message}`);
};
const throwIfAborted = (s?: AbortSignal) => { if (s?.aborted) throw new AetherisError('E_CANCELLED', 'Operación cancelada por el usuario'); };

async function pool<T>(items: T[], n: number, fn: (x: T) => Promise<void>): Promise<void> {
  let i = 0;
  await Promise.all(Array.from({ length: Math.max(1, Math.min(n, items.length)) }, async () => { for (;;) { const k = i++; if (k >= items.length) return; await fn(items[k]!); } }));
}

// ---------------------------------------------------------------- plan
interface Planned { rel: string; source: 'download' | 'override'; file?: MrpackFile; entry?: ZipEntry }
export function planFiles(m: OpenedMrpack, includeOptional = false): Map<string, Planned> {
  const plan = new Map<string, Planned>();
  for (const f of m.index.files) {
    if (f.env.client === 'unsupported') continue;
    if (f.env.client === 'optional' && !includeOptional) continue;
    plan.set(f.path, { rel: f.path, source: 'download', file: f });
  }
  for (const [rel, entry] of m.overrides) plan.set(rel, { rel, source: 'override', entry }); // overrides se aplican después de las descargas
  return plan;
}

const baseId = (fn: string) => fn.toLowerCase().replace(/\.jar$/, '').split(/[-_+](?=v?\d)/)[0]!.replace(/[-_](fabric|mc\d.*)$/, '');
async function findDuplicates(instance: string, incoming: string[], tracked: Set<string>): Promise<string[]> {
  let have: string[]; try { have = await fs.readdir(path.join(instance, 'mods')); } catch { return []; }
  const inc = new Map(incoming.filter((r) => r.startsWith('mods/')).map((r) => [baseId(path.basename(r)), r]));
  return have.filter((f) => f.toLowerCase().endsWith('.jar') && !tracked.has(`mods/${f}`) && inc.has(baseId(f)) && inc.get(baseId(f)) !== `mods/${f}`).map((f) => `mods/${f}`);
}

// ---------------------------------------------------------------- preparación
interface Staged { rel: string; abs: string; tracked: TrackedFile }
async function stage(instance: string, stageId: string, m: OpenedMrpack, plan: Planned[], o: EngineOptions, op: string): Promise<Map<string, Staged>> {
  const root = path.join(stagingRoot(instance, stageId), 'files');
  await fs.mkdir(root, { recursive: true });
  const out = new Map<string, Staged>();
  const dls = plan.filter((p) => p.source === 'download'), ovs = plan.filter((p) => p.source === 'override');
  const totalBytes = dls.reduce((s, p) => s + (p.file?.fileSize ?? 0), 0);
  let doneFiles = 0, bytes = 0; const failed: Array<{ rel: string; message: string }> = [];
  emit(o, op, 'download', `Descargando ${dls.length} archivos…`, { current: 0, total: dls.length, totalBytes });
  await pool(dls, o.concurrency ?? 4, async (p) => {
    throwIfAborted(o.signal);
    const dest = resolveInside(root, p.rel); const f = p.file!;
    try {
      if (!(await matchesExpected(dest, { ...f.hashes, ...(f.fileSize !== undefined ? { size: f.fileSize } : {}) }))) {
        await fs.rm(dest, { force: true });
        await downloadVerified(f.downloads, dest, {
          expected: { ...f.hashes, ...(f.fileSize !== undefined ? { size: f.fileSize } : {}) }, retries: o.retries ?? 3, backoffMs: o.backoffMs ?? 600,
          policy: o.policy ?? STRICT_POLICY, ...(o.signal ? { signal: o.signal } : {}), ...(o.fetchImpl ? { fetchImpl: o.fetchImpl } : {}),
          onBytes: (n) => { bytes += n; o.onProgress?.({ op, phase: 'download', message: 'Descargando…', current: doneFiles, total: dls.length, bytes, totalBytes, file: p.rel }); },
          onRetry: (a, e) => emit(o, op, 'download', `Reintento ${a} de ${p.rel}: ${e.message}`, { level: 'warn', file: p.rel }),
        });
      }
      const h = await hashFile(dest, ['sha256']); // sha1/sha512 ya se verificaron en streaming durante la descarga
      out.set(p.rel, { rel: p.rel, abs: dest, tracked: { sha256: h.sha256!, size: (await fs.stat(dest)).size, source: 'download', ...(f.hashes.sha1 ? { sha1: f.hashes.sha1 } : {}), ...(f.hashes.sha512 ? { sha512: f.hashes.sha512 } : {}), urls: f.downloads } });
      doneFiles++; emit(o, op, 'download', `Descargado ${p.rel}`, { current: doneFiles, total: dls.length, file: p.rel, bytes, totalBytes });
    } catch (e) {
      if (e instanceof AetherisError && e.code === 'E_CANCELLED') throw e;
      failed.push({ rel: p.rel, message: (e as Error).message });
      emit(o, op, 'download', `Falló ${p.rel}: ${(e as Error).message}`, { level: 'error', file: p.rel });
    }
  });
  throwIfAborted(o.signal);
  if (failed.length) throw new AetherisError('E_DOWNLOAD', `No se pudieron descargar ${failed.length} de ${dls.length} archivos. No se ha modificado nada en tu instalación. Puedes reintentar: lo ya descargado y verificado se reutiliza.`, { failed });
  emit(o, op, 'extract', `Extrayendo ${ovs.length} archivos del paquete…`, { current: 0, total: ovs.length });
  let n = 0;
  for (const p of ovs) {
    throwIfAborted(o.signal);
    const dest = resolveInside(root, p.rel);
    await fs.rm(dest, { force: true });
    await m.zip.extract(p.entry!, dest);
    const h = await hashFile(dest, ['sha256']);
    out.set(p.rel, { rel: p.rel, abs: dest, tracked: { sha256: h.sha256!, size: (await fs.stat(dest)).size, source: 'override' } });
    emit(o, op, 'extract', `Extraído ${p.rel}`, { current: ++n, total: ovs.length, file: p.rel });
  }
  return out;
}

// ---------------------------------------------------------------- aplicación (diario + reversión)
interface ApplyInput {
  instance: string; op: string; staged: Map<string, Staged>; prev: InstallRecord | null; userConfigPolicy: 'keep' | 'replace';
  staleRels: string[]; makeRecord: (kept: Record<string, TrackedFile>) => InstallRecord; o: EngineOptions;
  onlyRels?: Set<string>;
}
interface ApplyResult { installed: number; unchanged: number; removed: string[]; skippedUserConfigs: string[]; keptModified: string[]; backupId?: string }

async function sha256Of(file: string): Promise<string | null> {
  try { const st = await fs.lstat(file); if (st.isSymbolicLink()) throw new AetherisError('E_PATH', 'Hay un enlace simbólico donde debe ir un archivo'); if (st.isDirectory()) throw new AetherisError('E_TARGET', 'Hay una carpeta donde debe ir un archivo'); return (await hashFile(file, ['sha256'])).sha256!; }
  catch (e) { if ((e as NodeJS.ErrnoException).code === 'ENOENT') return null; throw e; }
}

async function apply(a: ApplyInput): Promise<ApplyResult> {
  const { instance, op, staged, prev, o } = a;
  const txid = newId('txn');
  const skipped: string[] = [], keptModified: string[] = [], removed: string[] = [];
  const actions: Array<{ rel: string; action: 'create' | 'replace' | 'delete'; abs: string; src?: string }> = [];
  const keptTracked: Record<string, TrackedFile> = {};
  let unchanged = 0;

  for (const [rel, s] of staged) {
    if (isProtected(rel)) throw new AetherisError('E_PROTECTED', `Ruta protegida: ${rel}`);
    const abs = resolveInside(instance, rel);
    await assertNoSymlinkEscape(instance, abs);
    const cur = await sha256Of(abs);
    const tr = prev?.files[rel];
    if (cur === null) { actions.push({ rel, action: 'create', abs, src: s.abs }); keptTracked[rel] = s.tracked; continue; }
    if (cur === s.tracked.sha256) { unchanged++; keptTracked[rel] = s.tracked; continue; }
    const oursUnmodified = !!tr && tr.sha256 === cur;
    if (!oursUnmodified && isPersonalConfig(rel) && a.userConfigPolicy === 'keep') { skipped.push(rel); continue; }
    actions.push({ rel, action: 'replace', abs, src: s.abs }); keptTracked[rel] = s.tracked;
  }
  for (const rel of a.staleRels) {
    const abs = resolveInside(instance, rel); await assertNoSymlinkEscape(instance, abs);
    const cur = await sha256Of(abs); const tr = prev!.files[rel]!;
    if (cur === null) continue;
    if (cur === tr.sha256) actions.push({ rel, action: 'delete', abs }); else keptModified.push(rel);
  }

  // directorios que se crearán (para poder deshacerlos)
  const createdDirs: string[] = []; const seenDirs = new Set<string>();
  for (const ac of actions.filter((x) => x.action === 'create')) {
    let d = path.dirname(ac.abs); const chain: string[] = [];
    while (path.resolve(d) !== path.resolve(instance) && !seenDirs.has(d)) {
      try { await fs.stat(d); break; } catch { chain.push(d); seenDirs.add(d); d = path.dirname(d); }
    }
    createdDirs.push(...chain.reverse().map((x) => path.relative(instance, x).split(path.sep).join('/')));
  }

  throwIfAborted(o.signal); // último punto de cancelación: a partir de aquí se completa o se revierte
  const meta: BackupMeta = { id: txid, createdAt: new Date().toISOString(), reason: `Copia automática antes de ${op}`, kind: 'auto', files: [], hasRecord: !!prev };
  const txn: Txn = { id: txid, op, startedAt: meta.createdAt, phase: 'committing', entries: [], createdDirs };
  emit(o, op, 'commit', `Respaldando y aplicando ${actions.length} cambios…`, { current: 0, total: actions.length });
  // 1) respaldar originales (todavía no se ha cambiado nada)
  for (const ac of actions) {
    if (ac.action === 'create') { txn.entries.push({ rel: ac.rel, action: 'create', hadOriginal: false }); continue; }
    const b = await backupOne(instance, txid, ac.rel);
    if (!b) throw new AetherisError('E_BACKUP', `No se pudo respaldar ${ac.rel}; no se ha modificado nada`);
    meta.files.push(b); txn.entries.push({ rel: ac.rel, action: ac.action, hadOriginal: true });
  }
  if (prev) { await fs.mkdir(path.join(backupsRoot(instance), txid), { recursive: true }); await fs.copyFile(recordPath(instance), path.join(backupsRoot(instance), txid, 'install.json')); }
  await writeMeta(instance, meta);
  await writeJsonAtomic(txnPath(instance), txn); // el diario existe ANTES del primer cambio
  // 2) aplicar
  let done = 0;
  try {
    for (const ac of actions) {
      if (ac.action === 'delete') { await fs.rm(ac.abs, { force: true }); removed.push(ac.rel); }
      else {
        await fs.mkdir(path.dirname(ac.abs), { recursive: true });
        try { await fs.rename(ac.src!, ac.abs); }
        catch (e) { if ((e as NodeJS.ErrnoException).code === 'EXDEV') { await fs.copyFile(ac.src!, ac.abs); await fs.rm(ac.src!, { force: true }); } else throw e; }
      }
      emit(o, op, 'commit', `${ac.action === 'create' ? 'Instalado' : ac.action === 'replace' ? 'Actualizado' : 'Retirado'} ${ac.rel}`, { current: ++done, total: actions.length, file: ac.rel });
      if (o.hooks?.crashAfter === done) throw new SimulatedCrash('corte simulado');
      if (o.hooks?.failAfter === done) throw new AetherisError('E_IO', 'fallo simulado');
    }
    txn.phase = 'applied'; await writeJsonAtomic(txnPath(instance), txn);
    // 3) registrar (atómico) y cerrar el diario
    await writeJsonAtomic(recordPath(instance), a.makeRecord(keptTracked));
    await fs.rm(txnPath(instance), { force: true });
  } catch (err) {
    if (err instanceof SimulatedCrash) throw err;
    emit(o, op, 'commit', `Error al aplicar cambios; revirtiendo: ${(err as Error).message}`, { level: 'error' });
    const failures = await rollbackFromTxn(instance, txn);
    if (failures.length) throw new AetherisError('E_ROLLBACK', `La operación falló y la reversión fue parcial (${failures.length} archivos). Abre "Estado" para revertir con la copia ${txid}.`, { failures, cause: (err as Error).message });
    throw err instanceof AetherisError ? err : new AetherisError('E_IO', `La operación falló y se revirtieron los cambios: ${(err as Error).message}`);
  }
  return { installed: actions.filter((x) => x.action !== 'delete').length, unchanged, removed, skippedUserConfigs: skipped, keptModified, ...(meta.files.length ? { backupId: txid } : {}) };
}

/** Deshace una transacción a partir de su diario. Devuelve los archivos que no se pudieron revertir. */
async function rollbackFromTxn(instance: string, txn: Txn): Promise<string[]> {
  const failures: string[] = [];
  for (const e of [...txn.entries].reverse()) {
    try {
      const abs = resolveInside(instance, e.rel);
      if (e.action === 'create') await fs.rm(abs, { force: true });
      else await restoreOneFromBackup(instance, txn.id, e.rel);
    } catch { failures.push(e.rel); }
  }
  for (const d of [...txn.createdDirs].reverse()) { try { await fs.rmdir(resolveInside(instance, d)); } catch { /* no vacío o ya no existe */ } }
  try {
    const bk = path.join(backupsRoot(instance), txn.id, 'install.json');
    const has = await fs.stat(bk).then(() => true, () => false);
    if (has) await fs.copyFile(bk, recordPath(instance)); else if (txn.entries.length) await fs.rm(recordPath(instance), { force: true });
  } catch { failures.push(`${AETH}/install.json`); }
  if (!failures.length) await fs.rm(txnPath(instance), { force: true });
  return failures;
}

// ---------------------------------------------------------------- API pública
export async function pendingTransaction(instance: string): Promise<Txn | null> { return readTxn(instance); }

/** Revierte una operación interrumpida. */
export async function rollbackPending(instance: string, o: EngineOptions = {}): Promise<{ reverted: number }> {
  return withLock(instance, async () => {
    const txn = await readTxn(instance);
    if (!txn) throw new AetherisError('E_TXN_PENDING', 'No hay ninguna operación pendiente');
    emit(o, 'rollback', 'commit', `Revirtiendo la operación interrumpida (${txn.op})…`);
    const f = await rollbackFromTxn(instance, txn);
    if (f.length) throw new AetherisError('E_ROLLBACK', `No se pudieron revertir ${f.length} archivos: ${f.slice(0, 5).join(', ')}`, { failures: f });
    emit(o, 'rollback', 'done', 'Instalación restaurada al estado anterior');
    return { reverted: txn.entries.length };
  });
}

async function preflight(instance: string, o: EngineOptions): Promise<string> {
  const abs = assertAcceptableInstanceDir(instance, o.home);
  await fs.mkdir(abs, { recursive: true });
  if (await readTxn(abs)) throw new AetherisError('E_TXN_PENDING', 'Una operación anterior se interrumpió y dejó cambios a medias. Revierte esos cambios antes de continuar (Estado → Revertir).');
  return abs;
}

/** Instalar / actualizar / cambiar de perfil (según el estado actual de la carpeta). */
export async function installOrUpdate(opts: InstallOptions): Promise<OpResult> {
  const instance = await preflight(opts.instanceDir, opts);
  return withLock(instance, async () => {
    const prev = await readRecord(instance);
    const op = !prev ? 'install' : prev.profileId === opts.profileId ? 'update' : 'switch';
    emit(opts, op, 'validate', 'Validando el paquete .mrpack…');
    const m = await openMrpack(opts.mrpackPath, opts.policy ?? STRICT_POLICY);
    emit(opts, op, 'validate', `Paquete "${m.index.name}" ${m.index.versionId} · Minecraft ${m.minecraft} · Fabric Loader ${m.loaderVersion} · ${m.index.files.length} archivos descargables`);
    const plan = planFiles(m, opts.includeOptional ?? false);
    const dups = await findDuplicates(instance, [...plan.keys()], new Set(Object.keys(prev?.files ?? {})));
    for (const d of dups) emit(opts, op, 'validate', `Posible mod duplicado ya presente (no se borra): ${d}`, { level: 'warn' });
    const stageId = `s-${m.index.versionId.replace(/[^A-Za-z0-9._-]/g, '_').slice(0, 40)}`;
    const staged = await stage(instance, stageId, m, [...plan.values()], opts, op);
    const stale = prev ? Object.keys(prev.files).filter((r) => !plan.has(r)) : [];
    const now = new Date().toISOString();
    const res = await apply({
      instance, op, staged, prev, userConfigPolicy: opts.userConfigPolicy ?? 'keep', staleRels: stale, o: opts,
      makeRecord: (files) => ({
        schema: 1, profileId: opts.profileId, packName: m.index.name, packVersionId: m.index.versionId, minecraft: m.minecraft, loader: 'fabric', loaderVersion: m.loaderVersion,
        installedAt: prev?.installedAt ?? now, updatedAt: now, files, ...(prev?.launcher ? { launcher: prev.launcher } : {}),
      }),
    });
    await fs.copyFile(opts.mrpackPath, packCopyPath(instance));
    await fs.rm(path.join(aethDir(instance), 'staging'), { recursive: true, force: true });
    emit(opts, op, 'done', `Listo: ${res.installed} archivos instalados o actualizados, ${res.unchanged} ya estaban al día`);
    return { op, ...res, duplicates: dups, profileId: opts.profileId, packVersionId: m.index.versionId };
  });
}

export interface VerifyReport { installed: boolean; profileId?: string; packVersionId?: string; total: number; ok: number; missing: string[]; modified: string[]; pendingTransaction: boolean; duplicates: string[] }
/** Comprobación de integridad de los archivos que instaló AETHERIS (no mira mundos ni configuraciones del usuario). */
export async function verifyIntegrity(instanceDir: string, o: EngineOptions = {}): Promise<VerifyReport> {
  const instance = path.resolve(instanceDir);
  const rec = await readRecord(instance);
  const pending = !!(await readTxn(instance));
  if (!rec) return { installed: false, total: 0, ok: 0, missing: [], modified: [], pendingTransaction: pending, duplicates: [] };
  const missing: string[] = [], modified: string[] = []; let ok = 0, i = 0;
  const rels = Object.keys(rec.files);
  for (const rel of rels) {
    const cur = await sha256Of(resolveInside(instance, rel)).catch(() => 'error');
    if (cur === null) missing.push(rel); else if (cur !== rec.files[rel]!.sha256) modified.push(rel); else ok++;
    o.onProgress?.({ op: 'verify', phase: 'verify', message: 'Comprobando…', current: ++i, total: rels.length, file: rel });
  }
  const dups = await findDuplicates(instance, rels, new Set(rels));
  return { installed: true, profileId: rec.profileId, packVersionId: rec.packVersionId, total: rels.length, ok, missing, modified, pendingTransaction: pending, duplicates: dups };
}

/** Repara archivos instalados que faltan o están dañados, usando la copia del paquete guardada en .aetheris. */
export async function repair(opts: EngineOptions & { instanceDir: string; userConfigPolicy?: 'keep' | 'replace' }): Promise<OpResult & { repaired: string[] }> {
  const instance = await preflight(opts.instanceDir, opts);
  return withLock(instance, async () => {
    const prev = await readRecord(instance);
    if (!prev) throw new AetherisError('E_NOT_INSTALLED', 'No hay ninguna instalación de AETHERIS en esta carpeta');
    const rep = await verifyIntegrity(instance);
    const bad = [...rep.missing, ...rep.modified];
    if (!bad.length) { emit(opts, 'repair', 'done', 'Todo está en orden: no hay nada que reparar'); return { op: 'repair', installed: 0, unchanged: rep.ok, removed: [], skippedUserConfigs: [], keptModified: [], duplicates: rep.duplicates, repaired: [] }; }
    let m: OpenedMrpack;
    try { m = await openMrpack(packCopyPath(instance), opts.policy ?? STRICT_POLICY); }
    catch { throw new AetherisError('E_NOT_INSTALLED', 'Falta la copia del paquete original (.aetheris/pack.mrpack). Vuelve a instalar el perfil para repararlo.'); }
    const plan = planFiles(m, false);
    const targets = bad.filter((r) => plan.has(r)).map((r) => plan.get(r)!);
    emit(opts, 'repair', 'validate', `Reparando ${targets.length} archivos (${rep.missing.length} faltan, ${rep.modified.length} modificados)…`);
    const staged = await stage(instance, `repair-${Date.now()}`, m, targets, opts, 'repair');
    const now = new Date().toISOString();
    const res = await apply({
      instance, op: 'repair', staged, prev, userConfigPolicy: opts.userConfigPolicy ?? 'keep', staleRels: [], o: opts,
      makeRecord: (kept) => ({ ...prev, updatedAt: now, files: { ...prev.files, ...kept } }),
    });
    await fs.rm(path.join(aethDir(instance), 'staging'), { recursive: true, force: true });
    const repaired = targets.map((t) => t.rel).filter((r) => !res.skippedUserConfigs.includes(r));
    emit(opts, 'repair', 'done', `Reparados ${repaired.length} archivos${res.skippedUserConfigs.length ? `; ${res.skippedUserConfigs.length} configuraciones modificadas por ti se han respetado` : ''}`);
    return { op: 'repair', ...res, duplicates: rep.duplicates, repaired };
  });
}

export interface UninstallResult { removed: string[]; keptModified: string[]; backupId?: string; launcher?: InstallRecord['launcher'] }
/** Desinstala SOLO lo que registró AETHERIS. Nunca toca mundos, capturas, partidas ni archivos que no instaló. */
export async function uninstall(opts: EngineOptions & { instanceDir: string; removeBackups?: boolean }): Promise<UninstallResult> {
  const instance = await preflight(opts.instanceDir, opts);
  return withLock(instance, async () => {
    const prev = await readRecord(instance);
    if (!prev) throw new AetherisError('E_NOT_INSTALLED', 'No hay ninguna instalación de AETHERIS en esta carpeta');
    const id = newId('uninstall'); const meta: BackupMeta = { id, createdAt: new Date().toISOString(), reason: 'Copia antes de desinstalar', kind: 'auto', files: [], hasRecord: true };
    const removed: string[] = [], kept: string[] = []; let i = 0;
    const rels = Object.keys(prev.files);
    for (const rel of rels) {
      const abs = resolveInside(instance, rel); await assertNoSymlinkEscape(instance, abs);
      const cur = await sha256Of(abs);
      if (cur !== null && cur === prev.files[rel]!.sha256) {
        const b = await backupOne(instance, id, rel); if (!b) throw new AetherisError('E_BACKUP', `No se pudo respaldar ${rel}`);
        meta.files.push(b); await fs.rm(abs, { force: true }); removed.push(rel);
      } else if (cur !== null) kept.push(rel);
      emit(opts, 'uninstall', 'commit', `Procesado ${rel}`, { current: ++i, total: rels.length, file: rel });
    }
    await fs.mkdir(path.join(backupsRoot(instance), id), { recursive: true });
    await fs.copyFile(recordPath(instance), path.join(backupsRoot(instance), id, 'install.json'));
    await writeMeta(instance, meta);
    const dirs = new Set(removed.map((r) => path.posix.dirname(r)).filter((d) => d !== '.'));
    for (const d of [...dirs].sort((a, b) => b.length - a.length)) {
      let cur = d;
      while (cur !== '.' && ['mods', 'config', 'resourcepacks', 'shaderpacks'].includes(cur.split('/')[0]!)) {
        try { await fs.rmdir(resolveInside(instance, cur)); } catch { break; }
        cur = path.posix.dirname(cur);
      }
    }
    await fs.rm(recordPath(instance), { force: true }); await fs.rm(packCopyPath(instance), { force: true });
    await fs.rm(path.join(aethDir(instance), 'staging'), { recursive: true, force: true });
    if (opts.removeBackups) await fs.rm(backupsRoot(instance), { recursive: true, force: true });
    emit(opts, 'uninstall', 'done', `Desinstalado: ${removed.length} archivos retirados; ${kept.length} modificados por ti se han conservado`);
    return { removed, keptModified: kept, ...(opts.removeBackups ? {} : { backupId: id }), ...(prev.launcher ? { launcher: prev.launcher } : {}) };
  });
}

export async function getInstallInfo(instanceDir: string): Promise<(InstallRecord & { fileCount: number; pendingTransaction: boolean }) | null> {
  const instance = path.resolve(instanceDir);
  const rec = await readRecord(instance);
  if (!rec) return null;
  return { ...rec, fileCount: Object.keys(rec.files).length, pendingTransaction: !!(await readTxn(instance)) };
}

/** Actualiza el registro con los datos del launcher (lo usa la integración con el launcher oficial). */
export async function setLauncherInfo(instanceDir: string, launcher: InstallRecord['launcher'] | null): Promise<void> {
  const instance = path.resolve(instanceDir);
  const rec = await readRecord(instance);
  if (!rec) throw new AetherisError('E_NOT_INSTALLED', 'No hay ninguna instalación de AETHERIS en esta carpeta');
  const { launcher: _old, ...rest } = rec; void _old;
  await writeJsonAtomic(recordPath(instance), { ...rest, ...(launcher ? { launcher } : {}) });
}
