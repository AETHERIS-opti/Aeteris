import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';

export type Algo = 'sha1' | 'sha256' | 'sha512';

export async function hashFile(file: string, algos: Algo[]): Promise<Record<string, string>> {
  const hs = algos.map((a) => [a, createHash(a)] as const);
  await new Promise<void>((resolve, reject) => {
    const s = createReadStream(file);
    s.on('data', (c) => { for (const [, h] of hs) h.update(c); });
    s.on('error', reject);
    s.on('end', () => resolve());
  });
  return Object.fromEntries(hs.map(([a, h]) => [a, h.digest('hex')]));
}

export const HEX_LEN: Record<'sha1' | 'sha512', number> = { sha1: 40, sha512: 128 };
export const isHex = (v: unknown, len: number): v is string => typeof v === 'string' && v.length === len && /^[0-9a-f]+$/.test(v);
