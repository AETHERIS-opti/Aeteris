/**
 * Lector ZIP mínimo, sin dependencias, pensado para entradas NO confiables.
 * - Solo métodos 0 (almacenado) y 8 (deflate). Rechaza cifrado, ZIP64, enlaces simbólicos y nombres peligrosos.
 * - Límites anti "zip bomb": nº de entradas, tamaño por entrada, tamaño total y ratio de compresión.
 * - Verifica CRC-32 y tamaño declarado al extraer.
 */
import fs from 'node:fs/promises';
import { createReadStream, createWriteStream } from 'node:fs';
import zlib from 'node:zlib';
import path from 'node:path';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { AetherisError } from './errors';
import { assertSafeRelative } from './paths';

export interface ZipLimits { maxEntries: number; maxEntryBytes: number; maxTotalBytes: number; maxRatio: number }
export const DEFAULT_LIMITS: ZipLimits = { maxEntries: 20_000, maxEntryBytes: 1024 ** 3, maxTotalBytes: 4 * 1024 ** 3, maxRatio: 1000 };

export interface ZipEntry {
  name: string;          // ruta normalizada (sin '/' final)
  isDirectory: boolean;
  method: number;
  compressedSize: number;
  size: number;
  crc32: number;
  offset: number;        // desplazamiento de la cabecera local
}

const SIG_EOCD = 0x06054b50, SIG_CEN = 0x02014b50, SIG_LOC = 0x04034b50, SIG_EOCD64LOC = 0x07064b50;

export class ZipReader {
  private constructor(readonly file: string, readonly entries: ZipEntry[], private limits: ZipLimits) {}

  static async open(file: string, limits: ZipLimits = DEFAULT_LIMITS): Promise<ZipReader> {
    const fh = await fs.open(file, 'r');
    try {
      const { size } = await fh.stat();
      if (size < 22) throw new AetherisError('E_ZIP', 'El archivo no es un ZIP válido (demasiado pequeño)');
      const tailLen = Math.min(size, 22 + 65535);
      const tail = Buffer.alloc(tailLen);
      await fh.read(tail, 0, tailLen, size - tailLen);
      let e = -1;
      for (let i = tailLen - 22; i >= 0; i--) if (tail.readUInt32LE(i) === SIG_EOCD) { e = i; break; }
      if (e < 0) throw new AetherisError('E_ZIP', 'El archivo no es un ZIP válido (sin directorio central)');
      if (e >= 20 && tail.readUInt32LE(e - 20) === SIG_EOCD64LOC) throw new AetherisError('E_ZIP', 'ZIP64 no soportado');
      const total = tail.readUInt16LE(e + 10), cdSize = tail.readUInt32LE(e + 12), cdOff = tail.readUInt32LE(e + 16);
      if (total === 0xffff || cdSize === 0xffffffff || cdOff === 0xffffffff) throw new AetherisError('E_ZIP', 'ZIP64 no soportado');
      if (total > limits.maxEntries) throw new AetherisError('E_ZIP', `Demasiadas entradas (${total})`);
      if (cdOff + cdSize > size) throw new AetherisError('E_ZIP', 'Directorio central fuera del archivo');
      const cd = Buffer.alloc(cdSize);
      await fh.read(cd, 0, cdSize, cdOff);
      const entries: ZipEntry[] = [];
      const seen = new Set<string>();
      let totalBytes = 0, p = 0;
      for (let n = 0; n < total; n++) {
        if (p + 46 > cd.length || cd.readUInt32LE(p) !== SIG_CEN) throw new AetherisError('E_ZIP', 'Directorio central dañado');
        const flags = cd.readUInt16LE(p + 8), method = cd.readUInt16LE(p + 10);
        const crc32 = cd.readUInt32LE(p + 16), comp = cd.readUInt32LE(p + 20), unc = cd.readUInt32LE(p + 24);
        const nl = cd.readUInt16LE(p + 28), xl = cd.readUInt16LE(p + 30), cl = cd.readUInt16LE(p + 32);
        const ext = cd.readUInt32LE(p + 38), off = cd.readUInt32LE(p + 42);
        const rawName = cd.subarray(p + 46, p + 46 + nl).toString((flags & 0x800) ? 'utf8' : 'latin1');
        p += 46 + nl + xl + cl;
        if (flags & 1) throw new AetherisError('E_ZIP', `Entrada cifrada no soportada: ${rawName}`);
        if (method !== 0 && method !== 8) throw new AetherisError('E_ZIP', `Método de compresión no soportado (${method}): ${rawName}`);
        if (comp === 0xffffffff || unc === 0xffffffff) throw new AetherisError('E_ZIP', 'ZIP64 no soportado');
        const unixMode = ext >>> 16;
        if ((unixMode & 0o170000) === 0o120000) throw new AetherisError('E_ZIP', `Enlace simbólico no permitido: ${rawName}`);
        const isDir = rawName.endsWith('/');
        const name = assertSafeRelative(rawName, 'entrada ZIP');
        const key = name.toLowerCase();
        if (seen.has(key)) throw new AetherisError('E_ZIP', `Entrada duplicada: ${name}`);
        seen.add(key);
        if (unc > limits.maxEntryBytes) throw new AetherisError('E_ZIP', `Entrada demasiado grande: ${name}`);
        if (!isDir && unc > 1024 * 1024 && comp > 0 && unc / comp > limits.maxRatio) throw new AetherisError('E_ZIP', `Ratio de compresión sospechoso: ${name}`);
        totalBytes += unc;
        if (totalBytes > limits.maxTotalBytes) throw new AetherisError('E_ZIP', 'El contenido descomprimido supera el límite permitido');
        entries.push({ name, isDirectory: isDir, method, compressedSize: comp, size: unc, crc32, offset: off });
      }
      return new ZipReader(file, entries, limits);
    } finally {
      await fh.close();
    }
  }

  find(name: string): ZipEntry | undefined { return this.entries.find((e) => e.name === name); }

  private async dataStart(fh: fs.FileHandle, e: ZipEntry): Promise<number> {
    const h = Buffer.alloc(30);
    await fh.read(h, 0, 30, e.offset);
    if (h.readUInt32LE(0) !== SIG_LOC) throw new AetherisError('E_ZIP', `Cabecera local dañada: ${e.name}`);
    return e.offset + 30 + h.readUInt16LE(26) + h.readUInt16LE(28);
  }

  /** Flujo descomprimido y verificado (tamaño + CRC) de una entrada. Destruir el flujo libera el archivo. */
  private async open_(e: ZipEntry): Promise<Readable> {
    const fh = await fs.open(this.file, 'r');
    let start: number;
    try { start = await this.dataStart(fh, e); } finally { await fh.close(); }
    let count = 0, crc = 0;
    const check = new Transform({
      transform(chunk: Buffer, _enc, cb) {
        count += chunk.length;
        if (count > e.size) return cb(new AetherisError('E_ZIP', `La entrada ${e.name} excede su tamaño declarado`));
        crc = zlib.crc32(chunk, crc);
        cb(null, chunk);
      },
      flush(cb) {
        if (count !== e.size) return cb(new AetherisError('E_ZIP', `Tamaño incorrecto en ${e.name}`));
        if ((crc >>> 0) !== e.crc32) return cb(new AetherisError('E_ZIP', `CRC incorrecto en ${e.name} (archivo dañado)`));
        cb();
      },
    });
    const raw = createReadStream(this.file, { start, end: start + e.compressedSize - 1 });
    const stages: Array<Readable | Transform> = [raw];
    if (e.method === 8) stages.push(zlib.createInflateRaw());
    stages.push(check);
    return Readable.from(pipelineGen(stages));
  }

  /** Lee una entrada pequeña en memoria (con tope). */
  async read(e: ZipEntry, maxBytes = 8 * 1024 * 1024): Promise<Buffer> {
    if (e.size > maxBytes) throw new AetherisError('E_ZIP', `Entrada demasiado grande para leerla en memoria: ${e.name}`);
    if (e.size === 0) return Buffer.alloc(0);
    const chunks: Buffer[] = [];
    for await (const c of await this.open_(e)) chunks.push(c as Buffer);
    return Buffer.concat(chunks);
  }

  /** Extrae a un archivo nuevo (falla si ya existe). Verifica tamaño y CRC; no deja archivos a medias. */
  async extract(e: ZipEntry, dest: string): Promise<void> {
    await fs.mkdir(path.dirname(dest), { recursive: true });
    if (e.size === 0) { await fs.writeFile(dest, Buffer.alloc(0), { flag: 'wx' }); return; }
    const src = await this.open_(e);
    try {
      await pipeline(src, createWriteStream(dest, { flags: 'wx' }));
    } catch (err) {
      await fs.rm(dest, { force: true });
      throw err;
    }
  }
}

/** Encadena etapas (raw -> inflate -> check) como un único async generator con propagación de errores. */
async function* pipelineGen(stages: Array<Readable | Transform>): AsyncGenerator<Buffer> {
  const last = stages[stages.length - 1]!;
  const errP = new Promise<never>((_, rej) => { for (const s of stages) s.once('error', rej); });
  for (let i = 0; i < stages.length - 1; i++) stages[i]!.pipe(stages[i + 1] as Transform);
  errP.catch(() => undefined);
  try {
    const it = last[Symbol.asyncIterator]() as AsyncIterator<Buffer>;
    for (;;) {
      const r = await Promise.race([it.next(), errP]);
      if ((r as IteratorResult<Buffer>).done) return;
      yield (r as IteratorResult<Buffer>).value;
    }
  } finally {
    for (const s of stages) s.destroy();
  }
}
