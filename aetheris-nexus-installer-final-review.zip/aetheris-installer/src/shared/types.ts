/** Tipos compartidos entre el proceso principal (Node) y la interfaz (React). Solo tipos: sin código de Node. */
export interface JavaInstall { path: string; version: string; major: number; source: string }
export interface LauncherInstance { name: string; path: string; gameDir: string }
export interface LauncherCandidate {
  kind: 'official' | 'prism' | 'modrinth' | 'curseforge' | 'gdlauncher' | 'multimc';
  label: string; path: string; exists: boolean; instances: LauncherInstance[];
  /** Siempre false: ningún launcher se ha probado con AETHERIS en un Windows real. */
  verified: false; note: string;
}
export interface SystemInfo {
  os: { platform: string; name: string; release: string; build: number | null; arch: string; supported: boolean };
  ram: { totalMB: number; freeMB: number };
  cpuCores: number;
  java: JavaInstall[];
  minecraftDir: { path: string; exists: boolean } | null;
  launchers: LauncherCandidate[];
  warnings: string[];
}
export interface JavaRequirement { major: number; confirmed: boolean; note: string }
export interface JavaCheck { ok: boolean; required: JavaRequirement; best: JavaInstall | null; message: string }

export type ProfileStatus = 'ready' | 'missing' | 'invalid';
export interface ProfileSummary {
  id: string; name: string; tagline: string; description: string; highlights: string[]; shaders: 'optional' | 'none';
  status: ProfileStatus; statusMessage: string;
  pack?: { name: string; versionId: string; minecraft: string; loaderVersion: string; modCount: number; sizeBytes: number; modListFingerprint: string; source: 'bundled' | 'user' };
  expectedFile: string;
}
export interface ProfilesReport { profiles: ProfileSummary[]; warnings: string[]; packsDir: string; userPacksDir: string }
