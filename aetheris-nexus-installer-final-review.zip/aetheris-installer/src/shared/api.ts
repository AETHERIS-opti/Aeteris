import type { ProfilesReport, SystemInfo, JavaCheck } from './types';

export type Result<T> = { ok: true; value: T } | { ok: false; error: { code: string; message: string; details?: unknown } };

export interface InstallTarget { kind: 'official' | 'folder'; folder?: string }
export interface InstallArgs { profileId: string; target: InstallTarget; userConfigPolicy: 'keep' | 'replace'; createLauncherProfile: boolean }
export interface OpSummary {
  op: string; installed: number; unchanged: number; removed: string[]; skippedUserConfigs: string[]; keptModified: string[]; duplicates: string[];
  backupId?: string; folder: string; launcherProfile?: 'created' | 'failed' | 'skipped'; launcherError?: string;
}
export interface ProgressMsg {
  op: string; phase: 'validate' | 'download' | 'extract' | 'commit' | 'verify' | 'cleanup' | 'done'; message: string;
  current?: number; total?: number; bytes?: number; totalBytes?: number; file?: string; level?: 'info' | 'warn' | 'error';
}
export interface InstallInfoDto {
  folder: string; profileId: string; packName: string; packVersionId: string; minecraft: string; loaderVersion: string;
  installedAt: string; updatedAt: string; fileCount: number; pendingTransaction: boolean; launcherProfile: boolean;
}
export interface KnownInstall { folder: string; exists: boolean; info: InstallInfoDto | null }
export interface VerifyDto { installed: boolean; profileId?: string; packVersionId?: string; total: number; ok: number; missing: string[]; modified: string[]; pendingTransaction: boolean; duplicates: string[] }
export interface BackupDto { id: string; createdAt: string; reason: string; kind: 'auto' | 'manual'; fileCount: number }
export interface LogLine { t: string; level: 'info' | 'warn' | 'error'; msg: string }
export interface AppInfo { version: string; packaged: boolean; platform: string; arch: string; electron: string; signed: false; userData: string; logFile: string }

export interface AetherisApi {
  appInfo(): Promise<AppInfo>;
  getSystem(): Promise<Result<SystemInfo>>;
  javaCheck(minecraft: string): Promise<Result<JavaCheck>>;
  listProfiles(): Promise<Result<ProfilesReport>>;
  importPack(profileId: string): Promise<Result<{ imported: boolean }>>;
  chooseFolder(title: string): Promise<string | null>;
  defaultOfficialFolder(profileId: string): Promise<Result<string>>;
  install(args: InstallArgs): Promise<Result<OpSummary>>;
  cancel(): Promise<void>;
  listKnownInstalls(): Promise<Result<KnownInstall[]>>;
  inspect(folder: string): Promise<Result<InstallInfoDto | null>>;
  verify(folder: string): Promise<Result<VerifyDto>>;
  repair(folder: string, userConfigPolicy: 'keep' | 'replace'): Promise<Result<OpSummary & { repaired: string[] }>>;
  uninstall(folder: string, removeBackups: boolean): Promise<Result<{ removed: number; keptModified: string[]; backupId?: string }>>;
  rollbackPending(folder: string): Promise<Result<{ reverted: number }>>;
  createBackup(folder: string): Promise<Result<BackupDto>>;
  listBackups(folder: string): Promise<Result<BackupDto[]>>;
  restoreBackup(folder: string, id: string): Promise<Result<{ restored: number; removed: number }>>;
  readLogs(): Promise<LogLine[]>;
  openFolder(folder: string): Promise<Result<true>>;
  onProgress(cb: (m: ProgressMsg) => void): () => void;
}

export const CHANNELS = [
  'appInfo', 'getSystem', 'javaCheck', 'listProfiles', 'importPack', 'chooseFolder', 'defaultOfficialFolder', 'install', 'cancel', 'listKnownInstalls',
  'inspect', 'verify', 'repair', 'uninstall', 'rollbackPending', 'createBackup', 'listBackups', 'restoreBackup', 'readLogs', 'openFolder',
] as const;
export type Channel = typeof CHANNELS[number];
export const PROGRESS_CHANNEL = 'aetheris:progress';
