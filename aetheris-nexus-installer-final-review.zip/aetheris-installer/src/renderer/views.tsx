import { useEffect, useMemo, useState } from 'react';
import type { ProfileSummary, ProfilesReport, SystemInfo, JavaCheck } from '../shared/types';
import type { AppInfo, BackupDto, InstallArgs, InstallInfoDto, KnownInstall, LogLine, VerifyDto } from '../shared/api';
import { api } from './api';
import { Badge, Button, Confirm, Modal, Stat } from './ui';
import { dirname, fmtBytes, fmtDate } from './format';

/* ------------------------------------------------------------------ PERFILES */
export function ProfilesView({ report, onInstall, onImport, onRefresh }: { report: ProfilesReport | null; onInstall: (p: ProfileSummary) => void; onImport: (p: ProfileSummary) => void; onRefresh: () => void }) {
  if (!report) return <div className="muted pad">Cargando perfiles…</div>;
  const ready = report.profiles.filter((p) => p.status === 'ready').length;
  return (
    <div>
      <div className="head">
        <div><h1>Perfiles</h1><p className="muted">{ready} de {report.profiles.length} perfiles tienen su paquete real configurado. Cada perfil se instala desde su propio archivo .mrpack.</p></div>
        <Button variant="ghost" onClick={onRefresh}>Actualizar</Button>
      </div>
      {report.warnings.map((w) => <div key={w} className="note note-warn">⚠ {w}</div>)}
      <div className="grid">
        {report.profiles.map((p, i) => (
          <article key={p.id} className={`card card-${p.id}`} style={{ animationDelay: `${i * 70}ms` }}>
            <div className="card-top">
              <h3>{p.name}</h3>
              <Badge tone={p.status === 'ready' ? 'ok' : p.status === 'missing' ? 'warn' : 'err'}>{p.status === 'ready' ? 'Configurado' : p.status === 'missing' ? 'Falta el paquete' : 'Paquete no válido'}</Badge>
            </div>
            <p className="tagline">{p.tagline}</p>
            <p className="muted small">{p.description}</p>
            <div className="chips">{p.highlights.map((h) => <span key={h} className="chip">{h}</span>)}<span className="chip chip-alt">{p.shaders === 'optional' ? 'Shaders opcionales (desactivados)' : 'Sin shaders'}</span></div>
            {p.pack ? (
              <div className="facts">
                <Stat label="Minecraft" value={p.pack.minecraft} /><Stat label="Fabric Loader" value={p.pack.loaderVersion} />
                <Stat label="Mods" value={p.pack.modCount} /><Stat label="Tamaño" value={fmtBytes(p.pack.sizeBytes)} />
                <Stat label="Versión del paquete" value={p.pack.versionId} /><Stat label="Origen" value={p.pack.source === 'user' ? 'Incorporado por ti' : 'Incluido'} />
              </div>
            ) : <div className={`note ${p.status === 'invalid' ? 'note-err' : 'note-mute'}`}>{p.statusMessage}</div>}
            <div className="row">
              <Button onClick={() => onInstall(p)} disabled={p.status !== 'ready'} title={p.status !== 'ready' ? 'Este perfil aún no tiene un paquete válido' : undefined}>Instalar</Button>
              <Button variant="ghost" onClick={() => onImport(p)}>Incorporar .mrpack</Button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ INSTALAR (diálogo) */
export function InstallDialog({ profile, system, onClose, onStart }: { profile: ProfileSummary; system: SystemInfo | null; onClose: () => void; onStart: (a: InstallArgs) => void }) {
  const officialOk = !!system?.minecraftDir?.exists;
  const [kind, setKind] = useState<'official' | 'folder'>(officialOk ? 'official' : 'folder');
  const [folder, setFolder] = useState<string>('');
  const [policy, setPolicy] = useState<'keep' | 'replace'>('keep');
  const [launcher, setLauncher] = useState(true);
  const [java, setJava] = useState<JavaCheck | null>(null);
  useEffect(() => { if (profile.pack) void api().javaCheck(profile.pack.minecraft).then((r) => { if (r.ok) setJava(r.value); }); }, [profile.pack]);
  const instances = useMemo(() => (system?.launchers ?? []).flatMap((l) => l.instances.map((i) => ({ ...i, launcher: l.label }))), [system]);
  const valid = kind === 'official' ? officialOk : folder.length > 0;
  return (
    <Modal title={`Instalar ${profile.name}`} onClose={onClose} wide>
      <div className="form">
        <fieldset>
          <legend>¿Dónde instalar?</legend>
          <label className={`opt${!officialOk ? ' opt-off' : ''}`}><input type="radio" name="t" checked={kind === 'official'} disabled={!officialOk} onChange={() => setKind('official')} />
            <span><b>Launcher oficial de Minecraft</b><small>{officialOk ? 'Se usa una carpeta propia y aislada: tu .minecraft normal no se mezcla.' : 'No se encontró el launcher oficial (.minecraft).'}</small></span></label>
          <label className="opt"><input type="radio" name="t" checked={kind === 'folder'} onChange={() => setKind('folder')} />
            <span><b>Carpeta de instancia</b><small>Para Prism, Modrinth App, CurseForge u otro launcher: solo se copian archivos; el cargador Fabric debe estar configurado en esa instancia.</small></span></label>
          {kind === 'folder' && (
            <div className="sub">
              {instances.length > 0 && <select value={folder} onChange={(e) => setFolder(e.target.value)} aria-label="Instancias detectadas"><option value="">Instancias detectadas…</option>{instances.map((i) => <option key={i.gameDir} value={i.gameDir}>{i.launcher} · {i.name} (sin verificar)</option>)}</select>}
              <div className="row"><Button variant="ghost" onClick={async () => { const f = await api().chooseFolder('Carpeta de la instancia'); if (f) setFolder(f); }}>Elegir carpeta…</Button><code className="path">{folder || 'Ninguna carpeta elegida'}</code></div>
            </div>
          )}
        </fieldset>
        <fieldset>
          <legend>Si ya existe configuración tuya (options.txt, config/, shaderpacks/)</legend>
          <label className="opt"><input type="radio" name="p" checked={policy === 'keep'} onChange={() => setPolicy('keep')} /><span><b>Respetarla</b><small>No se sobrescribe; se te informa de lo que se omitió.</small></span></label>
          <label className="opt"><input type="radio" name="p" checked={policy === 'replace'} onChange={() => setPolicy('replace')} /><span><b>Reemplazarla por la del perfil</b><small>Se guarda antes una copia de seguridad de cada archivo reemplazado.</small></span></label>
        </fieldset>
        {kind === 'official' && <label className="opt"><input type="checkbox" checked={launcher} onChange={(e) => setLauncher(e.target.checked)} /><span><b>Crear el perfil «{profile.name}» en el launcher oficial</b><small>Se hace copia de seguridad de launcher_profiles.json y no se tocan tus otros perfiles. Cierra el launcher antes.</small></span></label>}
        {java && <div className={`note ${java.ok ? 'note-ok' : 'note-warn'}`}>{java.ok ? '✔' : '⚠'} {java.message}</div>}
        <div className="note note-mute">Se verificará el hash de cada archivo descargado. Tus mundos, capturas y partidas nunca se tocan. Si algo falla, no se modifica nada.</div>
        <div className="row end"><Button variant="ghost" onClick={onClose}>Cancelar</Button>
          <Button disabled={!valid} onClick={() => onStart({ profileId: profile.id, target: kind === 'official' ? { kind } : { kind, folder }, userConfigPolicy: policy, createLauncherProfile: kind === 'official' && launcher })}>Instalar</Button></div>
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ MANTENIMIENTO */
export function ManageView({ report, installs, onRefreshInstalls, run, onInstallInto }: {
  report: ProfilesReport | null; installs: KnownInstall[]; onRefreshInstalls: () => void;
  run: (title: string, fn: () => Promise<{ ok: boolean }>, after?: () => void) => void; onInstallInto: (profileId: string, folder: string) => void;
}) {
  const [sel, setSel] = useState<string>(installs[0]?.folder ?? '');
  const [info, setInfo] = useState<InstallInfoDto | null>(null);
  const [verify, setVerify] = useState<VerifyDto | null>(null);
  const [backups, setBackups] = useState<BackupDto[]>([]);
  const [confirm, setConfirm] = useState<null | { kind: 'uninstall' | 'restore' | 'rollback' | 'repairReplace'; id?: string }>(null);
  const [removeBk, setRemoveBk] = useState(false);
  const [switchTo, setSwitchTo] = useState('');
  useEffect(() => { if (!sel && installs[0]) setSel(installs[0].folder); }, [installs, sel]);
  const reload = async (f: string) => {
    if (!f) { setInfo(null); setBackups([]); return; }
    const r = await api().inspect(f); setInfo(r.ok ? r.value : null);
    const b = await api().listBackups(f); setBackups(b.ok ? b.value : []);
  };
  useEffect(() => { setVerify(null); void reload(sel); }, [sel, installs]);
  const done = () => { onRefreshInstalls(); void reload(sel); };
  const others = (report?.profiles ?? []).filter((p) => p.status === 'ready' && p.id !== info?.profileId);
  const same = (report?.profiles ?? []).find((p) => p.id === info?.profileId);
  return (
    <div>
      <div className="head"><div><h1>Mantenimiento</h1><p className="muted">Comprueba, repara, actualiza, cambia de perfil, copia o desinstala. Solo se toca lo que AETHERIS instaló.</p></div></div>
      <div className="panel">
        <div className="row">
          <select value={sel} onChange={(e) => setSel(e.target.value)} aria-label="Instalación">
            {installs.length === 0 && <option value="">Sin instalaciones conocidas</option>}
            {installs.map((i) => <option key={i.folder} value={i.folder}>{i.info ? `${i.info.profileId} · ` : ''}{i.folder}{i.exists ? '' : ' (no existe)'}</option>)}
          </select>
          <Button variant="ghost" onClick={async () => { const f = await api().chooseFolder('Carpeta de una instalación de AETHERIS'); if (f) { const r = await api().inspect(f); if (r.ok && r.value) { onRefreshInstalls(); setSel(f); } else window.alert('Esa carpeta no contiene una instalación de AETHERIS.'); } }}>Buscar carpeta…</Button>
        </div>
      </div>
      {!info && <div className="note note-mute">Selecciona una instalación existente. Si todavía no has instalado ningún perfil, empieza en «Perfiles».</div>}
      {info && (
        <>
          {info.pendingTransaction && <div className="note note-err">⚠ Una operación anterior se interrumpió y dejó cambios a medias. <Button variant="danger" onClick={() => setConfirm({ kind: 'rollback' })}>Revertir cambios</Button></div>}
          <div className="panel">
            <h3>Información de la instalación</h3>
            <div className="facts">
              <Stat label="Perfil" value={info.profileId} /><Stat label="Paquete" value={`${info.packName} ${info.packVersionId}`} />
              <Stat label="Minecraft" value={info.minecraft} /><Stat label="Fabric Loader" value={info.loaderVersion} />
              <Stat label="Archivos registrados" value={info.fileCount} /><Stat label="Perfil en el launcher" value={info.launcherProfile ? 'Creado por AETHERIS' : 'No'} />
              <Stat label="Instalado" value={fmtDate(info.installedAt)} /><Stat label="Actualizado" value={fmtDate(info.updatedAt)} />
            </div>
            <div className="row wrap">
              <Button variant="ghost" onClick={() => api().openFolder(info.folder)}>Abrir carpeta</Button>
              <Button onClick={async () => { const r = await api().verify(info.folder); if (r.ok) setVerify(r.value); else window.alert(r.error.message); }}>Comprobar integridad</Button>
              <Button onClick={() => run('Reparando instalación', () => api().repair(info.folder, 'keep'), done)}>Reparar</Button>
              <Button variant="ghost" disabled={!same || same.status !== 'ready'} title={!same || same.status !== 'ready' ? 'Falta el paquete de este perfil' : 'Vuelve a aplicar el paquete actual del perfil'} onClick={() => same && onInstallInto(same.id, info.folder)}>Actualizar al paquete actual</Button>
            </div>
            {verify && (
              <div className={`note ${verify.missing.length + verify.modified.length === 0 ? 'note-ok' : 'note-warn'}`}>
                {verify.missing.length + verify.modified.length === 0 ? `✔ Integridad correcta: ${verify.ok} de ${verify.total} archivos coinciden.` : `⚠ ${verify.ok} de ${verify.total} correctos · ${verify.missing.length} faltan · ${verify.modified.length} modificados. Pulsa «Reparar».`}
                {verify.missing.concat(verify.modified).slice(0, 6).map((f) => <div key={f} className="mono small">{f}</div>)}
                {verify.duplicates.length > 0 && <div>Posibles mods duplicados (no se borran): {verify.duplicates.join(', ')}</div>}
              </div>
            )}
          </div>
          <div className="panel">
            <h3>Cambiar de perfil</h3>
            <p className="muted small">Instala otro perfil en esta misma carpeta. Se retiran solo los archivos del perfil anterior que no hayas modificado, con copia de seguridad.</p>
            <div className="row"><select value={switchTo} onChange={(e) => setSwitchTo(e.target.value)} aria-label="Nuevo perfil"><option value="">Elige un perfil listo…</option>{others.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
              <Button disabled={!switchTo} onClick={() => onInstallInto(switchTo, info.folder)}>Cambiar</Button></div>
          </div>
          <div className="panel">
            <h3>Copias de seguridad</h3>
            <p className="muted small">Incluyen los archivos instalados y tu configuración (options.txt, config/). Nunca incluyen mundos ni capturas.</p>
            <div className="row"><Button onClick={() => run('Creando copia de seguridad', () => api().createBackup(info.folder), done)}>Crear copia ahora</Button></div>
            <div className="list">{backups.length === 0 && <div className="muted small">Todavía no hay copias.</div>}
              {backups.map((b) => (
                <div key={b.id} className="li"><div><b>{b.kind === 'manual' ? 'Manual' : 'Automática'}</b> · {fmtDate(b.createdAt)} · {b.fileCount} archivos<div className="muted small">{b.reason}</div></div>
                  {b.kind === 'manual' && <Button variant="ghost" onClick={() => setConfirm({ kind: 'restore', id: b.id })}>Restaurar</Button>}</div>))}
            </div>
          </div>
          <div className="panel panel-danger">
            <h3>Desinstalar</h3>
            <p className="muted small">Retira únicamente los archivos que registró AETHERIS (y su perfil del launcher). Tus mundos, capturas, partidas y archivos propios no se tocan.</p>
            <Button variant="danger" onClick={() => setConfirm({ kind: 'uninstall' })}>Desinstalar este perfil…</Button>
          </div>
        </>
      )}
      {confirm?.kind === 'uninstall' && info && <Confirm danger title="Desinstalar AETHERIS" confirmLabel="Desinstalar" text={`Se retirarán los archivos instalados por AETHERIS en ${info.folder}. Antes se guarda una copia.`} onNo={() => setConfirm(null)} onYes={() => { setConfirm(null); run('Desinstalando', () => api().uninstall(info.folder, removeBk), done); }}>
        <label className="opt"><input type="checkbox" checked={removeBk} onChange={(e) => setRemoveBk(e.target.checked)} /><span><b>Borrar también las copias de seguridad de AETHERIS</b><small>Si no lo marcas, se conservan en .aetheris/backups.</small></span></label></Confirm>}
      {confirm?.kind === 'restore' && info && <Confirm title="Restaurar copia" confirmLabel="Restaurar" text="Se restaurarán los archivos de la copia. Antes se guarda el estado actual de todo lo que se vaya a cambiar." onNo={() => setConfirm(null)} onYes={() => { const id = confirm.id!; setConfirm(null); run('Restaurando copia', () => api().restoreBackup(info.folder, id), done); }} />}
      {confirm?.kind === 'rollback' && info && <Confirm danger title="Revertir cambios" confirmLabel="Revertir" text="Se deshará la operación interrumpida y la carpeta volverá al estado anterior." onNo={() => setConfirm(null)} onYes={() => { setConfirm(null); run('Revirtiendo operación interrumpida', () => api().rollbackPending(info.folder), done); }} />}
    </div>
  );
}

/* ------------------------------------------------------------------ SISTEMA */
export function SystemView({ system, onRefresh, minecraft }: { system: SystemInfo | null; onRefresh: () => void; minecraft: string }) {
  const [java, setJava] = useState<JavaCheck | null>(null);
  useEffect(() => { void api().javaCheck(minecraft).then((r) => setJava(r.ok ? r.value : null)); }, [minecraft, system]);
  if (!system) return <div className="muted pad">Analizando el sistema…</div>;
  return (
    <div>
      <div className="head"><div><h1>Diagnóstico del sistema</h1><p className="muted">Lo que el instalador ha detectado en este equipo.</p></div><Button variant="ghost" onClick={onRefresh}>Volver a analizar</Button></div>
      {system.warnings.map((w) => <div key={w} className="note note-warn">⚠ {w}</div>)}
      <div className="panel"><div className="facts">
        <Stat label="Sistema" value={`${system.os.name}${system.os.build ? ` (compilación ${system.os.build})` : ''}`} /><Stat label="Arquitectura" value={system.os.arch} />
        <Stat label="RAM total" value={`${system.ram.totalMB} MB`} /><Stat label="RAM libre" value={`${system.ram.freeMB} MB`} /><Stat label="Núcleos" value={system.cpuCores} />
        <Stat label="Compatible con el instalador" value={system.os.supported ? <Badge tone="ok">Sí</Badge> : <Badge tone="warn">No</Badge>} />
      </div></div>
      <div className="panel"><h3>Java</h3>
        {java && <div className={`note ${java.ok ? 'note-ok' : 'note-warn'}`}>{java.ok ? '✔' : '⚠'} {java.message}</div>}
        {system.java.length === 0 ? <div className="muted small">No se detectó ningún Java.</div> : <table><thead><tr><th>Versión</th><th>Origen</th><th>Ruta</th></tr></thead><tbody>{system.java.map((j) => <tr key={j.path + j.version}><td>{j.version}</td><td>{j.source}</td><td className="mono small">{j.path}</td></tr>)}</tbody></table>}
      </div>
      <div className="panel"><h3>Launchers y carpetas</h3><p className="muted small">«Detectado» solo significa que la carpeta existe. Ningún launcher se ha probado con AETHERIS en un Windows real.</p>
        <table><thead><tr><th>Launcher</th><th>Estado</th><th>Ruta</th><th>Instancias</th></tr></thead><tbody>
          {system.launchers.map((l) => <tr key={l.kind}><td>{l.label}</td><td>{l.exists ? <Badge tone="info">Detectado</Badge> : <Badge tone="mute">No encontrado</Badge>} <Badge tone="warn">No verificado</Badge></td><td className="mono small">{l.path}</td><td>{l.instances.length}</td></tr>)}
        </tbody></table>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ REGISTROS */
export function LogsView({ logFile }: { logFile: string }) {
  const [lines, setLines] = useState<LogLine[]>([]);
  useEffect(() => { let on = true; const t = async () => { const l = await api().readLogs(); if (on) setLines(l); }; void t(); const id = setInterval(() => void t(), 1500); return () => { on = false; clearInterval(id); }; }, []);
  const text = lines.map((l) => `${l.t} [${l.level}] ${l.msg}`).join('\n');
  return (
    <div>
      <div className="head"><div><h1>Registros</h1><p className="muted">Últimos eventos del instalador. El archivo completo está en <span className="mono small">{logFile}</span></p></div>
        <div className="row"><Button variant="ghost" onClick={() => void navigator.clipboard.writeText(text)}>Copiar</Button><Button variant="ghost" onClick={() => api().openFolder(dirname(logFile))}>Abrir carpeta</Button></div></div>
      <div className="log">{lines.length === 0 ? <span className="muted">Sin eventos todavía.</span> : lines.map((l, i) => <div key={i} className={`ll ll-${l.level}`}><span className="lt">{l.t.slice(11, 19)}</span> {l.msg}</div>)}</div>
    </div>
  );
}

/* ------------------------------------------------------------------ ACERCA DE */
export function AboutView({ info }: { info: AppInfo | null }) {
  return (
    <div>
      <div className="head"><div><h1>Acerca de</h1><p className="muted">AETHERIS NEXUS INSTALLER</p></div></div>
      <div className="panel"><div className="facts">
        <Stat label="Versión" value={info?.version ?? '…'} /><Stat label="Electron" value={info?.electron ?? '…'} /><Stat label="Plataforma" value={info ? `${info.platform}/${info.arch}` : '…'} />
        <Stat label="Firma digital" value={<Badge tone="warn">Sin firmar</Badge>} /><Stat label="Datos del instalador" value={<span className="mono small">{info?.userData ?? '…'}</span>} />
      </div></div>
      <div className="panel"><h3>Limitaciones conocidas</h3>
        <ul className="plain">
          <li>El ejecutable no está firmado digitalmente: Windows SmartScreen puede mostrar un aviso la primera vez.</li>
          <li>La integración con launchers distintos del oficial se limita a copiar archivos a la carpeta elegida; ninguno se ha verificado en un Windows real.</li>
          <li>Solo se admiten paquetes .mrpack de Fabric. La compatibilidad real de cada paquete con Minecraft depende del paquete, no del instalador.</li>
          <li>Los perfiles muestran los datos reales de su .mrpack; si dos perfiles tienen los mismos mods, el instalador lo avisa.</li>
        </ul></div>
    </div>
  );
}
