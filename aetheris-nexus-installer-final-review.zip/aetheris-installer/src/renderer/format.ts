export const fmtBytes = (n: number): string => (n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(0)} KB` : n < 1073741824 ? `${(n / 1048576).toFixed(1)} MB` : `${(n / 1073741824).toFixed(2)} GB`);
export const fmtDate = (iso: string): string => { const d = new Date(iso); return Number.isNaN(d.getTime()) ? iso : d.toLocaleString('es-ES', { dateStyle: 'medium', timeStyle: 'short' }); };
export const dirname = (p: string): string => p.replace(/[\\/][^\\/]*$/, '');

/** Qué hacer ante cada código de error (el mensaje en sí ya viene redactado por el motor). */
export function hintFor(code: string): string {
  switch (code) {
    case 'E_DOWNLOAD': return 'Revisa tu conexión a internet y pulsa «Reintentar»: lo ya descargado y verificado no se vuelve a bajar. Tu instalación no se ha modificado.';
    case 'E_HASH': return 'Un archivo no coincide con su huella de seguridad. No se ha instalado. Reintenta; si persiste, el paquete puede estar corrupto.';
    case 'E_CANCELLED': return 'Has cancelado la operación. No se ha modificado nada.';
    case 'E_TXN_PENDING': return 'Una operación anterior se interrumpió. Ve a «Mantenimiento» y pulsa «Revertir cambios» para dejar todo como estaba.';
    case 'E_ROLLBACK': return 'La reversión fue parcial. Ve a «Mantenimiento» y restaura la copia indicada.';
    case 'E_LOADER': return 'Este instalador solo admite paquetes con Fabric.';
    case 'E_PROTECTED': return 'El paquete intenta tocar mundos o datos personales: se ha bloqueado por seguridad.';
    case 'E_PATH': case 'E_ZIP': case 'E_MRPACK': return 'El archivo .mrpack no es válido o no es seguro. No se ha instalado nada.';
    case 'E_TARGET': return 'Elige otra carpeta de destino (mejor una carpeta nueva y propia).';
    case 'E_LAUNCHER': return 'Abre el launcher oficial de Minecraft al menos una vez y vuelve a intentarlo.';
    case 'E_BUSY': return 'Espera a que termine la operación actual.';
    default: return '';
  }
}
