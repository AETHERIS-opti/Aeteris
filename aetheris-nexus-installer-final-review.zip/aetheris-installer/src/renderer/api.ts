import type { AetherisApi } from '../shared/api';
declare global { interface Window { aetheris: AetherisApi } }
export const api = (): AetherisApi => window.aetheris;
