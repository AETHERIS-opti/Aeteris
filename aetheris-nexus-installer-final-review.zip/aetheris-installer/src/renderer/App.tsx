import { useCallback, useEffect, useRef, useState } from 'react';
import type { ProfileSummary, ProfilesReport, SystemInfo } from '../shared/types';
import type { AppInfo, InstallArgs, KnownInstall, ProgressMsg, Result } from '../shared/api';
import { api } from './api';
import { Badge, Button, Logo, ProgressBar } from './ui';
import { AboutView, InstallDialog, LogsView, ManageView, ProfilesView, SystemView } from './views';
import { fmtBytes, hintFor } from './format';

type View = 'profiles' | 'manage' | 'system' | 'logs' | 'about';
interface Op {
  title: string; status: 'running' | 'done' | 'error'; phase: ProgressMsg['phase']; message: string; current?: number; total?: number; bytes?: number; totalBytes?: number; file?: string;
  log: ProgressMsg[]; result?: unknown; error?: { code: string; message: string }; retry: () => void;
}
const NAV: Array<[View, string, string]> = [['profiles', '◈', 'Perfiles'], ['manage', '⚙', 'Mantenimiento'], ['system', '▣', 'Sistema'], ['logs', '≡', 'Registros'], ['about', 'ⓘ', 'Acerca de']];
const STEPS: Array<[ProgressMsg['phase'][], string]> = [[['validate'], 'Validar'], [['download'], 'Descargar'], [['extract'], 'Extraer'], [['commit', 'cleanup', 'verify'], 'Aplicar'], [['done'], 'Listo']];

function percent(o: Op): number {
  if (o.status === 'done') return 100;
  const f = o.total ? (o.current ?? 0) / o.total : 0;
  switch (o.phase) {
    case 'validate': return 4;
    case 'download': return 5 + (o.totalBytes ? (o.bytes ?? 0) / o.totalBytes : f) * 60;
    case 'extract': return 65 + f * 15;
    case 'commit': return 80 + f * 18;
    case 'verify': return f * 100;
    default: return 0;
  }
}

function Summary({ r }: { r: Record<string, unknown> }) {
  const arr = (k: string) => (Array.isArray(r[k]) ? (r[k] as string[]) : []);
  const num = (k: string) => (typeof r[k] === 'number' ? (r[k] as number) : null);
  const skipped = arr('skippedUserConfigs'), kept = arr('keptModified'), dups = arr('duplicates');
  return (
    <div className="summary">
      {typeof r.folder === 'string' && <div className="muted small">Carpeta: <span className="mono">{r.folder}</span></div>}
      <div className="facts">
        {num('installed') !== null && <div className="stat"><span className="stat-l">Instalados / actualizados</span><span className="stat-v">{num('installed')}</span></div>}
        {num('unchanged') !== null && <div className="stat"><span className="stat-l">Ya estaban al día</span><span className="stat-v">{num('unchanged')}</span></div>}
        {typeof r.backupId === 'string' && <div className="stat"><span className="stat-l">Copia automática</span><span className="stat-v mono small">{r.backupId}</span></div>}
      </div>
      {r.launcherProfile === 'created' && <div className="note note-ok">✔ Perfil creado en el launcher oficial. Ábrelo y selecciónalo en la lista de perfiles.</div>}
      {r.launcherProfile === 'failed' && <div className="note note-warn">⚠ Los archivos están instalados, pero no se pudo crear el perfil del launcher: {String(r.launcherError ?? '')}</div>}
      {skipped.length > 0 && <div className="note note-mute">Se respetó tu configuración personal ({skipped.length}): {skipped.slice(0, 5).join(', ')}{skipped.length > 5 ? '…' : ''}</div>}
      {kept.length > 0 && <div className="note note-mute">Se conservaron archivos que habías modificado ({kept.length}): {kept.slice(0, 5).join(', ')}</div>}
      {dups.length > 0 && <div className="note note-warn">⚠ Posibles mods duplicados que ya tenías (no se borran): {dups.join(', ')}</div>}
    </div>
  );
}

function OperationPanel({ op, onClose }: { op: Op; onClose: () => void }) {
  const p = percent(op);
  const cur = STEPS.findIndex(([ph]) => ph.includes(op.phase));
  return (
    <div className="overlay op-overlay" role="dialog" aria-modal="true" aria-label={op.title}>
      <div className="op">
        <div className="op-head"><h2>{op.title}</h2>{op.status === 'running' && <span className="dot-run" aria-label="En curso" />}{op.status === 'done' && <Badge tone="ok">Completado</Badge>}{op.status === 'error' && <Badge tone="err">Error</Badge>}</div>
        <ol className="steps">{STEPS.map(([, name], i) => <li key={name} className={op.status === 'done' || i < cur ? 'st-done' : i === cur && op.status === 'running' ? 'st-cur' : ''}><span>{i + 1}</span>{name}</li>)}</ol>
        <ProgressBar value={p} running={op.status === 'running'} />
        <div className="op-line"><span>{op.message}</span><span className="muted">{op.total ? `${op.current ?? 0}/${op.total}` : ''}{op.totalBytes ? ` · ${fmtBytes(op.bytes ?? 0)} de ${fmtBytes(op.totalBytes)}` : ''}</span></div>
        {op.status === 'error' && op.error && (
          <div className="note note-err"><b>{op.error.message}</b>{hintFor(op.error.code) && <div className="small">{hintFor(op.error.code)}</div>}</div>
        )}
        {op.status === 'done' && op.result && typeof op.result === 'object' && <Summary r={op.result as Record<string, unknown>} />}
        <div className="log log-sm" aria-live="polite">{op.log.slice(-8).map((m, i) => <div key={i} className={`ll ll-${m.level ?? 'info'}`}>{m.message}</div>)}</div>
        <div className="row end">
          {op.status === 'running' && <Button variant="danger" onClick={() => void api().cancel()}>Cancelar</Button>}
          {op.status === 'error' && op.error?.code !== 'E_CANCELLED' && <Button onClick={op.retry}>Reintentar</Button>}
          {op.status !== 'running' && <Button variant={op.status === 'done' ? 'primary' : 'ghost'} onClick={onClose}>Cerrar</Button>}
        </div>
      </div>
    </div>
  );
}

export function App() {
  const [view, setView] = useState<View>('profiles');
  const [report, setReport] = useState<ProfilesReport | null>(null);
  const [system, setSystem] = useState<SystemInfo | null>(null);
  const [installs, setInstalls] = useState<KnownInstall[]>([]);
  const [info, setInfo] = useState<AppInfo | null>(null);
  const [installFor, setInstallFor] = useState<ProfileSummary | null>(null);
  const [op, setOp] = useState<Op | null>(null);
  const [toast, setToast] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const say = (tone: 'ok' | 'err', text: string) => { setToast({ tone, text }); clearTimeout(toastTimer.current); toastTimer.current = setTimeout(() => setToast(null), 7000); };

  const refreshProfiles = useCallback(async () => { const r = await api().listProfiles(); if (r.ok) setReport(r.value); else say('err', r.error.message); }, []);
  const refreshSystem = useCallback(async () => { setSystem(null); const r = await api().getSystem(); if (r.ok) setSystem(r.value); else say('err', r.error.message); }, []);
  const refreshInstalls = useCallback(async () => { const r = await api().listKnownInstalls(); if (r.ok) setInstalls(r.value); }, []);
  useEffect(() => { void refreshProfiles(); void refreshSystem(); void refreshInstalls(); void api().appInfo().then(setInfo); }, [refreshProfiles, refreshSystem, refreshInstalls]);
  useEffect(() => api().onProgress((m) => setOp((o) => (o && o.status === 'running' ? { ...o, phase: m.phase, message: m.message, ...(m.current !== undefined ? { current: m.current } : {}), ...(m.total !== undefined ? { total: m.total } : {}), ...(m.bytes !== undefined ? { bytes: m.bytes } : {}), ...(m.totalBytes !== undefined ? { totalBytes: m.totalBytes } : {}), log: [...o.log.slice(-60), m] } : o))), []);

  const runOp = useCallback((title: string, fn: () => Promise<{ ok: boolean }>, after?: () => void) => {
    const start = () => {
      setOp({ title, status: 'running', phase: 'validate', message: 'Preparando…', log: [], retry: start });
      void fn().then((r) => {
        const res = r as Result<unknown>;
        if (res.ok) { setOp((o) => (o ? { ...o, status: 'done', phase: 'done', message: 'Operación completada', result: res.value } : o)); after?.(); void refreshProfiles(); void refreshInstalls(); }
        else setOp((o) => (o ? { ...o, status: 'error', error: res.error } : o));
      });
    };
    start();
  }, [refreshProfiles, refreshInstalls]);

  const startInstall = (p: ProfileSummary, a: InstallArgs) => { setInstallFor(null); runOp(`Instalando ${p.name}`, () => api().install(a)); };
  const installInto = (profileId: string, folder: string) => {
    const p = report?.profiles.find((x) => x.id === profileId);
    runOp(`Instalando ${p?.name ?? profileId}`, () => api().install({ profileId, target: { kind: 'folder', folder }, userConfigPolicy: 'keep', createLauncherProfile: false }));
  };
  const importPack = async (p: ProfileSummary) => { const r = await api().importPack(p.id); if (!r.ok) say('err', r.error.message); else if (r.value.imported) { say('ok', `Paquete incorporado para ${p.name}`); void refreshProfiles(); } };
  const mc = report?.profiles.find((p) => p.pack)?.pack?.minecraft ?? '26.3';

  return (
    <div className="app">
      <aside className="side">
        <div className="brand"><Logo /><div><div className="brand-t">AETHERIS</div><div className="brand-s">NEXUS INSTALLER</div></div></div>
        <nav>{NAV.map(([v, ic, label]) => <button key={v} type="button" className={`nav${view === v ? ' nav-on' : ''}`} onClick={() => setView(v)}><span className="nav-i" aria-hidden="true">{ic}</span>{label}</button>)}</nav>
        <div className="side-foot"><div className="muted small">v{info?.version ?? '…'}</div><Badge tone="warn">Sin firmar</Badge></div>
      </aside>
      <main className="main">
        <div key={view} className="view">
          {view === 'profiles' && <ProfilesView report={report} onInstall={setInstallFor} onImport={importPack} onRefresh={refreshProfiles} />}
          {view === 'manage' && <ManageView report={report} installs={installs} onRefreshInstalls={refreshInstalls} run={runOp} onInstallInto={installInto} />}
          {view === 'system' && <SystemView system={system} onRefresh={refreshSystem} minecraft={mc} />}
          {view === 'logs' && <LogsView logFile={info?.logFile ?? ''} />}
          {view === 'about' && <AboutView info={info} />}
        </div>
      </main>
      {installFor && <InstallDialog profile={installFor} system={system} onClose={() => setInstallFor(null)} onStart={(a) => startInstall(installFor, a)} />}
      {op && <OperationPanel op={op} onClose={() => setOp(null)} />}
      {toast && <div className={`toast toast-${toast.tone}`} role="status">{toast.text}</div>}
    </div>
  );
}
