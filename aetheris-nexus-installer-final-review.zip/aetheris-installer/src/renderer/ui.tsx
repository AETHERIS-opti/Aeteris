import type { ReactNode } from 'react';

export function Logo({ size = 34 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
      <defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#4cc9f0" /><stop offset="1" stopColor="#8b5cf6" /></linearGradient></defs>
      <polygon points="24,3 43,14 43,34 24,45 5,34 5,14" fill="none" stroke="url(#lg)" strokeWidth="2.5" />
      <path d="M15 33 L24 13 L33 33 M18.5 26.5 H29.5" fill="none" stroke="url(#lg)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Badge({ tone, children }: { tone: 'ok' | 'warn' | 'err' | 'info' | 'mute'; children: ReactNode }) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

export function Button({ children, onClick, variant = 'primary', disabled, title }: { children: ReactNode; onClick?: () => void; variant?: 'primary' | 'ghost' | 'danger'; disabled?: boolean; title?: string }) {
  return <button type="button" className={`btn btn-${variant}`} onClick={onClick} disabled={disabled} title={title}>{children}</button>;
}

export function ProgressBar({ value, running }: { value: number; running?: boolean }) {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div className="bar" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(pct)}>
      <div className={`bar-fill${running ? ' bar-run' : ''}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function Modal({ title, children, onClose, wide }: { title: string; children: ReactNode; onClose?: () => void; wide?: boolean }) {
  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(e) => { if (e.target === e.currentTarget) onClose?.(); }}>
      <div className={`modal${wide ? ' modal-wide' : ''}`}>
        <div className="modal-head"><h2>{title}</h2>{onClose && <button type="button" className="x" onClick={onClose} aria-label="Cerrar">×</button>}</div>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
}

export function Confirm({ title, text, confirmLabel, danger, onYes, onNo, children }: { title: string; text: string; confirmLabel: string; danger?: boolean; onYes: () => void; onNo: () => void; children?: ReactNode }) {
  return (
    <Modal title={title} onClose={onNo}>
      <p className="muted">{text}</p>
      {children}
      <div className="row end"><Button variant="ghost" onClick={onNo}>Cancelar</Button><Button variant={danger ? 'danger' : 'primary'} onClick={onYes}>{confirmLabel}</Button></div>
    </Modal>
  );
}

export function Stat({ label, value }: { label: string; value: ReactNode }) {
  return <div className="stat"><span className="stat-l">{label}</span><span className="stat-v">{value}</span></div>;
}
