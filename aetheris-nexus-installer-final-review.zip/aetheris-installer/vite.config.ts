import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Interfaz (renderer) de Electron. 'base: ./' es imprescindible para cargarla con file:// desde la app empaquetada.
export default defineConfig({
  base: './',
  plugins: [react()],
  build: { outDir: 'dist/renderer', emptyOutDir: true, sourcemap: false, target: 'chrome140' },
  server: { port: 5173, strictPort: true },
});
