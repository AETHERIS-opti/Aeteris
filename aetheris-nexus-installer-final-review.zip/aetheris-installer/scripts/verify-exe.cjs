/* Verifica que un .exe de Windows es x64 (cabecera PE) y no está vacío. Uso: node scripts/verify-exe.cjs <ruta.exe> */
const fs = require('node:fs');
function peMachine(file) {
  const fd = fs.openSync(file, 'r');
  try {
    const dos = Buffer.alloc(64); fs.readSync(fd, dos, 0, 64, 0);
    if (dos.readUInt16LE(0) !== 0x5a4d) throw new Error('No es un ejecutable de Windows (falta la firma MZ)');
    const off = dos.readUInt32LE(0x3c); const pe = Buffer.alloc(6); fs.readSync(fd, pe, 0, 6, off);
    if (pe.readUInt32LE(0) !== 0x00004550) throw new Error('Cabecera PE inválida');
    return pe.readUInt16LE(4);
  } finally { fs.closeSync(fd); }
}
module.exports = { peMachine };
if (require.main === module) {
  const f = process.argv[2]; const st = fs.statSync(f); const m = peMachine(f);
  const names = { 0x8664: 'x64 (AMD64)', 0x14c: 'x86', 0xaa64: 'ARM64' };
  console.log(`${f}: ${(st.size / 1048576).toFixed(1)} MB, arquitectura ${names[m] ?? '0x' + m.toString(16)}`);
  if (m !== 0x8664) { console.error('ERROR: no es x64'); process.exit(1); }
  if (st.size < 10 * 1048576) { console.error('ERROR: el instalador es sospechosamente pequeño'); process.exit(1); }
}
