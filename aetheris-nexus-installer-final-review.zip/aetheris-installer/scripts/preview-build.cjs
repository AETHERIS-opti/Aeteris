/* Ayuda de desarrollo SOLO para entornos sin acceso a npm: empaqueta la interfaz con esbuild (que no es la ruta de producción;
   el build real usa Vite, ver package.json) para poder probar la UI en un navegador headless con una API simulada. */
const path = require('node:path');
const fs = require('node:fs');
const esbuildPath = process.env.ESBUILD_PATH || '/opt/npm-tools/node_modules/esbuild';
const esbuild = require(esbuildPath);
const out = path.join(__dirname, '..', 'dist-preview');
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
esbuild.buildSync({
  entryPoints: [path.join(__dirname, '..', 'src/renderer/main.tsx')], bundle: true, outdir: out, entryNames: 'app', jsx: 'automatic', format: 'iife', target: 'chrome120',
  define: { 'process.env.NODE_ENV': '"production"' }, nodePaths: [process.env.REACT_PATH || '/usr/local/lib/node_modules_global'], logLevel: 'warning', minify: false,
});
fs.writeFileSync(path.join(out, 'index.html'), '<!doctype html><html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>AETHERIS NEXUS INSTALLER</title><link rel="stylesheet" href="app.css"></head><body><div id="root"></div><script src="app.js"></script></body></html>');
console.log('preview listo en', out, fs.readdirSync(out).join(', '));
