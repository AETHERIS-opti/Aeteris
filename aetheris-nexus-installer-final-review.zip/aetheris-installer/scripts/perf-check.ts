/* Medición de rendimiento del motor en ESTE equipo (no es un benchmark de Minecraft). Uso: tsx scripts/perf-check.ts */
import http from 'node:http';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { installOrUpdate } from '../src/core/engine';
import { buildZip } from '../tests/helpers';

(async () => {
  const MB = 300, CH = Buffer.alloc(1024 * 1024, 7); const h1 = createHash('sha1'), h5 = createHash('sha512');
  for (let i = 0; i < MB; i++) { h1.update(CH); h5.update(CH); }
  const srv = http.createServer((_q, res) => { res.setHeader('Content-Length', MB * 1048576); let i = 0; const w = () => { while (i < MB) { i++; if (!res.write(CH)) return void res.once('drain', w); } res.end(); }; w(); });
  await new Promise<void>((r) => srv.listen(0, '127.0.0.1', r)); const base = `http://127.0.0.1:${(srv.address() as { port: number }).port}`;
  const d = await fs.mkdtemp(path.join(os.tmpdir(), 'perf-'));
  const files = [{ path: 'mods/grande-1.jar', hashes: { sha1: h1.digest('hex'), sha512: h5.digest('hex') }, env: { client: 'required', server: 'unsupported' }, downloads: [`${base}/g`], fileSize: MB * 1048576 }];
  const small: Record<string, string> = {}; for (let i = 0; i < 400; i++) small[`config/c${i}.toml`] = 'x=' + i + '\n'.repeat(50);
  const idx = { formatVersion: 1, game: 'minecraft', versionId: 'p', name: 'perf', files, dependencies: { minecraft: '26.3', 'fabric-loader': '0.19.5' } };
  const zip = path.join(d, 'perf.mrpack');
  await fs.writeFile(zip, buildZip([{ name: 'modrinth.index.json', data: JSON.stringify(idx), deflate: true }, ...Object.entries(small).map(([k, v]) => ({ name: 'overrides/' + k, data: v, deflate: true }))]));
  let peak = 0; const t = setInterval(() => { peak = Math.max(peak, process.memoryUsage().rss); }, 20); const base0 = process.memoryUsage().rss;
  const t0 = performance.now();
  const r = await installOrUpdate({ instanceDir: path.join(d, 'inst'), mrpackPath: zip, profileId: 'perf', policy: { allowedHosts: ['127.0.0.1'], allowHttp: true } });
  const ms = performance.now() - t0; clearInterval(t);
  console.log(JSON.stringify({ archivos: r.installed, datos_MB: MB, tiempo_s: +(ms / 1000).toFixed(2), rss_inicial_MB: +(base0 / 1048576).toFixed(0), rss_pico_MB: +(peak / 1048576).toFixed(0), incremento_pico_MB: +((peak - base0) / 1048576).toFixed(0), nodo: process.version, cpu: os.cpus()[0]?.model }, null, 2));
  srv.close(); await fs.rm(d, { recursive: true, force: true });
})();
