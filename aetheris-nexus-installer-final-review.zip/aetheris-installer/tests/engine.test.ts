/** Pruebas REALES del código del motor sobre el sistema de archivos, con paquetes y servidor HTTP SINTÉTICOS. No prueban Minecraft. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { installOrUpdate, repair, uninstall, verifyIntegrity, rollbackPending, pendingTransaction, getInstallInfo, SimulatedCrash } from '../src/core/engine';
import { createManualBackup, listBackups, restoreBackup } from '../src/core/backup';
import { startServer, tmpDir, makeMrpack, TEST_POLICY, sha256, type TestServer } from './helpers';

const base = { policy: TEST_POLICY, backoffMs: 2, retries: 1 };
const rd = (p: string) => fs.readFile(p, 'utf8');
const exists = (p: string) => fs.stat(p).then(() => true, () => false);

async function snapshotTree(dir: string, skip = ['.aetheris']): Promise<Record<string, string>> {
  const out: Record<string, string> = {};
  async function w(d: string) {
    for (const e of await fs.readdir(d, { withFileTypes: true })) {
      if (skip.includes(e.name) && d === dir) continue;
      const p = path.join(d, e.name);
      if (e.isDirectory()) await w(p); else out[path.relative(dir, p)] = sha256(await fs.readFile(p));
    }
  }
  await w(dir); return out;
}
async function userStuff(inst: string) {
  const f: Record<string, string> = { 'saves/Mundo1/level.dat': 'NBT-datos-del-mundo', 'saves/Mundo1/region/r.0.0.mca': 'region', 'screenshots/2026-11-07.png': 'png', 'servers.dat': 'servidores', 'logs/latest.log': 'log' };
  for (const [k, v] of Object.entries(f)) { await fs.mkdir(path.dirname(path.join(inst, k)), { recursive: true }); await fs.writeFile(path.join(inst, k), v); }
  return f;
}
const checkUser = async (inst: string, f: Record<string, string>) => { for (const [k, v] of Object.entries(f)) assert.equal(await rd(path.join(inst, k)), v, `se alteró ${k}`); };

const V1 = [{ path: 'mods/sodium-1.0.jar', content: 'SODIUM1' }, { path: 'mods/lithium-1.0.jar', content: 'LITHIUM1' }, { path: 'mods/servidor-solo.jar', content: 'SRV', env: { client: 'unsupported', server: 'required' } }];
async function setup(extra: Partial<Parameters<typeof makeMrpack>[0]> = {}) {
  const s = await startServer(); const d = await tmpDir(); const inst = path.join(d, 'instancia');
  const pack = await makeMrpack({ dir: d, server: s, files: V1, overrides: { 'config/mod.toml': 'valor=1', 'options.txt': 'fov:70', 'resourcepacks/pack.zip': 'RP1' }, clientOverrides: { 'config/mod.toml': 'valor=cliente' }, ...extra });
  return { s, d, inst, pack };
}

test('instalar: descargas verificadas, overrides con client-overrides, env.client=unsupported omitido, registro y copia del paquete', async () => {
  const { s, d, inst, pack } = await setup();
  try {
    const user = await userStuff(inst);
    const events: string[] = [];
    const r = await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps', onProgress: (e) => events.push(e.phase) });
    assert.equal(r.op, 'install'); assert.equal(r.installed, 5);
    assert.equal(await rd(path.join(inst, 'mods/sodium-1.0.jar')), 'SODIUM1');
    assert.equal(await rd(path.join(inst, 'config/mod.toml')), 'valor=cliente');
    assert.ok(!(await exists(path.join(inst, 'mods/servidor-solo.jar'))));
    const info = await getInstallInfo(inst);
    assert.equal(info?.profileId, 'fps'); assert.equal(info?.minecraft, '26.3'); assert.equal(info?.fileCount, 5);
    assert.ok(await exists(path.join(inst, '.aetheris/pack.mrpack'))); assert.ok(!(await exists(path.join(inst, '.aetheris/staging'))));
    assert.ok(events.includes('download') && events.includes('extract') && events.includes('commit') && events.includes('done'));
    await checkUser(inst, user);
    assert.equal((await verifyIntegrity(inst)).ok, 5);
  } finally { await s.close(); void d; }
});

test('fallo de descarga: no se modifica NADA del destino; el reintento reutiliza lo ya descargado', async () => {
  const s = await startServer(); const d = await tmpDir(); const inst = path.join(d, 'i');
  try {
    const pack = await makeMrpack({ dir: d, server: s, files: V1 });
    s.routes.delete('/files/v1/mods/lithium-1.0.jar'); // simula caída de un archivo
    const user = await userStuff(inst); const before = await snapshotTree(inst);
    await assert.rejects(installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps' }), (e: Error & { code?: string; details?: { failed: unknown[] } }) => e.code === 'E_DOWNLOAD' && e.details!.failed.length === 1);
    assert.deepEqual(await snapshotTree(inst), before); assert.ok(!(await exists(path.join(inst, '.aetheris/install.json'))));
    const hitsSodium = s.hits.get('/files/v1/mods/sodium-1.0.jar');
    await makeMrpack({ dir: d, server: s, files: V1 }); // el servidor vuelve a servir todo
    const r = await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps' });
    assert.equal(r.installed, 2); assert.equal(s.hits.get('/files/v1/mods/sodium-1.0.jar'), hitsSodium, 'lo ya verificado no se vuelve a descargar');
    await checkUser(inst, user);
  } finally { await s.close(); }
});

test('hash manipulado en el servidor: la instalación se rechaza y no se escribe el archivo', async () => {
  const s = await startServer(); const d = await tmpDir(); const inst = path.join(d, 'i');
  try {
    const pack = await makeMrpack({ dir: d, server: s, files: V1 });
    s.routes.set('/files/v1/mods/sodium-1.0.jar', (_q, res) => res.end('MALWARE'));
    await assert.rejects(installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps' }), (e: Error & { code?: string }) => e.code === 'E_DOWNLOAD');
    assert.ok(!(await exists(path.join(inst, 'mods'))));
  } finally { await s.close(); }
});

test('configuración personal: por defecto se respeta (y se informa); con "replace" se reemplaza tras respaldar', async () => {
  const { s, inst, pack, d } = await setup();
  try {
    await fs.mkdir(path.join(inst, 'config'), { recursive: true });
    await fs.writeFile(path.join(inst, 'options.txt'), 'fov:110 (mía)'); await fs.writeFile(path.join(inst, 'config/mod.toml'), 'valor=MIO');
    const r = await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'eq' });
    assert.deepEqual(r.skippedUserConfigs.sort(), ['config/mod.toml', 'options.txt']);
    assert.equal(await rd(path.join(inst, 'options.txt')), 'fov:110 (mía)'); assert.equal(await rd(path.join(inst, 'config/mod.toml')), 'valor=MIO');
    assert.equal((await getInstallInfo(inst))!.files['options.txt'], undefined, 'lo que respetamos no se registra como nuestro');
    // misma carpeta, otra vez, con replace
    const pack2 = await makeMrpack({ dir: d, server: s, versionId: 'v2', files: V1, overrides: { 'config/mod.toml': 'valor=1', 'options.txt': 'fov:70' } });
    const r2 = await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack2, profileId: 'eq', userConfigPolicy: 'replace' });
    assert.equal(await rd(path.join(inst, 'options.txt')), 'fov:70');
    assert.ok(r2.backupId); assert.equal(await rd(path.join(inst, '.aetheris/backups', r2.backupId!, 'files/options.txt')), 'fov:110 (mía)');
  } finally { await s.close(); }
});

test('reversión: un fallo A MITAD de la aplicación deja todo exactamente como estaba', async () => {
  const { s, inst, pack, d } = await setup();
  try {
    await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps' });
    const user = await userStuff(inst); const before = await snapshotTree(inst);
    const files2 = [{ path: 'mods/sodium-2.0.jar', content: 'SODIUM2' }, { path: 'mods/nuevo-1.0.jar', content: 'NUEVO' }];
    const pack2 = await makeMrpack({ dir: d, server: s, versionId: 'v2', files: files2, overrides: { 'config/mod.toml': 'valor=2', 'resourcepacks/pack.zip': 'RP2' } });
    await assert.rejects(installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack2, profileId: 'fps', hooks: { failAfter: 2 } }), /fallo simulado|revirtieron/);
    assert.deepEqual(await snapshotTree(inst), before, 'el árbol de archivos debe ser idéntico al anterior');
    assert.equal(await pendingTransaction(inst), null);
    assert.equal((await getInstallInfo(inst))!.packVersionId, 'v1');
    await checkUser(inst, user);
  } finally { await s.close(); }
});

test('corte de proceso a mitad: la siguiente operación lo detecta, se niega a continuar y "revertir" restaura el estado', async () => {
  const { s, inst, pack, d } = await setup();
  try {
    await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps' });
    const before = await snapshotTree(inst);
    const pack2 = await makeMrpack({ dir: d, server: s, versionId: 'v2', files: [{ path: 'mods/sodium-2.0.jar', content: 'S2' }, { path: 'mods/otro-1.0.jar', content: 'O' }], overrides: { 'config/mod.toml': 'valor=2' } });
    await assert.rejects(installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack2, profileId: 'fps', hooks: { crashAfter: 1 } }), SimulatedCrash);
    assert.notDeepEqual(await snapshotTree(inst), before, 'tras el corte hay cambios a medias');
    assert.ok(await pendingTransaction(inst));
    await assert.rejects(installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack2, profileId: 'fps' }), (e: Error & { code?: string }) => e.code === 'E_TXN_PENDING');
    await assert.rejects(uninstall({ ...base, instanceDir: inst }), (e: Error & { code?: string }) => e.code === 'E_TXN_PENDING');
    await rollbackPending(inst);
    assert.deepEqual(await snapshotTree(inst), before); assert.equal(await pendingTransaction(inst), null);
    const ok = await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack2, profileId: 'fps' });
    assert.equal(ok.op, 'update');
  } finally { await s.close(); }
});

test('actualizar y cambiar de perfil: retira lo antiguo sin modificar, conserva lo que el usuario cambió, avisa de duplicados', async () => {
  const { s, inst, pack, d } = await setup();
  try {
    await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps' });
    await fs.writeFile(path.join(inst, 'mods/lithium-1.0.jar'), 'EDITADO-POR-EL-USUARIO');
    await fs.writeFile(path.join(inst, 'mods/sodium-0.5.jar'), 'JAR-DEL-USUARIO'); // mismo mod, otra versión, no instalado por nosotros
    const pack2 = await makeMrpack({ dir: d, server: s, versionId: 'v2', name: 'Otro perfil', files: [{ path: 'mods/sodium-2.0.jar', content: 'S2' }], overrides: {} });
    const r = await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack2, profileId: 'pvp' });
    assert.equal(r.op, 'switch');
    assert.ok(!(await exists(path.join(inst, 'mods/sodium-1.0.jar'))), 'el mod antiguo sin tocar se retira');
    assert.equal(await rd(path.join(inst, 'mods/lithium-1.0.jar')), 'EDITADO-POR-EL-USUARIO'); assert.deepEqual(r.keptModified, ['mods/lithium-1.0.jar']);
    assert.ok(r.duplicates.includes('mods/sodium-0.5.jar')); assert.equal(await rd(path.join(inst, 'mods/sodium-0.5.jar')), 'JAR-DEL-USUARIO');
    assert.equal((await getInstallInfo(inst))!.profileId, 'pvp');
    assert.ok(r.backupId && await exists(path.join(inst, '.aetheris/backups', r.backupId, 'files/mods/sodium-1.0.jar')));
  } finally { await s.close(); }
});

test('reparar: restaura archivos borrados o corruptos; respeta configuraciones editadas por el usuario', async () => {
  const { s, inst, pack } = await setup();
  try {
    await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps' });
    const user = await userStuff(inst);
    await fs.rm(path.join(inst, 'mods/sodium-1.0.jar')); await fs.writeFile(path.join(inst, 'mods/lithium-1.0.jar'), 'CORRUPTO'); await fs.writeFile(path.join(inst, 'config/mod.toml'), 'valor=editado');
    const rep = await verifyIntegrity(inst);
    assert.deepEqual(rep.missing, ['mods/sodium-1.0.jar']); assert.deepEqual(rep.modified.sort(), ['config/mod.toml', 'mods/lithium-1.0.jar']);
    const r = await repair({ ...base, instanceDir: inst });
    assert.deepEqual(r.repaired.sort(), ['mods/lithium-1.0.jar', 'mods/sodium-1.0.jar']);
    assert.equal(await rd(path.join(inst, 'mods/sodium-1.0.jar')), 'SODIUM1'); assert.equal(await rd(path.join(inst, 'mods/lithium-1.0.jar')), 'LITHIUM1');
    assert.equal(await rd(path.join(inst, 'config/mod.toml')), 'valor=editado'); assert.deepEqual(r.skippedUserConfigs, ['config/mod.toml']);
    await checkUser(inst, user);
    const again = await repair({ ...base, instanceDir: inst, userConfigPolicy: 'replace' });
    assert.deepEqual(again.repaired, ['config/mod.toml']); assert.equal(await rd(path.join(inst, 'config/mod.toml')), 'valor=cliente');
    assert.equal((await repair({ ...base, instanceDir: inst })).repaired.length, 0);
  } finally { await s.close(); }
});

test('desinstalar: solo lo registrado; mundos, capturas, partidas y mods del usuario intactos; lo modificado se conserva', async () => {
  const { s, inst, pack } = await setup();
  try {
    const user = await userStuff(inst); await fs.mkdir(path.join(inst, 'mods'), { recursive: true });
    await fs.writeFile(path.join(inst, 'mods/mi-mod-propio.jar'), 'MIO');
    await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps' });
    await fs.writeFile(path.join(inst, 'mods/lithium-1.0.jar'), 'MODIFICADO');
    const r = await uninstall({ ...base, instanceDir: inst });
    assert.deepEqual(r.keptModified, ['mods/lithium-1.0.jar']); assert.ok(r.removed.includes('mods/sodium-1.0.jar'));
    assert.ok(!(await exists(path.join(inst, 'mods/sodium-1.0.jar')))); assert.ok(!(await exists(path.join(inst, 'resourcepacks'))), 'carpeta vacía creada por nosotros');
    assert.equal(await rd(path.join(inst, 'mods/mi-mod-propio.jar')), 'MIO'); assert.equal(await rd(path.join(inst, 'mods/lithium-1.0.jar')), 'MODIFICADO');
    await checkUser(inst, user);
    assert.equal(await getInstallInfo(inst), null);
    assert.ok(r.backupId && await exists(path.join(inst, '.aetheris/backups', r.backupId, 'files/mods/sodium-1.0.jar')));
    await assert.rejects(uninstall({ ...base, instanceDir: inst }), (e: Error & { code?: string }) => e.code === 'E_NOT_INSTALLED');
  } finally { await s.close(); }
});

test('copias de seguridad manuales: crear, modificar, restaurar; no incluyen mundos; la restauración guarda antes el estado actual', async () => {
  const { s, inst, pack } = await setup();
  try {
    await installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps' });
    const user = await userStuff(inst); await fs.writeFile(path.join(inst, 'options.txt'), 'fov:90');
    const b = await createManualBackup(inst, 'antes de probar');
    assert.ok(b.files.every((f) => !f.rel.startsWith('saves/') && !f.rel.startsWith('screenshots/')));
    assert.ok(b.files.some((f) => f.rel === 'options.txt') && b.files.some((f) => f.rel === 'mods/sodium-1.0.jar'));
    await fs.writeFile(path.join(inst, 'options.txt'), 'fov:30'); await fs.rm(path.join(inst, 'mods/sodium-1.0.jar'));
    const r = await restoreBackup(inst, b.id);
    assert.equal(await rd(path.join(inst, 'options.txt')), 'fov:90'); assert.equal(await rd(path.join(inst, 'mods/sodium-1.0.jar')), 'SODIUM1');
    assert.equal(await rd(path.join(inst, '.aetheris/backups', r.preRestoreBackupId, 'files/options.txt')), 'fov:30');
    await checkUser(inst, user);
    assert.equal((await listBackups(inst)).filter((x) => x.kind === 'manual').length, 1);
    await assert.rejects(restoreBackup(inst, '../../etc'), /inválido/);
    // copia dañada: no se toca nada
    await fs.writeFile(path.join(inst, '.aetheris/backups', b.id, 'files/options.txt'), 'basura'); await fs.writeFile(path.join(inst, 'options.txt'), 'fov:11');
    await assert.rejects(restoreBackup(inst, b.id), /dañada/); assert.equal(await rd(path.join(inst, 'options.txt')), 'fov:11');
  } finally { await s.close(); }
});

test('seguridad: un enlace simbólico que sale del destino no permite escribir fuera; destinos no aceptables se rechazan', async () => {
  const { s, d, pack } = await setup();
  try {
    const inst = path.join(d, 'inst2'); const afuera = path.join(d, 'afuera'); await fs.mkdir(inst); await fs.mkdir(afuera);
    await fs.symlink(afuera, path.join(inst, 'mods'));
    await assert.rejects(installOrUpdate({ ...base, instanceDir: inst, mrpackPath: pack, profileId: 'fps' }), (e: Error & { code?: string }) => e.code === 'E_PATH');
    assert.deepEqual(await fs.readdir(afuera), []);
    for (const bad of ['relativa/x', 'C:\\Windows\\System32', 'C:\\']) await assert.rejects(installOrUpdate({ ...base, instanceDir: bad, mrpackPath: pack, profileId: 'fps' }), (e: Error & { code?: string }) => e.code === 'E_TARGET');
  } finally { await s.close(); }
});

test('cancelar durante la descarga: sin cambios; dos operaciones simultáneas en la misma carpeta: la segunda se rechaza', async () => {
  const { s, d, inst } = await setup();
  try {
    const user = await userStuff(inst); const before = await snapshotTree(inst);
    s.routes.set('/files/vlento/mods/a-1.jar', (_q, res) => { res.write('x'); });
    const slow = await makeMrpack({ dir: d, server: s, versionId: 'vlento', name: 'lento', files: [{ path: 'mods/a-1.jar', content: 'AAA' }] });
    s.routes.set('/files/vlento/mods/a-1.jar', (_q, res) => { res.write('x'); });
    const ctl = new AbortController(); setTimeout(() => ctl.abort(), 100);
    const p1 = installOrUpdate({ ...base, instanceDir: inst, mrpackPath: slow, profileId: 'fps', signal: ctl.signal });
    await new Promise((r) => setTimeout(r, 20));
    await assert.rejects(installOrUpdate({ ...base, instanceDir: inst, mrpackPath: slow, profileId: 'fps' }), (e: Error & { code?: string }) => e.code === 'E_BUSY');
    await assert.rejects(p1, (e: Error & { code?: string }) => e.code === 'E_CANCELLED');
    assert.deepEqual(await snapshotTree(inst), before); await checkUser(inst, user);
  } finally { await s.close(); }
});

test('paquete de otro cargador o con rutas protegidas: se rechaza antes de descargar nada', async () => {
  const { s, d, inst } = await setup();
  try {
    const forge = await makeMrpack({ dir: d, server: s, name: 'forge', loader: 'forge', files: V1 });
    await assert.rejects(installOrUpdate({ ...base, instanceDir: inst, mrpackPath: forge, profileId: 'x' }), (e: Error & { code?: string }) => e.code === 'E_LOADER');
    const evil = await makeMrpack({ dir: d, server: s, name: 'evil', overrides: { 'saves/Mundo1/level.dat': 'BORRADO' } });
    await assert.rejects(installOrUpdate({ ...base, instanceDir: inst, mrpackPath: evil, profileId: 'x' }), (e: Error & { code?: string }) => e.code === 'E_PROTECTED');
    assert.equal(s.hits.size, 0, 'no se descargó nada');
  } finally { await s.close(); void (null as unknown as TestServer); }
});
