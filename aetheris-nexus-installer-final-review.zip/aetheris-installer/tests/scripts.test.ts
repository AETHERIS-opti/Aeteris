import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { tmpDir } from './helpers';
const { peMachine } = createRequire(__filename)('../scripts/verify-exe.cjs') as { peMachine(f: string): number };

function fakePe(machine: number): Buffer {
  const b = Buffer.alloc(256); b.write('MZ', 0, 'latin1'); b.writeUInt32LE(0x80, 0x3c); b.writeUInt32LE(0x00004550, 0x80); b.writeUInt16LE(machine, 0x84); return b;
}
test('verify-exe: distingue x64, x86, ARM64 y rechaza lo que no es un ejecutable (cabeceras PE SINTÉTICAS)', async () => {
  const d = await tmpDir();
  for (const [m, name] of [[0x8664, 'x64'], [0x14c, 'x86'], [0xaa64, 'arm']] as const) { const f = path.join(d, name + '.exe'); await fs.writeFile(f, fakePe(m)); assert.equal(peMachine(f), m); }
  const bad = path.join(d, 'no.exe'); await fs.writeFile(bad, Buffer.from('texto'.repeat(30))); assert.throws(() => peMachine(bad), /MZ/);
});
