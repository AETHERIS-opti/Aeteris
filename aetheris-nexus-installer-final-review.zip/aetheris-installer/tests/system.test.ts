/** Detección, launcher y perfiles. Usa contextos FALSOS y un servidor local: prueba la lógica, no un Windows real ni el launcher real. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { detectSystem, parseJavaVersion, requiredJava, checkJava, windowsName, type DetectContext } from '../src/core/detect';
import { installOfficialLauncherProfile, removeOfficialLauncherProfile, fetchFabricProfile } from '../src/core/launcher';
import { listProfiles, importPack, loadConfig } from '../src/core/profiles';
import { makeMrpack, startServer, tmpDir, TEST_POLICY, serve } from './helpers';

function fakeCtx(files: string[], javaOut: Record<string, string>, over: Partial<DetectContext> = {}): DetectContext {
  const set = new Set(files.map((f) => path.normalize(f)));
  return {
    platform: 'win32', arch: 'x64', release: '10.0.22631', totalmem: 16 * 1024 ** 3, freemem: 8 * 1024 ** 3, cpus: 8,
    env: { APPDATA: 'C:\\Users\\u\\AppData\\Roaming', ProgramFiles: 'C:\\Program Files', JAVA_HOME: undefined }, homedir: 'C:\\Users\\u',
    exists: async (p) => set.has(path.normalize(p)) || [...set].some((f) => f.startsWith(path.normalize(p) + path.sep)),
    readdir: async (p) => { const n = path.normalize(p) + path.sep; return [...new Set([...set].filter((f) => f.startsWith(n)).map((f) => f.slice(n.length).split(path.sep)[0]!))]; },
    javaVersionOutput: async (j) => { if (j in javaOut) return javaOut[j]!; throw new Error('no ejecutable'); }, ...over,
  };
}

test('detect: parseo de versiones de Java, Windows 10/11, requisito de Java por versión de Minecraft', () => {
  assert.deepEqual(parseJavaVersion('openjdk version "21.0.12.1" 2026-08-18'), { version: '21.0.12.1', major: 21 });
  assert.deepEqual(parseJavaVersion('java version "1.8.0_391"'), { version: '1.8.0_391', major: 8 });
  assert.deepEqual(parseJavaVersion('openjdk version "25" 2026-09-15'), { version: '25', major: 25 });
  assert.equal(parseJavaVersion('basura'), null);
  assert.equal(windowsName('10.0.22631').name, 'Windows 11'); assert.equal(windowsName('10.0.19045').name, 'Windows 10'); assert.equal(windowsName('6.1.7601').supported, false);
  assert.deepEqual([requiredJava('26.3').major, requiredJava('26.3').confirmed], [25, true]);
  assert.equal(requiredJava('26.9').confirmed, false);
  assert.deepEqual(['1.21.4', '1.20.5', '1.20.4', '1.18.2', '1.17.1', '1.16.5'].map((v) => requiredJava(v).major), [21, 21, 17, 17, 16, 8]);
});

test('detect: encuentra Java en rutas conocidas, el del launcher oficial y launchers con sus instancias; Java insuficiente se explica', async () => {
  const P = 'C:\\Program Files'; const A = 'C:\\Users\\u\\AppData\\Roaming';
  const files = [path.join(P, 'Eclipse Adoptium', 'jdk-21', 'bin', 'java.exe'), path.join(A, '.minecraft', 'runtime', 'java-runtime-epsilon', 'windows-x64', 'java-runtime-epsilon', 'bin', 'java.exe'),
    path.join(A, '.minecraft', 'launcher_profiles.json'), path.join(A, 'PrismLauncher', 'instances', 'MiPack', 'minecraft', 'mods', 'x.jar')];
  const out = { [path.join(P, 'Eclipse Adoptium', 'jdk-21', 'bin', 'java.exe')]: 'openjdk version "21.0.4"', [path.join(A, '.minecraft', 'runtime', 'java-runtime-epsilon', 'windows-x64', 'java-runtime-epsilon', 'bin', 'java.exe')]: 'openjdk version "25.0.1"' };
  const s = await detectSystem(fakeCtx(files, out));
  assert.deepEqual(s.java.map((j) => j.major), [25, 21]); assert.equal(s.os.name, 'Windows 11'); assert.ok(s.os.supported); assert.equal(s.ram.totalMB, 16384);
  assert.ok(s.minecraftDir?.exists); const prism = s.launchers.find((l) => l.kind === 'prism')!;
  assert.ok(prism.exists && prism.verified === false && prism.instances[0]!.gameDir.endsWith(path.join('MiPack', 'minecraft')));
  assert.ok(s.launchers.every((l) => l.verified === false), 'ningún launcher se declara verificado');
  assert.ok(checkJava(s.java, '26.3').ok); assert.equal(checkJava(s.java, '26.3').best!.major, 25);
  const old = checkJava([{ path: 'j', version: '21', major: 21, source: 'x' }], '26.3'); assert.ok(!old.ok && /25/.test(old.message));
  assert.ok(!checkJava([], '26.3').ok);
  const low = await detectSystem(fakeCtx([], {}, { totalmem: 2 * 1024 ** 3, arch: 'arm64', platform: 'linux' }));
  assert.ok(low.warnings.length >= 3 && !low.os.supported);
});

const FABRIC = (mc: string, l: string) => JSON.stringify({ id: `fabric-loader-${l}-${mc}`, inheritsFrom: mc, type: 'release', mainClass: 'net.fabricmc.loader.impl.launch.knot.KnotClient', libraries: [] });

test('launcher: crea perfil con gameDir aislado, copia de seguridad de launcher_profiles.json, conserva los perfiles del usuario y se desinstala limpio', async () => {
  const s = await startServer(); const d = await tmpDir(); const mcDir = path.join(d, '.minecraft'); const game = path.join(d, 'inst');
  try {
    serve(s, '/v2/versions/loader/26.3/0.19.5/profile/json', FABRIC('26.3', '0.19.5'));
    await fs.mkdir(mcDir, { recursive: true }); await fs.mkdir(game, { recursive: true });
    const mine = { profiles: { mio: { name: 'Mi perfil', type: 'custom', lastVersionId: '1.21' } }, settings: { x: 1 }, version: 3 };
    await fs.writeFile(path.join(mcDir, 'launcher_profiles.json'), JSON.stringify(mine));
    const info = await installOfficialLauncherProfile({ minecraftDir: mcDir, gameDir: game, profileId: 'fps', profileName: 'AETHERIS FPS', minecraft: '26.3', loaderVersion: '0.19.5' }, { metaBase: s.base });
    const after = JSON.parse(await fs.readFile(path.join(mcDir, 'launcher_profiles.json'), 'utf8'));
    assert.deepEqual(after.profiles.mio, mine.profiles.mio); assert.deepEqual(after.settings, mine.settings);
    assert.equal(after.profiles['aetheris-fps'].gameDir, game); assert.equal(after.profiles['aetheris-fps'].lastVersionId, 'fabric-loader-0.19.5-26.3');
    assert.ok(info.createdVersionFile); assert.ok((await fs.readdir(path.join(game, '.aetheris/launcher-backups'))).length === 1);
    assert.equal(JSON.parse(await fs.readFile(path.join(game, '.aetheris/launcher-backups', (await fs.readdir(path.join(game, '.aetheris/launcher-backups')))[0]!), 'utf8')).profiles.mio.name, 'Mi perfil');
    const rm = await removeOfficialLauncherProfile(info, game);
    assert.deepEqual(rm, { removedProfile: true, removedVersion: true });
    const fin = JSON.parse(await fs.readFile(path.join(mcDir, 'launcher_profiles.json'), 'utf8')); assert.deepEqual(fin.profiles, mine.profiles);
    await assert.rejects(fs.stat(path.join(mcDir, 'versions', 'fabric-loader-0.19.5-26.3')));
  } finally { await s.close(); }
});

test('launcher: errores claros (sin launcher_profiles.json, JSON dañado, versión inexistente, id peligroso) y sin modificar nada', async () => {
  const s = await startServer(); const d = await tmpDir(); const mcDir = path.join(d, '.minecraft'); await fs.mkdir(mcDir, { recursive: true });
  const a = { minecraftDir: mcDir, gameDir: d, profileId: 'fps', profileName: 'x', minecraft: '26.3', loaderVersion: '0.19.5' };
  try {
    await assert.rejects(installOfficialLauncherProfile(a, { metaBase: s.base }), /al menos una vez/);
    await fs.writeFile(path.join(mcDir, 'launcher_profiles.json'), '{roto'); await assert.rejects(installOfficialLauncherProfile(a, { metaBase: s.base }), /dañado/);
    assert.equal(await fs.readFile(path.join(mcDir, 'launcher_profiles.json'), 'utf8'), '{roto');
    await fs.writeFile(path.join(mcDir, 'launcher_profiles.json'), '{"profiles":{}}');
    await assert.rejects(installOfficialLauncherProfile(a, { metaBase: s.base }), /no ofrece un perfil|404/);
    serve(s, '/v2/versions/loader/26.3/0.19.5/profile/json', JSON.stringify({ id: '../../evil', inheritsFrom: '26.3' }));
    await assert.rejects(fetchFabricProfile('26.3', '0.19.5', { metaBase: s.base }), /identificador/);
    await assert.rejects(fetchFabricProfile('26.3/../x', '0.19.5', { metaBase: s.base }), /no válidos/);
    assert.equal(await fs.readFile(path.join(mcDir, 'launcher_profiles.json'), 'utf8'), '{"profiles":{}}');
  } finally { await s.close(); }
});

test('perfiles: sin paquetes => "missing" (no se simula nada); con paquetes reales se leen sus datos; shaders prohibidos en FPS/PvP; listas iguales se avisan', async () => {
  const s = await startServer(); const d = await tmpDir();
  const paths = { profilesJson: path.resolve(__dirname, '../profiles/profiles.json'), packsDir: path.join(d, 'packs'), userPacksDir: path.join(d, 'user') };
  await fs.mkdir(paths.packsDir);
  try {
    let r = await listProfiles(paths, TEST_POLICY);
    assert.deepEqual(r.profiles.map((p) => p.status), ['missing', 'missing', 'missing']); assert.ok(r.profiles.every((p) => !p.pack));
    const same = [{ path: 'mods/sodium-1.jar', content: 'S' }];
    await fs.copyFile(await makeMrpack({ dir: d, server: s, name: 'a', files: same }), path.join(paths.packsDir, 'AETHERIS_NEXUS_FPS.mrpack'));
    await fs.copyFile(await makeMrpack({ dir: d, server: s, name: 'b', versionId: 'v9', files: same }), path.join(paths.packsDir, 'AETHERIS_NEXUS_PVP_ULTRA.mrpack'));
    await fs.copyFile(await makeMrpack({ dir: d, server: s, name: 'c', files: [...same, { path: 'mods/iris-1.jar', content: 'I' }] }), path.join(paths.packsDir, 'AETHERIS_NEXUS_EQUILIBRADO.mrpack'));
    r = await listProfiles(paths, TEST_POLICY);
    const by = Object.fromEntries(r.profiles.map((p) => [p.id, p]));
    assert.equal(by.fps!.status, 'ready'); assert.equal(by.fps!.pack!.modCount, 1); assert.equal(by.fps!.pack!.minecraft, '26.3'); assert.equal(by.equilibrado!.status, 'ready');
    assert.ok(r.warnings.some((w) => /misma lista de mods/.test(w) && /FPS/.test(w) && /PVP/.test(w)), 'avisa de perfiles idénticos');
    // un paquete FPS con Iris se rechaza
    await fs.copyFile(await makeMrpack({ dir: d, server: s, name: 'd', files: [{ path: 'mods/iris-fabric-1.jar', content: 'I' }] }), path.join(paths.packsDir, 'AETHERIS_NEXUS_FPS.mrpack'));
    assert.equal((await listProfiles(paths, TEST_POLICY)).profiles.find((p) => p.id === 'fps')!.status, 'invalid');
    // importar: valida y copia a la carpeta del usuario, que tiene prioridad
    const ok = await makeMrpack({ dir: d, server: s, name: 'e', versionId: 'v10', files: [{ path: 'mods/lithium-1.jar', content: 'L' }] });
    await importPack(paths, 'fps', ok, TEST_POLICY);
    const fps = (await listProfiles(paths, TEST_POLICY)).profiles.find((p) => p.id === 'fps')!; assert.equal(fps.status, 'ready'); assert.equal(fps.pack!.source, 'user'); assert.equal(fps.pack!.versionId, 'v10');
    await assert.rejects(importPack(paths, 'fps', await makeMrpack({ dir: d, server: s, name: 'f', files: [{ path: 'shaderpacks/x.zip', content: 'S' }] }), TEST_POLICY), /sin shaders/);
    await assert.rejects(importPack(paths, 'inexistente', ok, TEST_POLICY), /desconocido/);
    assert.equal((await loadConfig(paths.profilesJson)).profiles.length, 3);
  } finally { await s.close(); }
});
