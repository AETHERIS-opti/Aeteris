import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { openMrpack, validateIndex, STRICT_POLICY } from '../src/core/mrpack';
import { buildZip, makeMrpack, startServer, tmpDir, TEST_POLICY, sha1, sha512 } from './helpers';

const goodFile = (over: Record<string, unknown> = {}) => ({ path: 'mods/a.jar', hashes: { sha1: sha1('a'), sha512: sha512('a') }, env: { client: 'required', server: 'unsupported' }, downloads: ['https://cdn.modrinth.com/data/x/versions/y/a.jar'], fileSize: 1, ...over });
const idx = (over: Record<string, unknown> = {}, files: unknown[] = [goodFile()]) => ({ formatVersion: 1, game: 'minecraft', versionId: 'v', name: 'n', files, dependencies: { minecraft: '26.3', 'fabric-loader': '0.19.5' }, ...over });
const bad = (raw: unknown, re: RegExp) => assert.throws(() => validateIndex(raw), (e: Error) => re.test(e.message));

test('mrpack: índice válido; lee minecraft y fabric-loader', () => {
  const r = validateIndex(idx());
  assert.equal(r.minecraft, '26.3'); assert.equal(r.loaderVersion, '0.19.5'); assert.equal(r.index.files[0]!.env.client, 'required');
});

test('mrpack: rechaza índices inválidos (campos, loader, rutas, hashes, URLs, protegidas)', () => {
  bad(null, /objeto/); bad(idx({ formatVersion: 2 }), /formatVersion/); bad(idx({ game: 'otro' }), /game/);
  bad(idx({ dependencies: { minecraft: '26.3' } }), /exactamente un cargador/);
  assert.throws(() => validateIndex(idx({ dependencies: { minecraft: '26.3', forge: '1' } })), (e: Error & { code?: string }) => e.code === 'E_LOADER');
  bad(idx({ dependencies: { minecraft: '26.3', 'fabric-loader': '1', raro: '1' } }), /desconocida/);
  bad(idx({}, [goodFile({ path: '../x.jar' })]), /segmento/); bad(idx({}, [goodFile({ path: 'mods/a.exe' })]), /\.jar|extensión/);
  bad(idx({}, [goodFile({ path: 'otracarpeta/a.jar' })]), /solo se descargan/);
  assert.throws(() => validateIndex(idx({}, [goodFile({ path: 'saves/w/level.dat' })])), (e: Error & { code?: string }) => e.code === 'E_PROTECTED' || /solo se descargan/.test(e.message));
  bad(idx({}, [goodFile({ hashes: {} })]), /sin hash/); bad(idx({}, [goodFile({ hashes: { sha1: 'abc' } })]), /sha1 inválido/);
  bad(idx({}, [goodFile({ downloads: ['http://cdn.modrinth.com/a.jar'] })]), /https/);
  bad(idx({}, [goodFile({ downloads: ['https://evil.example/a.jar'] })]), /dominio no permitido/);
  bad(idx({}, [goodFile({ downloads: ['https://user:pw@cdn.modrinth.com/a.jar'] })]), /credenciales/);
  bad(idx({}, [goodFile({ downloads: [] })]), /sin URLs/); bad(idx({}, [goodFile(), goodFile()]), /duplicada/);
  bad(idx({}, [goodFile({ env: { client: 'quizas' } })]), /env/); bad(idx({}, [goodFile({ fileSize: -5 })]), /fileSize/);
});

test('mrpack: client-overrides tiene precedencia; rutas protegidas y ejecutables en overrides se rechazan', async () => {
  const d = await tmpDir(); const s = await startServer();
  try {
    const f = await makeMrpack({ dir: d, server: s, overrides: { 'config/a.txt': 'base', 'options.txt': 'o' }, clientOverrides: { 'config/a.txt': 'cliente' } });
    const m = await openMrpack(f, TEST_POLICY);
    assert.equal((await m.zip.read(m.overrides.get('config/a.txt')!)).toString(), 'cliente');
    for (const [rel, re] of [['saves/w/level.dat', /protegida/], ['servers.dat', /protegida/], ['tools/x.exe', /extensión/], ['mods/x.dll', /extensión/]] as const) {
      const g = await makeMrpack({ dir: d, server: s, name: 'x' + rel.length, overrides: { [rel]: 'x' } });
      await assert.rejects(openMrpack(g, TEST_POLICY), (e: Error) => re.test(e.message), rel);
    }
  } finally { await s.close(); }
});

test('mrpack: archivo sin modrinth.index.json, JSON roto y ZIP corrupto', async () => {
  const d = await tmpDir();
  const a = path.join(d, 'a.mrpack'); await fs.writeFile(a, buildZip([{ name: 'otra.txt', data: 'x' }]));
  await assert.rejects(openMrpack(a, STRICT_POLICY), /falta modrinth\.index\.json/);
  const b = path.join(d, 'b.mrpack'); await fs.writeFile(b, buildZip([{ name: 'modrinth.index.json', data: '{roto' }]));
  await assert.rejects(openMrpack(b, STRICT_POLICY), /JSON válido/);
  const c = path.join(d, 'c.mrpack'); await fs.writeFile(c, Buffer.from('no zip no zip no zip no zip no zip'));
  await assert.rejects(openMrpack(c, STRICT_POLICY), /ZIP/);
});
