import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { ZipReader } from '../src/core/zip';
import { assertSafeRelative, resolveInside, isProtected, assertAcceptableInstanceDir } from '../src/core/paths';
import { buildZip, tmpDir } from './helpers';

async function zipFile(entries: Parameters<typeof buildZip>[0]) { const d = await tmpDir(); const f = path.join(d, 'a.zip'); await fs.writeFile(f, buildZip(entries)); return { d, f }; }
const rejects = (p: Promise<unknown>, re: RegExp) => assert.rejects(p, (e: Error) => re.test(e.message));

test('ZIP: lee y extrae entradas almacenadas y deflate con CRC correcto', async () => {
  const { d, f } = await zipFile([{ name: 'a.txt', data: 'hola' }, { name: 'dir/b.txt', data: 'x'.repeat(5000), deflate: true }, { name: 'vacio.txt', data: '' }]);
  const z = await ZipReader.open(f);
  assert.equal((await z.read(z.find('a.txt')!)).toString(), 'hola');
  await z.extract(z.find('dir/b.txt')!, path.join(d, 'out', 'b.txt'));
  assert.equal((await fs.readFile(path.join(d, 'out', 'b.txt'), 'utf8')).length, 5000);
  await z.extract(z.find('vacio.txt')!, path.join(d, 'out', 'v.txt'));
  assert.equal((await fs.stat(path.join(d, 'out', 'v.txt'))).size, 0);
});

test('ZIP: rutas maliciosas (zip-slip, absolutas, unidad, UNC, ADS, reservados) se rechazan al abrir', async () => {
  for (const name of ['../evil.txt', 'a/../../evil.txt', '/etc/passwd', 'C:/Windows/x.txt', '\\\\srv\\share\\x', 'a\\b.txt', 'file.txt:stream', 'CON.txt', 'dir/aux', 'a/./b', 'x.txt.']) {
    const { f } = await zipFile([{ name, data: 'x' }]);
    await rejects(ZipReader.open(f), /entrada ZIP|ruta|segmento|absoluta|barra|nombre reservado|punto/i);
  }
});

test('ZIP: enlaces simbólicos, duplicados y archivos que no son ZIP se rechazan', async () => {
  await rejects(ZipReader.open((await zipFile([{ name: 'link', data: 'target', mode: 0o120777 }])).f), /simbólico/);
  await rejects(ZipReader.open((await zipFile([{ name: 'a.txt', data: '1' }, { name: 'A.TXT', data: '2' }])).f), /duplicada/);
  const d = await tmpDir(); const f = path.join(d, 'x.zip'); await fs.writeFile(f, 'esto no es un zip, solo texto largo '.repeat(5));
  await rejects(ZipReader.open(f), /no es un ZIP/);
});

test('ZIP: CRC o tamaño falsos se detectan al extraer y no dejan archivo parcial', async () => {
  const { d, f } = await zipFile([{ name: 'a.txt', data: 'contenido', rawCrc: 123 }, { name: 'b.txt', data: 'contenido', rawSize: 3 }]);
  const z = await ZipReader.open(f);
  await rejects(z.extract(z.find('a.txt')!, path.join(d, 'o', 'a.txt')), /CRC/);
  await rejects(z.extract(z.find('b.txt')!, path.join(d, 'o', 'b.txt')), /excede|Tamaño/);
  await assert.rejects(fs.stat(path.join(d, 'o', 'a.txt')));
  await assert.rejects(fs.stat(path.join(d, 'o', 'b.txt')));
});

test('ZIP: límites anti zip-bomb (ratio y tamaño total)', async () => {
  const big = 'a'.repeat(3 * 1024 * 1024);
  const { f } = await zipFile([{ name: 'bomba.bin', data: big, deflate: true }]);
  await rejects(ZipReader.open(f, { maxEntries: 10, maxEntryBytes: 1 << 30, maxTotalBytes: 1 << 30, maxRatio: 50 }), /Ratio/);
  await rejects(ZipReader.open(f, { maxEntries: 10, maxEntryBytes: 1 << 30, maxTotalBytes: 1000, maxRatio: 1e9 }), /límite/);
  await rejects(ZipReader.open(f, { maxEntries: 0, maxEntryBytes: 1 << 30, maxTotalBytes: 1 << 30, maxRatio: 1e9 }), /Demasiadas/);
});

test('rutas: resolveInside, protegidas y destinos no aceptables', () => {
  const root = path.resolve('/tmp/inst');
  assert.equal(resolveInside(root, 'mods/a.jar'), path.join(root, 'mods', 'a.jar'));
  assert.throws(() => resolveInside(root, '../x'), /segmento|sale/);
  for (const p of ['saves/mundo/level.dat', 'Screenshots/a.png', 'servers.dat', 'logs/latest.log', '.aetheris/x', 'crash-reports/c.txt']) assert.ok(isProtected(p), p);
  for (const p of ['mods/a.jar', 'config/x.toml', 'options.txt', 'resourcepacks/x.zip']) assert.ok(!isProtected(p), p);
  assert.throws(() => assertAcceptableInstanceDir('relativa/x'), /absoluta/);
  assert.throws(() => assertAcceptableInstanceDir('C:\\Windows\\Foo'), /sistema/);
  assert.throws(() => assertAcceptableInstanceDir('C:\\'), /raíz/);
  assert.equal(assertSafeRelative('mods/a.jar'), 'mods/a.jar');
});
