/** Utilidades de prueba. TODO lo que se genera aquí es SINTÉTICO (ZIP/mrpack creados al vuelo, servidor HTTP local en 127.0.0.1). */
import http from 'node:http';
import zlib from 'node:zlib';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHash } from 'node:crypto';
import type { NetworkPolicy } from '../src/core/mrpack';

export interface ZEntry { name: string; data?: Buffer | string; deflate?: boolean; mode?: number; rawCrc?: number; rawSize?: number }

export function buildZip(entries: ZEntry[]): Buffer {
  const locals: Buffer[] = [], central: Buffer[] = [];
  let offset = 0;
  for (const e of entries) {
    const data = Buffer.from(e.data ?? '');
    const name = Buffer.from(e.name, 'utf8');
    const method = e.deflate ? 8 : 0;
    const comp = e.deflate ? zlib.deflateRawSync(data) : data;
    const crc = e.rawCrc ?? zlib.crc32(data);
    const size = e.rawSize ?? data.length;
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x800, 6); lh.writeUInt16LE(method, 8);
    lh.writeUInt32LE(crc >>> 0, 14); lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(size, 22); lh.writeUInt16LE(name.length, 26);
    const local = Buffer.concat([lh, name, comp]);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(0x031e, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x800, 8); ch.writeUInt16LE(method, 10);
    ch.writeUInt32LE(crc >>> 0, 16); ch.writeUInt32LE(comp.length, 20); ch.writeUInt32LE(size, 24); ch.writeUInt16LE(name.length, 28);
    ch.writeUInt32LE(((e.mode ?? 0o100644) << 16) >>> 0, 38); ch.writeUInt32LE(offset, 42);
    central.push(Buffer.concat([ch, name]));
    locals.push(local); offset += local.length;
  }
  const cd = Buffer.concat(central);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(entries.length, 8); eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(cd.length, 12); eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, eocd]);
}

export const sha1 = (b: Buffer | string) => createHash('sha1').update(b).digest('hex');
export const sha512 = (b: Buffer | string) => createHash('sha512').update(b).digest('hex');
export const sha256 = (b: Buffer | string) => createHash('sha256').update(b).digest('hex');

export async function tmpDir(prefix = 'aeth-'): Promise<string> { return fs.mkdtemp(path.join(os.tmpdir(), prefix)); }

export interface TestServer { base: string; hits: Map<string, number>; routes: Map<string, (req: http.IncomingMessage, res: http.ServerResponse, hit: number) => void>; close(): Promise<void> }
export async function startServer(): Promise<TestServer> {
  const hits = new Map<string, number>();
  const routes: TestServer['routes'] = new Map();
  const srv = http.createServer((req, res) => {
    const p = (req.url ?? '/').split('?')[0]!;
    const n = (hits.get(p) ?? 0) + 1; hits.set(p, n);
    const h = routes.get(p);
    if (!h) { res.statusCode = 404; res.end('no'); return; }
    h(req, res, n);
  });
  await new Promise<void>((r) => srv.listen(0, '127.0.0.1', r));
  const port = (srv.address() as { port: number }).port;
  return { base: `http://127.0.0.1:${port}`, hits, routes, close: () => new Promise((r) => { srv.closeAllConnections?.(); srv.close(() => r()); }) };
}
export const serve = (s: TestServer, p: string, body: Buffer | string) => s.routes.set(p, (_q, res) => { res.end(body); });
export const TEST_POLICY: NetworkPolicy = { allowedHosts: ['127.0.0.1'], allowHttp: true };

export interface FakeFile { path: string; content: string; env?: { client?: string; server?: string } }
/** Construye un .mrpack sintético cuyos archivos se sirven desde `server`. */
export async function makeMrpack(opts: {
  dir: string; server: TestServer; name?: string; versionId?: string; files?: FakeFile[]; overrides?: Record<string, string>; clientOverrides?: Record<string, string>;
  minecraft?: string; loader?: string; extraIndex?: Record<string, unknown>; mutateFile?: (f: Record<string, unknown>, i: number) => void;
}): Promise<string> {
  const files = (opts.files ?? []).map((f, i) => {
    const url = `${opts.server.base}/files/${opts.versionId ?? 'v1'}/${f.path}`;
    serve(opts.server, new URL(url).pathname, f.content);
    const o: Record<string, unknown> = { path: f.path, hashes: { sha1: sha1(f.content), sha512: sha512(f.content) }, env: f.env ?? { client: 'required', server: 'unsupported' }, downloads: [url], fileSize: Buffer.byteLength(f.content) };
    opts.mutateFile?.(o, i);
    return o;
  });
  const index = { formatVersion: 1, game: 'minecraft', versionId: opts.versionId ?? 'v1', name: opts.name ?? 'Paquete de prueba', files, dependencies: { minecraft: opts.minecraft ?? '26.3', [opts.loader ?? 'fabric-loader']: '0.19.5' }, ...(opts.extraIndex ?? {}) };
  const entries: ZEntry[] = [{ name: 'modrinth.index.json', data: JSON.stringify(index), deflate: true }];
  for (const [k, v] of Object.entries(opts.overrides ?? {})) entries.push({ name: `overrides/${k}`, data: v, deflate: true });
  for (const [k, v] of Object.entries(opts.clientOverrides ?? {})) entries.push({ name: `client-overrides/${k}`, data: v, deflate: true });
  const out = path.join(opts.dir, `${opts.name ?? 'pack'}-${opts.versionId ?? 'v1'}.mrpack`.replace(/\s+/g, '_'));
  await fs.writeFile(out, buildZip(entries));
  return out;
}
