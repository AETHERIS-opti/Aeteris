import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { downloadVerified, matchesExpected } from '../src/core/download';
import { startServer, tmpDir, serve, TEST_POLICY, sha1, sha512 } from './helpers';

const exp = (c: string) => ({ sha1: sha1(c), sha512: sha512(c), size: Buffer.byteLength(c) });
const base = { policy: TEST_POLICY, backoffMs: 5, retries: 3 };

test('descarga: éxito, hash verificado, sin archivo .part', async () => {
  const s = await startServer(); const d = await tmpDir();
  try {
    serve(s, '/a.jar', 'contenido-a');
    const dest = path.join(d, 'a.jar'); let bytes = 0;
    await downloadVerified([s.base + '/a.jar'], dest, { ...base, expected: exp('contenido-a'), onBytes: (n) => { bytes += n; } });
    assert.equal(await fs.readFile(dest, 'utf8'), 'contenido-a'); assert.equal(bytes, 11);
    assert.deepEqual((await fs.readdir(d)).sort(), ['a.jar']);
    assert.ok(await matchesExpected(dest, exp('contenido-a'))); assert.ok(!(await matchesExpected(dest, exp('otro'))));
  } finally { await s.close(); }
});

test('descarga: hash incorrecto => error E_HASH y no queda archivo', async () => {
  const s = await startServer(); const d = await tmpDir();
  try {
    serve(s, '/a.jar', 'manipulado');
    await assert.rejects(downloadVerified([s.base + '/a.jar'], path.join(d, 'a.jar'), { ...base, expected: exp('original') }), (e: Error & { code?: string }) => e.code === 'E_HASH');
    assert.deepEqual(await fs.readdir(d), []);
  } finally { await s.close(); }
});

test('descarga: reintenta tras errores 500 y termina bien; 404 no se reintenta', async () => {
  const s = await startServer(); const d = await tmpDir();
  try {
    s.routes.set('/flaky', (_q, res, hit) => { if (hit < 3) { res.statusCode = 503; res.end('x'); } else res.end('bien'); });
    let retries = 0;
    await downloadVerified([s.base + '/flaky'], path.join(d, 'f.jar'), { ...base, expected: exp('bien'), onRetry: () => { retries++; } });
    assert.equal(retries, 2); assert.equal(s.hits.get('/flaky'), 3);
    await assert.rejects(downloadVerified([s.base + '/no-existe'], path.join(d, 'n.jar'), { ...base, expected: exp('x') }), /404/);
    assert.equal(s.hits.get('/no-existe'), 1);
  } finally { await s.close(); }
});

test('descarga: usa la siguiente URL si la primera falla con 404', async () => {
  const s = await startServer(); const d = await tmpDir();
  try {
    serve(s, '/espejo', 'datos');
    await downloadVerified([s.base + '/primera', s.base + '/espejo'], path.join(d, 'x.jar'), { ...base, expected: exp('datos') });
    assert.equal(await fs.readFile(path.join(d, 'x.jar'), 'utf8'), 'datos');
  } finally { await s.close(); }
});

test('descarga: conexión rechazada => error comprensible tras agotar reintentos; sin archivos', async () => {
  const s = await startServer(); const base0 = s.base; await s.close(); const d = await tmpDir();
  await assert.rejects(downloadVerified([base0 + '/a.jar'], path.join(d, 'a.jar'), { ...base, retries: 1, expected: exp('x') }), /No se pudo descargar|conexión fallida/);
  assert.deepEqual(await fs.readdir(d), []);
});

test('descarga: cancelación con AbortSignal y dominio no permitido', async () => {
  const s = await startServer(); const d = await tmpDir();
  try {
    s.routes.set('/lento', (_q, res) => { res.write('parte'); /* nunca termina */ });
    const ctl = new AbortController(); setTimeout(() => ctl.abort(), 80);
    await assert.rejects(downloadVerified([s.base + '/lento'], path.join(d, 'l.jar'), { ...base, expected: exp('x'), signal: ctl.signal }), (e: Error & { code?: string }) => e.code === 'E_CANCELLED');
    assert.deepEqual(await fs.readdir(d), []);
    await assert.rejects(downloadVerified(['https://evil.example/a.jar'], path.join(d, 'e.jar'), { expected: exp('x') }), /dominio no permitido/);
  } finally { await s.close(); }
});
