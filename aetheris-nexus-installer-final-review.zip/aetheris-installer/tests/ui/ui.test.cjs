/* Pruebas de INTERFAZ en Chromium headless (Playwright) con una API SIMULADA. Verifican que la UI renderiza, que cada botón llama a la acción
   correcta con los argumentos correctos y que los estados de error/éxito se muestran. No prueban el motor ni Electron: eso son otras pruebas. */
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const fs = require('node:fs');
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const root = path.resolve(__dirname, '../..'); const shots = path.join(root, 'docs', 'screenshots'); fs.mkdirSync(shots, { recursive: true });
const mock = fs.readFileSync(path.join(__dirname, 'mock-api.js'), 'utf8'); let browser;
before(async () => { browser = await chromium.launch(); }); after(async () => { await browser.close(); });
async function open(scenario = {}, size = { width: 1180, height: 780 }) {
  const page = await browser.newPage({ viewport: size }); const errors = []; page.on('pageerror', (e) => errors.push(String(e))); page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.addInitScript(`window.__scenario = ${JSON.stringify(scenario)};`); await page.addInitScript(mock);
  await page.goto(pathToFileURL(path.join(root, 'dist', 'renderer', 'index.html')).href); await page.waitForSelector('.card'); page.__errors = errors; return page;
}
const calls = (page) => page.evaluate(() => window.__calls);

test('perfiles: tres tarjetas, estados reales, Instalar deshabilitado sin paquete, aviso de perfiles iguales', async () => {
  const page = await open({ dupWarn: true }); await page.waitForTimeout(600);
  assert.equal(await page.locator('.card').count(), 3);
  assert.deepEqual(await page.locator('.card .badge').allInnerTexts(), ['Configurado', 'Configurado', 'Falta el paquete']);
  const btn = page.locator('.card', { hasText: 'AETHERIS PVP ULTRA' }).getByRole('button', { name: 'Instalar', exact: true });
  assert.ok(await btn.isDisabled()); assert.ok(await page.locator('.card', { hasText: 'AETHERIS FPS' }).getByRole('button', { name: 'Instalar', exact: true }).isEnabled());
  assert.match(await page.locator('.note-warn').first().innerText(), /misma lista de mods/);
  assert.match(await page.locator('.card', { hasText: 'AETHERIS EQUILIBRADO' }).innerText(), /Shaders opcionales \(desactivados\)/); assert.match(await page.locator('.card', { hasText: 'AETHERIS FPS' }).innerText(), /Sin shaders/);
  await page.screenshot({ path: path.join(shots, '01-perfiles.png') });
  await page.locator('.card', { hasText: 'AETHERIS PVP ULTRA' }).getByRole('button', { name: 'Incorporar .mrpack' }).click(); await page.waitForTimeout(100);
  assert.deepEqual((await calls(page)).filter((c) => c[0] === 'importPack'), [['importPack', 'pvp-ultra']]); assert.deepEqual(page.__errors, []); await page.close();
});

test('instalar: el diálogo envía los argumentos elegidos, muestra progreso y resumen final', async () => {
  const page = await open({ slow: true }); await page.locator('.card', { hasText: 'AETHERIS FPS' }).getByRole('button', { name: 'Instalar', exact: true }).click();
  await page.waitForSelector('.modal'); assert.match(await page.locator('.modal').innerText(), /Java 25\.0\.1 detectado/);
  await page.screenshot({ path: path.join(shots, '02-instalar-dialogo.png') });
  await page.getByLabel(/Reemplazarla/).check(); await page.getByRole('button', { name: 'Instalar', exact: true }).last().click();
  await page.waitForSelector('.op'); await page.waitForTimeout(900); await page.screenshot({ path: path.join(shots, '03-progreso.png') });
  assert.ok(await page.locator('.op').getByRole('button', { name: 'Cancelar' }).isVisible());
  await page.waitForSelector('.op .badge-ok', { timeout: 8000 }); await page.screenshot({ path: path.join(shots, '04-resumen.png') });
  const inst = (await calls(page)).find((c) => c[0] === 'install')[1];
  assert.deepEqual(inst, { profileId: 'fps', target: { kind: 'official' }, userConfigPolicy: 'replace', createLauncherProfile: true });
  const txt = await page.locator('.op').innerText(); assert.match(txt, /Perfil creado en el launcher oficial/); assert.match(txt, /Se respetó tu configuración personal/); assert.match(txt, /txn-20261107100000-ab12/);
  await page.getByRole('button', { name: 'Cerrar' }).click(); assert.equal(await page.locator('.op').count(), 0); assert.deepEqual(page.__errors, []); await page.close();
});

test('instalar: sin launcher oficial solo se ofrece carpeta de instancia (y hay que elegirla); Cancelar durante la operación llama a cancel', async () => {
  const page = await open({ noOfficial: true, slow: true }); await page.locator('.card', { hasText: 'AETHERIS FPS' }).getByRole('button', { name: 'Instalar', exact: true }).click(); await page.waitForSelector('.modal');
  assert.ok(await page.getByLabel(/Launcher oficial de Minecraft/).isDisabled()); const go = page.getByRole('button', { name: 'Instalar', exact: true }).last(); assert.ok(await go.isDisabled());
  await page.getByRole('button', { name: 'Elegir carpeta…' }).click(); await page.waitForFunction(() => document.querySelector('.path')?.textContent?.includes('MisInstancias')); assert.ok(await go.isEnabled());
  await go.click(); await page.waitForSelector('.op'); await page.getByRole('button', { name: 'Cancelar' }).click();
  const c = await calls(page); assert.deepEqual(c.find((x) => x[0] === 'install')[1].target, { kind: 'folder', folder: 'D:\\MisInstancias\\aetheris' }); assert.ok(c.some((x) => x[0] === 'cancel')); await page.close();
});

test('error de descarga: mensaje claro con pista, y «Reintentar» vuelve a llamar a install', async () => {
  const page = await open({ failFirst: true }); await page.locator('.card', { hasText: 'AETHERIS FPS' }).getByRole('button', { name: 'Instalar', exact: true }).click();
  await page.getByRole('button', { name: 'Instalar', exact: true }).last().click(); await page.waitForSelector('.op .badge-err'); await page.screenshot({ path: path.join(shots, '05-error.png') });
  const t = await page.locator('.op').innerText(); assert.match(t, /No se pudieron descargar 1 de 8/); assert.match(t, /no se vuelve a bajar|no se ha modificado/i);
  await page.getByRole('button', { name: 'Reintentar' }).click(); await page.waitForSelector('.op .badge-ok', { timeout: 6000 });
  assert.equal((await calls(page)).filter((c) => c[0] === 'install').length, 2); await page.close();
});

test('mantenimiento: comprobar, reparar, copia, restaurar y desinstalar solo tras confirmar', async () => {
  const page = await open(); await page.getByRole('button', { name: /Mantenimiento/ }).click(); await page.waitForSelector('text=Información de la instalación');
  await page.getByRole('button', { name: 'Comprobar integridad' }).click(); await page.waitForSelector('text=1 faltan'); await page.screenshot({ path: path.join(shots, '06-mantenimiento.png'), fullPage: false });
  await page.getByRole('button', { name: 'Reparar', exact: true }).click(); await page.waitForSelector('.op .badge-ok'); assert.match(await page.locator('.op').innerText(), /instalados \/ actualizados/i); await page.getByRole('button', { name: 'Cerrar' }).click();
  await page.getByRole('button', { name: 'Crear copia ahora' }).click(); await page.waitForSelector('.op .badge-ok'); await page.getByRole('button', { name: 'Cerrar' }).click();
  await page.getByRole('button', { name: 'Restaurar' }).click(); await page.waitForSelector('.modal'); assert.equal((await calls(page)).filter((c) => c[0] === 'restoreBackup').length, 0, 'no se restaura sin confirmar');
  await page.getByRole('button', { name: 'Cancelar' }).click();
  await page.getByRole('button', { name: 'Desinstalar este perfil…' }).click(); await page.waitForSelector('.modal'); assert.equal((await calls(page)).filter((c) => c[0] === 'uninstall').length, 0, 'no se desinstala sin confirmar');
  await page.getByLabel(/Borrar también las copias/).check(); await page.getByRole('button', { name: 'Desinstalar', exact: true }).click(); await page.waitForSelector('.op .badge-ok');
  const c = await calls(page); assert.deepEqual(c.find((x) => x[0] === 'uninstall').slice(1), ['C:\\Users\\u\\AppData\\Roaming\\.minecraft\\aetheris-instances\\fps', true]);
  assert.deepEqual(c.find((x) => x[0] === 'repair').slice(2), ['keep']); assert.deepEqual(page.__errors, []); await page.close();
});

test('mantenimiento: operación interrumpida muestra «Revertir cambios» y requiere confirmación', async () => {
  const page = await open({ pending: true }); await page.getByRole('button', { name: /Mantenimiento/ }).click(); await page.waitForSelector('text=se interrumpió');
  await page.getByRole('button', { name: 'Revertir cambios' }).click(); await page.waitForSelector('.modal'); await page.getByRole('button', { name: 'Revertir', exact: true }).click(); await page.waitForSelector('.op .badge-ok');
  assert.equal((await calls(page)).filter((c) => c[0] === 'rollbackPending').length, 1); await page.close();
});

test('sistema, registros y acerca de: muestran datos y declaran "No verificado" y "Sin firmar"', async () => {
  const page = await open(); await page.getByRole('button', { name: /Sistema/ }).click(); await page.waitForSelector('text=Diagnóstico del sistema');
  const t = await page.locator('.view').innerText(); assert.match(t, /Windows 11/); assert.match(t, /Prism Launcher/); assert.ok((await page.locator('.badge-warn', { hasText: 'No verificado' }).count()) >= 3);
  await page.screenshot({ path: path.join(shots, '07-sistema.png') });
  await page.getByRole('button', { name: /Registros/ }).click(); await page.waitForSelector('.ll'); assert.match(await page.locator('.log').innerText(), /503/);
  await page.getByRole('button', { name: /Acerca de/ }).click(); await page.waitForSelector('text=Limitaciones conocidas'); assert.match(await page.locator('.view').innerText(), /no está firmado digitalmente/); assert.ok(await page.locator('.badge-warn', { hasText: 'Sin firmar' }).count() >= 1); await page.close();
});

test('adaptable: a 800 px no hay desbordamiento horizontal y la navegación sigue accesible', async () => {
  const page = await open({}, { width: 800, height: 900 }); await page.waitForTimeout(500);
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)); assert.ok(await page.getByRole('button', { name: /Perfiles/ }).isVisible());
  await page.screenshot({ path: path.join(shots, '08-estrecho.png') }); await page.close();
});
