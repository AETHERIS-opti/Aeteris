/* API SIMULADA solo para pruebas de interfaz (se inyecta en el navegador headless). No es el motor real: el motor se prueba en tests/*.test.ts. */
(function () {
  const calls = []; window.__calls = calls; const listeners = []; const scen = window.__scenario || {};
  const emit = (m) => listeners.forEach((l) => l(m));
  const ok = (value) => Promise.resolve({ ok: true, value });
  const err = (code, message) => Promise.resolve({ ok: false, error: { code, message } });
  const rec = (n, ...a) => { calls.push([n, ...a]); };
  const system = { os: { platform: 'win32', name: 'Windows 11', release: '10.0.22631', build: 22631, arch: 'x64', supported: true }, ram: { totalMB: 16384, freeMB: 9120 }, cpuCores: 12,
    java: [{ path: 'C:\\Users\\u\\AppData\\Roaming\\.minecraft\\runtime\\java-runtime-epsilon\\windows-x64\\bin\\java.exe', version: '25.0.1', major: 25, source: 'Java del launcher oficial' }, { path: 'C:\\Program Files\\Eclipse Adoptium\\jdk-21\\bin\\java.exe', version: '21.0.4', major: 21, source: 'Eclipse Adoptium' }],
    minecraftDir: { path: 'C:\\Users\\u\\AppData\\Roaming\\.minecraft', exists: scen.noOfficial ? false : true },
    launchers: [
      { kind: 'official', label: 'Launcher oficial de Minecraft (.minecraft)', path: 'C:\\Users\\u\\AppData\\Roaming\\.minecraft', exists: !scen.noOfficial, instances: [], verified: false, note: '' },
      { kind: 'prism', label: 'Prism Launcher', path: 'C:\\Users\\u\\AppData\\Roaming\\PrismLauncher', exists: true, instances: [{ name: 'MiPack', path: 'C:\\P\\MiPack', gameDir: 'C:\\P\\MiPack\\minecraft' }], verified: false, note: '' },
      { kind: 'modrinth', label: 'Modrinth App', path: 'C:\\Users\\u\\AppData\\Roaming\\ModrinthApp', exists: false, instances: [], verified: false, note: '' }], warnings: [] };
  const pack = (n, id, mods) => ({ name: n, versionId: id, minecraft: '26.3', loaderVersion: '0.19.5', modCount: mods, sizeBytes: 3400000 + mods * 1000, modListFingerprint: 'abc123def456', source: 'user' });
  const base = (id, name, tagline, shaders, hl) => ({ id, name, tagline, description: 'Objetivo del perfil (descripción de diseño).', highlights: hl, shaders, expectedFile: `AETHERIS_NEXUS_${id.toUpperCase().replace('-', '_')}.mrpack` });
  const profiles = [
    { ...base('equilibrado', 'AETHERIS EQUILIBRADO', 'Rendimiento y apariencia en equilibrio', 'optional', ['Texturas Vanilla+', 'Iris opcional']), status: 'ready', statusMessage: 'Configurado', pack: pack('AETHERIS NEXUS EQUILIBRADO', '2.1.0', 10) },
    { ...base('fps', 'AETHERIS FPS', 'Máximo rendimiento', 'none', ['Prioriza FPS', 'Sin shaders']), status: 'ready', statusMessage: 'Configurado', pack: pack('AETHERIS NEXUS FPS', '2.1.0', 8) },
    { ...base('pvp-ultra', 'AETHERIS PVP ULTRA', 'Visibilidad y fluidez para PvP', 'none', ['Buena visibilidad']), status: 'missing', statusMessage: 'Falta el archivo AETHERIS_NEXUS_PVP_ULTRA.mrpack. Incorpóralo con «Incorporar .mrpack» o cópialo a la carpeta de paquetes.' }];
  const info = { folder: 'C:\\Users\\u\\AppData\\Roaming\\.minecraft\\aetheris-instances\\fps', profileId: 'fps', packName: 'AETHERIS NEXUS FPS', packVersionId: '2.1.0', minecraft: '26.3', loaderVersion: '0.19.5', installedAt: '2026-11-07T10:00:00Z', updatedAt: '2026-11-07T10:00:00Z', fileCount: 19, pendingTransaction: !!scen.pending, launcherProfile: true };
  const installs = [{ folder: info.folder, exists: true, info }];
  let n = 0;
  window.aetheris = {
    appInfo: () => ok({ version: '1.0.0', packaged: false, platform: 'win32', arch: 'x64', electron: '45.x (simulado)', signed: false, userData: 'C:\\Users\\u\\AppData\\Roaming\\aetheris-installer', logFile: 'C:\\Users\\u\\AppData\\Roaming\\aetheris-installer\\logs\\installer.log' }).then((r) => r.value),
    getSystem: () => ok(system), javaCheck: (mc) => { rec('javaCheck', mc); return ok({ ok: true, required: { major: 25, confirmed: true, note: '' }, best: system.java[0], message: 'Java 25.0.1 detectado (se necesita 25 o superior)' }); },
    listProfiles: () => ok({ profiles, warnings: scen.dupWarn ? ['Estos perfiles tienen exactamente la misma lista de mods: AETHERIS FPS y AETHERIS PVP ULTRA.'] : [], packsDir: 'C:\\app\\packs', userPacksDir: 'C:\\ud\\packs' }),
    importPack: (id) => { rec('importPack', id); return ok({ imported: true }); }, chooseFolder: (t) => { rec('chooseFolder', t); return Promise.resolve('D:\\MisInstancias\\aetheris'); }, defaultOfficialFolder: () => ok('x'),
    install: (a) => { rec('install', a); n++; return new Promise((res) => {
      const steps = [['validate', 'Validando el paquete .mrpack…'], ['download', 'Descargando 8 archivos…', 0, 8, 0, 3400000], ['download', 'Descargado mods/sodium.jar', 4, 8, 1700000, 3400000], ['extract', 'Extrayendo 12 archivos del paquete…', 6, 12], ['commit', 'Instalado config/x.toml', 9, 19]];
      let i = 0; const t = setInterval(() => { const s = steps[i++]; if (!s) { clearInterval(t);
        if (scen.failFirst && n === 1) return res({ ok: false, error: { code: 'E_DOWNLOAD', message: 'No se pudieron descargar 1 de 8 archivos. No se ha modificado nada en tu instalación.' } });
        emit({ op: 'install', phase: 'done', message: 'Listo' });
        return res({ ok: true, value: { op: 'install', installed: 19, unchanged: 0, removed: [], skippedUserConfigs: ['options.txt'], keptModified: [], duplicates: [], backupId: 'txn-20261107100000-ab12', folder: info.folder, launcherProfile: 'created' } }); }
        emit({ op: 'install', phase: s[0], message: s[1], current: s[2], total: s[3], bytes: s[4], totalBytes: s[5] }); }, scen.slow ? 400 : 40); }); },
    cancel: () => { rec('cancel'); return Promise.resolve(); },
    listKnownInstalls: () => ok(installs), inspect: () => ok(info),
    verify: (f) => { rec('verify', f); return ok({ installed: true, profileId: 'fps', packVersionId: '2.1.0', total: 19, ok: 18, missing: ['mods/lithium.jar'], modified: [], pendingTransaction: false, duplicates: [] }); },
    repair: (f, p) => { rec('repair', f, p); return ok({ op: 'repair', installed: 1, unchanged: 18, removed: [], skippedUserConfigs: [], keptModified: [], duplicates: [], folder: f, repaired: ['mods/lithium.jar'] }); },
    uninstall: (f, rb) => { rec('uninstall', f, rb); return ok({ removed: 19, keptModified: [] }); }, rollbackPending: (f) => { rec('rollbackPending', f); return ok({ reverted: 3 }); },
    createBackup: (f) => { rec('createBackup', f); return ok({ id: 'manual-1', createdAt: '2026-11-07T11:00:00Z', reason: 'Copia manual', kind: 'manual', fileCount: 21 }); },
    listBackups: () => ok([{ id: 'manual-20261107110000-ab12', createdAt: '2026-11-07T11:00:00Z', reason: 'Copia manual desde el instalador', kind: 'manual', fileCount: 21 }, { id: 'txn-20261107100000-ab12', createdAt: '2026-11-07T10:00:00Z', reason: 'Copia automática antes de install', kind: 'auto', fileCount: 2 }]),
    restoreBackup: (f, id) => { rec('restoreBackup', f, id); return ok({ restored: 21, removed: 0 }); },
    readLogs: () => Promise.resolve([{ t: '2026-11-07T10:00:01.000Z', level: 'info', msg: 'Instalador 1.0.0 iniciado' }, { t: '2026-11-07T10:00:05.000Z', level: 'warn', msg: 'Reintento 1 de mods/sodium.jar: el servidor respondió 503' }, { t: '2026-11-07T10:00:09.000Z', level: 'info', msg: '[install] Listo' }]),
    openFolder: (f) => { rec('openFolder', f); return ok(true); }, onProgress: (cb) => { listeners.push(cb); return () => { const i = listeners.indexOf(cb); if (i >= 0) listeners.splice(i, 1); }; },
  };
})();
