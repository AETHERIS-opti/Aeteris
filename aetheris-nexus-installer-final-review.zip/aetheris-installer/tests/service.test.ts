/** Integración de la capa de servicio (lo que llama la interfaz) sobre carpetas temporales. Servidor HTTP y paquetes SINTÉTICOS; sin Electron ni Windows real. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createService } from '../src/electron/service';
import { Logger } from '../src/core/logger';
import { realContext } from '../src/core/detect';
import type { ProgressMsg } from '../src/shared/api';
import { makeMrpack, startServer, tmpDir, TEST_POLICY, serve } from './helpers';

async function world() {
  const s = await startServer(); const d = await tmpDir(); const appdata = path.join(d, 'AppData'); const mc = path.join(appdata, '.minecraft');
  await fs.mkdir(mc, { recursive: true }); await fs.writeFile(path.join(mc, 'launcher_profiles.json'), JSON.stringify({ profiles: { mio: { name: 'Mío' } }, version: 3 }));
  await fs.mkdir(path.join(mc, 'saves', 'MiMundo'), { recursive: true }); await fs.writeFile(path.join(mc, 'saves', 'MiMundo', 'level.dat'), 'MUNDO');
  serve(s, '/v2/versions/loader/26.3/0.19.5/profile/json', JSON.stringify({ id: 'fabric-loader-0.19.5-26.3', inheritsFrom: '26.3' }));
  const packs = path.join(d, 'packs'); await fs.mkdir(packs);
  const mk = (name: string, file: string, files: Array<{ path: string; content: string }>) => makeMrpack({ dir: d, server: s, name, versionId: name, files, overrides: { 'config/x.toml': name } }).then((f) => fs.copyFile(f, path.join(packs, file)));
  await mk('eq', 'AETHERIS_NEXUS_EQUILIBRADO.mrpack', [{ path: 'mods/sodium-1.jar', content: 'S' }, { path: 'mods/iris-1.jar', content: 'I' }]);
  await mk('fps', 'AETHERIS_NEXUS_FPS.mrpack', [{ path: 'mods/sodium-1.jar', content: 'S' }, { path: 'mods/lithium-1.jar', content: 'L' }]);
  const events: ProgressMsg[] = []; const log = new Logger();
  const svc = createService({ paths: { profilesJson: path.resolve(__dirname, '../profiles/profiles.json'), packsDir: packs, userPacksDir: path.join(d, 'user') }, userData: path.join(d, 'ud'), log, emit: (m) => events.push(m), home: d,
    detectCtx: { ...realContext(), platform: 'win32', arch: 'x64', release: '10.0.22631', env: { APPDATA: appdata }, homedir: d, javaVersionOutput: async () => { throw new Error('sin java'); } },
    engine: { policy: TEST_POLICY, backoffMs: 2, retries: 1 }, launcher: { metaBase: s.base } });
  return { s, d, mc, svc, events, log };
}
const val = <T>(r: { ok: boolean; value?: T; error?: { message: string; code: string } }): T => { assert.ok(r.ok, r.error?.message ?? 'resultado inesperado'); return r.value as T; };

test('servicio: flujo completo en el launcher oficial (instalar, perfil de launcher, inspeccionar, verificar, copia, reparar, cambiar de perfil, desinstalar) sin tocar mundos ni perfiles del usuario', async () => {
  const { s, mc, svc, events } = await world();
  try {
    const prof = val(await svc.listProfiles());
    assert.deepEqual(prof.profiles.map((p) => [p.id, p.status]), [['equilibrado', 'ready'], ['fps', 'ready'], ['pvp-ultra', 'missing']]);
    const folder = val(await svc.defaultOfficialFolder('fps')); assert.equal(folder, path.join(mc, 'aetheris-instances', 'fps'));
    const r = val(await svc.install({ profileId: 'fps', target: { kind: 'official' }, userConfigPolicy: 'keep', createLauncherProfile: true }));
    assert.equal(r.op, 'install'); assert.equal(r.launcherProfile, 'created'); assert.equal(r.folder, folder);
    assert.ok(events.some((e) => e.phase === 'download') && events.at(-1)!.phase === 'done');
    const lp = JSON.parse(await fs.readFile(path.join(mc, 'launcher_profiles.json'), 'utf8'));
    assert.equal(lp.profiles['aetheris-fps'].gameDir, folder); assert.equal(lp.profiles.mio.name, 'Mío');
    const info = val(await svc.inspect(folder))!; assert.equal(info.profileId, 'fps'); assert.equal(info.launcherProfile, true); assert.equal(info.minecraft, '26.3');
    assert.equal(val(await svc.listKnownInstalls()).length, 1);
    assert.equal(val(await svc.verify(folder)).ok, info.fileCount);
    const b = val(await svc.createBackup(folder)); assert.ok(b.fileCount > 0); assert.equal(val(await svc.listBackups(folder)).filter((x) => x.kind === 'manual').length, 1);
    await fs.rm(path.join(folder, 'mods/lithium-1.jar')); assert.deepEqual(val(await svc.verify(folder)).missing, ['mods/lithium-1.jar']);
    assert.deepEqual(val(await svc.repair(folder, 'keep')).repaired, ['mods/lithium-1.jar']);
    const sw = val(await svc.install({ profileId: 'equilibrado', target: { kind: 'folder', folder }, userConfigPolicy: 'keep', createLauncherProfile: false }));
    assert.equal(sw.op, 'switch'); assert.ok(!(await fs.stat(path.join(folder, 'mods/lithium-1.jar')).then(() => true, () => false)));
    const un = val(await svc.uninstall(folder, false)); assert.ok(un.removed >= 2);
    const lp2 = JSON.parse(await fs.readFile(path.join(mc, 'launcher_profiles.json'), 'utf8')); assert.equal(lp2.profiles['aetheris-fps'], undefined); assert.equal(lp2.profiles.mio.name, 'Mío');
    assert.equal(await fs.readFile(path.join(mc, 'saves/MiMundo/level.dat'), 'utf8'), 'MUNDO');
    assert.equal(val(await svc.listKnownInstalls()).length, 0);
  } finally { await s.close(); }
});

test('servicio: perfil sin paquete => error claro y nada instalado; los errores llegan como Result con código y mensaje comprensible', async () => {
  const { s, d, svc } = await world();
  try {
    const r = await svc.install({ profileId: 'pvp-ultra', target: { kind: 'folder', folder: path.join(d, 'x') }, userConfigPolicy: 'keep', createLauncherProfile: false });
    assert.ok(!r.ok && r.error.code === 'E_PROFILE' && /AETHERIS_NEXUS_PVP_ULTRA\.mrpack/.test(r.error.message));
    assert.ok(!(await fs.stat(path.join(d, 'x')).then(() => true, () => false)));
    const bad = await svc.install({ profileId: 'fps', target: { kind: 'folder', folder: 'C:\\' }, userConfigPolicy: 'keep', createLauncherProfile: false });
    assert.ok(!bad.ok && bad.error.code === 'E_TARGET');
    const unk = await svc.install({ profileId: '../x', target: { kind: 'official' }, userConfigPolicy: 'keep', createLauncherProfile: false });
    assert.ok(!unk.ok && unk.error.code === 'E_PROFILE');
    const un = await svc.uninstall(path.join(d, 'nada'), false); assert.ok(!un.ok && un.error.code === 'E_NOT_INSTALLED');
  } finally { await s.close(); }
});

test('servicio: cancelar una instalación en curso y rechazar una segunda operación simultánea', async () => {
  const { s, d, svc } = await world();
  try {
    const f = await makeMrpack({ dir: d, server: s, name: 'lento', versionId: 'lento', files: [{ path: 'mods/a-1.jar', content: 'A' }] });
    s.routes.set('/files/lento/mods/a-1.jar', (_q, res) => { res.write('x'); });
    await fs.copyFile(f, path.join(d, 'packs', 'AETHERIS_NEXUS_FPS.mrpack'));
    const folder = path.join(d, 'inst');
    const p1 = svc.install({ profileId: 'fps', target: { kind: 'folder', folder }, userConfigPolicy: 'keep', createLauncherProfile: false });
    await new Promise((r) => setTimeout(r, 60));
    const second = await svc.verify(folder); assert.ok(!second.ok && second.error.code === 'E_BUSY');
    await svc.cancel();
    const r1 = await p1; assert.ok(!r1.ok && r1.error.code === 'E_CANCELLED');
    assert.ok(!(await fs.stat(path.join(folder, 'mods')).then(() => true, () => false)));
  } finally { await s.close(); }
});

test('servicio: si falla la creación del perfil del launcher, los archivos quedan instalados y se informa claramente', async () => {
  const { s, mc, svc } = await world();
  try {
    await fs.writeFile(path.join(mc, 'launcher_profiles.json'), '{roto');
    const r = val(await svc.install({ profileId: 'fps', target: { kind: 'official' }, userConfigPolicy: 'keep', createLauncherProfile: true }));
    assert.equal(r.launcherProfile, 'failed'); assert.match(r.launcherError!, /dañado/);
    assert.equal(val(await svc.verify(r.folder)).installed, true);
    assert.equal(await fs.readFile(path.join(mc, 'launcher_profiles.json'), 'utf8'), '{roto');
  } finally { await s.close(); }
});
