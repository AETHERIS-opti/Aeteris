# AETHERIS NEXUS INSTALLER

Instalador de escritorio para Windows x64 que instala, repara, actualiza y desinstala los tres perfiles de **AETHERIS NEXUS** (Minecraft Java + Fabric) a partir de archivos `.mrpack` de Modrinth.

Electron + TypeScript + React + Vite + electron-builder (NSIS). El motor de instalación es TypeScript puro sobre Node (sin dependencias externas) y está probado de forma independiente de Electron.

## Estado real (léelo antes de usarlo)

| Componente | Estado |
|---|---|
| Motor `.mrpack` (ZIP seguro, validación, descargas con hash y reintentos, overrides, transacciones, reversión, reparación, copias, desinstalación) | **Implementado y probado** (39 pruebas automáticas, Node 22 en Linux) |
| Detección de sistema, perfil del launcher oficial, perfiles | Implementado; probado con contextos y servidores **simulados** |
| Interfaz React | Implementada; **8 pruebas en Chromium headless con API simulada** |
| Shell de Electron (ventana, IPC, preload) | Escrito y comprobado de tipos contra un shim local; **nunca ejecutado** (no hay Electron en el entorno de desarrollo) |
| Instalador `.exe` (NSIS) | **No generado todavía.** Se compila en GitHub Actions (Windows). **Sin firma digital.** |
| Paquetes `.mrpack` de los tres perfiles | **No incluidos.** La app muestra «Falta el paquete» hasta que los añadas |
| Launchers distintos del oficial | Solo copia de archivos a la carpeta elegida; **ninguno verificado** |

Detalle completo en `docs/AUDITORIA.md` y `docs/LIMITACIONES_Y_PENDIENTES.md`.

## Obtener el `.exe`

1. Sube esta carpeta a un repositorio de GitHub (rama `main`).
2. Pestaña **Actions** → workflow **Build Windows installer** (se lanza solo al hacer push; o «Run workflow»).
3. Al terminar, en la ejecución → **Artifacts** → `AETHERIS-NEXUS-INSTALLER-windows-x64` (el `.exe`) y `AETHERIS-NEXUS-INSTALLER-source` (código fuente en ZIP).
4. El resumen de la ejecución muestra el SHA-256 del `.exe`.

El workflow: instala dependencias → comprueba tipos → ejecuta pruebas → compila → genera el NSIS x64 → verifica que es x64 → arranca la app empaquetada (`--smoke-test`) → instala y desinstala en silencio. **Esos pasos de Windows aún no se han ejecutado nunca**; el primer run puede mostrar errores que habrá que corregir.

Si no existe `package-lock.json`, el primer run lo genera y después ejecuta `npm ci`. Descarga el artefacto `AETHERIS-NEXUS-INSTALLER-package-lock` y añade ese archivo al repositorio; los siguientes builds usarán `npm ci` con versiones fijadas.

## Añadir los paquetes reales

Elige una opción:
- Copia los tres archivos a `packs/` con **estos nombres exactos** antes de compilar (se incluyen en el instalador): `AETHERIS_NEXUS_EQUILIBRADO.mrpack`, `AETHERIS_NEXUS_FPS.mrpack`, `AETHERIS_NEXUS_PVP_ULTRA.mrpack`.
- O en la app: tarjeta del perfil → **Incorporar .mrpack** (se valida y se guarda en la carpeta de datos del usuario; tiene prioridad sobre el incluido).

Reglas que el instalador impone al contenido: FPS y PvP Ultra **no pueden** incluir Iris/shaders (se rechazan). Si dos perfiles tienen exactamente los mismos mods, se muestra un aviso (no se inventan diferencias).

## Desarrollo

```
npm install
npm test            # 39 pruebas del motor/servicio (Node, sin Electron)
npm run build:renderer && npx playwright install chromium && npm run test:ui  # 8 pruebas de UI
npm run typecheck
npm run build && npx electron .
```
Requiere Node ≥ 22.12. Documentación: `docs/`.
