# Registro de cambios

## 1.0.0 (en desarrollo, sin publicar)
- Motor de instalación `.mrpack` transaccional (ZIP seguro, validación, descargas verificadas, overrides, reversión, reparación, copias, desinstalación).
- Perfiles Equilibrado / FPS / PvP Ultra con estado real por paquete; reglas sin shaders en FPS y PvP Ultra; aviso de perfiles idénticos.
- Integración con el launcher oficial (perfil de Fabric + entrada aislada).
- Interfaz React oscura/futurista; shell de Electron endurecido; workflow de GitHub Actions para Windows x64 (no ejecutado).
